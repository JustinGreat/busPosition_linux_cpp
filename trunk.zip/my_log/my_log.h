/*
 * my_log.h
 *
 *  Created on: Oct 22, 2011
 *      Author: wapthen
 */

#ifndef MY_LOG_H_
#define MY_LOG_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <sys/time.h>
#include <sys/stat.h>

#define MY_LOG_DEFAULT_LIMIT_SIZE (10) //M byte
#define MY_LOG_LIMIT_UNIT (1024*1024L)



#define MY_LOG_FATAL	0x01    //fatal errors
#define MY_LOG_WARNING	0x02    //exceptional events
#define MY_LOG_NOTICE   0x04    //informational notices
#define MY_LOG_TRACE	0x08    //program tracing
#define MY_LOG_DEBUG	0x10    //full debugging


enum my_log_notice_type {
	MY_LOG_LOG_ID,
	MY_LOG_FROM_IP,
	MY_LOG_FROM_SRV_NAME,
	MY_LOG_SRV_NAME,
	MY_LOG_ELAPSE_TIME,
	MY_LOG_CMD
};


//public function
int log_init(const char* path="./log/", const char* file="my_log", unsigned int log_level=MY_LOG_DEBUG, unsigned long limit_size=1024);
int log_init_thread_attr();
int log_set_notice_info(my_log_notice_type notice_type, const char* fmt, ...) __attribute__((format(printf, 2, 3)));
int log_set_self_notice(const char* notice_key, const char* fmt, ...) __attribute__((format(printf, 2, 3)));

const char* log_get_notice_info(my_log_notice_type notice_type);
unsigned long log_get_logid();
int log_write(const unsigned int log_level, const char* fmt, ... ) __attribute__ ((format (printf,2,3)));

int log_destroy_thread_attr();
int log_destroy();



#define FATAL_LOG(fmt, arg...) do{ \
	log_write(MY_LOG_FATAL, "[%s:%d] " fmt, __FILE__, __LINE__, ##arg); \
}while(0);

#define WARNING_LOG(fmt, arg...) do{ \
	log_write(MY_LOG_WARNING, "[%s:%d] " fmt, __FILE__, __LINE__, ##arg); \
}while(0);

#define NOTICE_LOG(fmt, arg...) do{ \
	log_write(MY_LOG_NOTICE, "[%s:%d] " fmt, __FILE__, __LINE__, ##arg); \
}while(0);

#define TRACE_LOG(fmt, arg...) do{ \
	log_write(MY_LOG_TRACE, "[%s:%d] " fmt, __FILE__, __LINE__, ##arg); \
}while(0);

#define DEBUG_LOG(fmt, arg...) do{ \
	log_write(MY_LOG_DEBUG, "[%s:%d] " fmt, __FILE__, __LINE__, ##arg); \
}while(0);

#endif /* MY_LOG_H_ */
