/*
 * my_log.cpp
 *
 *  Created on: Oct 22, 2011
 *      Author: wapthen
 */
#include "my_log.h"
#include <signal.h>
#include <stdarg.h>

#define MY_LOG_STR_LEN (512)
#define MY_LOG_FILENAME_LEN (1024)
#define MY_LOG_DATA_LEN (4096)
#define MY_LOG_ITEM_NUM (32)

#define WARNING_LOG_IN(fmt, arg...) \
	fprintf(stderr, "[my_log] [%s:%d]" fmt "\n", __FILE__, __LINE__, ##arg)

#define LOG_SAFE_EXIT() \
	{ while(1) { raise(SIGKILL); } exit(-1); }



typedef struct _log_file_info {
	FILE *fp;
	unsigned long limit_file_size;
	char file_name[MY_LOG_FILENAME_LEN];
	pthread_mutex_t file_lock;
} log_file_info;


typedef struct _log_unit {
	log_file_info* p_logf;
	log_file_info* p_logf_wf;
	unsigned int log_level;
} log_unit;

typedef struct _log_notice_info {
	char log_id[MY_LOG_STR_LEN];
	char log_from_ip[MY_LOG_STR_LEN];
	char log_from_srv_name[MY_LOG_STR_LEN];
	char log_srv_name[MY_LOG_STR_LEN];
	char log_elapse_time[MY_LOG_STR_LEN];
	char log_cmd[MY_LOG_STR_LEN];
} log_notice_info;

typedef struct _log_kv_item {
	char log_key[MY_LOG_STR_LEN];
	char log_value[MY_LOG_STR_LEN];
} log_kv_item;

typedef struct _log_thread_unit {
	pthread_t log_tid;
	log_notice_info log_notice;
	int log_item_no;
	log_kv_item log_item[MY_LOG_ITEM_NUM];
	char log_buf[MY_LOG_DATA_LEN];
} log_thread_unit;

static pthread_key_t g_log_thread_key;
static pthread_once_t g_log_once = PTHREAD_ONCE_INIT;
static log_unit* g_log_unit = NULL;


//static log_thread_unit g_log_thread_stderr =
//{
//	0,
//	{"", "", "", "", "",""},
//	0,
//	{},
//	""
//};
//static log_unit g_log_stderr =
//{
//	{stderr, (MY_LOG_DEFAULT_LIMIT_SIZE * MY_LOG_LIMIT_UNIT), "/dev/stderr", PTHREAD_MUTEX_INITIALIZER},
//	{stderr, (MY_LOG_DEFAULT_LIMIT_SIZE * MY_LOG_LIMIT_UNIT), "/dev/stderr", PTHREAD_MUTEX_INITIALIZER},
//	MY_LOG_FATAL
//};


int log_file_info_init(log_file_info* log_f) {
	if(log_f == NULL) {
		WARNING_LOG_IN("The intput parameter log_f is NULL!");
		return -1;
	}

	pthread_mutex_init(&log_f->file_lock, NULL);
	log_f->file_name[0] = '\0';
	log_f->fp = NULL;
	log_f->limit_file_size = MY_LOG_DEFAULT_LIMIT_SIZE * MY_LOG_LIMIT_UNIT;
	return 0;
}

static void log_key_create() {
	pthread_key_create(&g_log_thread_key, NULL);
	if(g_log_unit == NULL) {
		g_log_unit = (log_unit*) calloc(1, sizeof(log_unit));
		if(g_log_unit == NULL) {
			WARNING_LOG_IN("Fail to calloc memory for g_log_unit!");
			LOG_SAFE_EXIT();
		}

		g_log_unit->p_logf = (log_file_info*) malloc(sizeof(log_file_info));
		if(g_log_unit->p_logf == NULL) {
			WARNING_LOG_IN("Fail to malloc memory for p_logf!");
			LOG_SAFE_EXIT();
		}
		if(log_file_info_init(g_log_unit->p_logf) < 0) {
			LOG_SAFE_EXIT();
		}


		g_log_unit->p_logf_wf = (log_file_info*) malloc(sizeof(log_file_info));
		if(g_log_unit->p_logf_wf == NULL) {
			WARNING_LOG_IN("Fail to malloc memory for p_logf_wf!");
			LOG_SAFE_EXIT();
		}
		if(log_file_info_init(g_log_unit->p_logf_wf) < 0) {
			LOG_SAFE_EXIT();
		}
	}
}

int log_check_log_level(unsigned int log_level) {

	switch(log_level) {
	case MY_LOG_FATAL:
	case MY_LOG_WARNING:
	case MY_LOG_NOTICE:
	case MY_LOG_TRACE:
	case MY_LOG_DEBUG:
		return 0;
	default:
		return -1;
	}
}

FILE* log_open_file_in(const char* path, const char* mode) {
	if(path == NULL || mode == NULL) {
		WARNING_LOG_IN("The input parameter is NULL!");
		return NULL;
	}
	FILE* fp = fopen(path, mode);
	if(fp != NULL) {
		return fp;
	}

	//need to mkdir for path
	char tmp_path[MY_LOG_FILENAME_LEN+1];
	const char* tmp_end_slash = NULL;
	int cp_len = 0;
	tmp_end_slash = strrchr(path, '/');
	if(tmp_end_slash != NULL) {
		cp_len = tmp_end_slash - path;
		if(cp_len > MY_LOG_FILENAME_LEN) {
			return NULL;
		}
		strncpy(tmp_path, path, cp_len);
		tmp_path[cp_len] = '\0';
		mkdir(tmp_path, 0700);
		return fopen(path, mode);
	}else{
		WARNING_LOG_IN("No '/' in path[%s]!", path);
	}

	return NULL;
}

int log_init(const char* path, const char* file, unsigned int log_level, unsigned long limit_size) {

	if(log_check_log_level(log_level) < 0) {
		WARNING_LOG_IN("The input parameter log_level[%u] is illegal!", log_level);
		return -1;
	}
	if(path == NULL) {
		WARNING_LOG_IN("The input parameter path is NULL!");
		return -1;
	}
	if(file == NULL) {
		WARNING_LOG_IN("The input parameter file is NULL!");
		return -1;
	}
	if(limit_size < MY_LOG_DEFAULT_LIMIT_SIZE) {
		limit_size = MY_LOG_DEFAULT_LIMIT_SIZE;
	}


	pthread_once(&g_log_once, log_key_create);

	g_log_unit->log_level = log_level;
	if(path[strlen(path)-1] == '/') {
		snprintf(g_log_unit->p_logf->file_name, sizeof(g_log_unit->p_logf->file_name), "%s%s.log", path, file);
	}else{
		snprintf(g_log_unit->p_logf->file_name, sizeof(g_log_unit->p_logf->file_name), "%s/%s.log", path, file);
	}
	g_log_unit->p_logf->fp = log_open_file_in(g_log_unit->p_logf->file_name, "a");
	if(g_log_unit->p_logf->fp == NULL) {
		WARNING_LOG_IN("Fail to open log_file[%s], err[%s]", g_log_unit->p_logf->file_name, strerror(errno));
		return -1;
	}
	g_log_unit->p_logf->limit_file_size = limit_size * MY_LOG_LIMIT_UNIT;

	if(path[strlen(path)-1] == '/') {
		snprintf(g_log_unit->p_logf_wf->file_name, sizeof(g_log_unit->p_logf_wf->file_name), "%s%s.log.wf", path, file);
	}else{
		snprintf(g_log_unit->p_logf_wf->file_name, sizeof(g_log_unit->p_logf_wf->file_name), "%s/%s.log.wf", path, file);
	}
	g_log_unit->p_logf_wf->fp = log_open_file_in(g_log_unit->p_logf_wf->file_name, "a");
	if(g_log_unit->p_logf_wf->fp == NULL) {
		WARNING_LOG_IN("Fail to open log_file[%s], err[%s]", g_log_unit->p_logf_wf->file_name, strerror(errno));
		return -1;
	}
	g_log_unit->p_logf_wf->limit_file_size = limit_size * MY_LOG_LIMIT_UNIT;

	time_t cur_time = 0;
	struct tm cur_tm;
	time(&cur_time);
	localtime_r(&cur_time, &cur_tm);

	fprintf(g_log_unit->p_logf->fp, "%02d-%02d %02d:%02d:%02d %s", cur_tm.tm_mon+1, cur_tm.tm_mday,
			  cur_tm.tm_hour, cur_tm.tm_min, cur_tm.tm_sec,
			  "====================INIT LOG SUCCESS FINISH====================\n");
	fflush(g_log_unit->p_logf->fp);
	fprintf(g_log_unit->p_logf_wf->fp, "%02d-%02d %02d:%02d:%02d %s", cur_tm.tm_mon+1, cur_tm.tm_mday,
			  cur_tm.tm_hour, cur_tm.tm_min, cur_tm.tm_sec,
			 "====================INIT WFLOG SUCCESS FINISH====================\n");
	fflush(g_log_unit->p_logf_wf->fp);

	return 0;
}

int log_destroy() {
	if(g_log_unit == NULL) {
		return 0;
	}

	g_log_unit->log_level = MY_LOG_FATAL;
	if(g_log_unit->p_logf != NULL) {
		pthread_mutex_destroy(&g_log_unit->p_logf->file_lock);
		g_log_unit->p_logf->file_name[0] = '\0';
		if(g_log_unit->p_logf->fp != NULL) {
			fclose(g_log_unit->p_logf->fp);
			g_log_unit->p_logf->fp = NULL;
		}
		free(g_log_unit->p_logf);
		g_log_unit->p_logf = NULL;
	}
	if(g_log_unit->p_logf_wf != NULL) {
		pthread_mutex_destroy(&g_log_unit->p_logf_wf->file_lock);
		g_log_unit->p_logf_wf->file_name[0] = '\0';
		if(g_log_unit->p_logf_wf->fp != NULL) {
			fclose(g_log_unit->p_logf_wf->fp);
			g_log_unit->p_logf_wf->fp = NULL;
		}
		free(g_log_unit->p_logf_wf);
		g_log_unit->p_logf_wf = NULL;
	}
	free(g_log_unit);
	g_log_unit = NULL;

	return 0;
}


int log_init_thread_attr() {

	if(g_log_unit == NULL) {
		WARNING_LOG_IN("Error! g_log_unit is NULL! Please execute log_init() firstly!");
		return -1;
	}

	log_thread_unit* p_thread_unit = NULL;
	p_thread_unit = (log_thread_unit*) pthread_getspecific(g_log_thread_key);
	if(p_thread_unit == NULL) {
		p_thread_unit = (log_thread_unit*) calloc(1, sizeof(log_thread_unit));
		if(p_thread_unit == NULL) {
			WARNING_LOG_IN("Fail to calloc memory for log_thread_unit!");
			return -1;
		}
	}
	p_thread_unit->log_tid = pthread_self();
	pthread_setspecific(g_log_thread_key, p_thread_unit);

	return 0;
}

int log_destroy_thread_attr() {

	log_thread_unit* p_thread_unit = NULL;
	p_thread_unit = (log_thread_unit*) pthread_getspecific(g_log_thread_key);
	if(p_thread_unit != NULL) {
		free(p_thread_unit);
		p_thread_unit = NULL;
	}

	return 0;
}

int log_check_notice_type(my_log_notice_type notice_type) {

	switch(notice_type) {
	case MY_LOG_LOG_ID:
	case MY_LOG_FROM_IP:
	case MY_LOG_FROM_SRV_NAME:
	case MY_LOG_SRV_NAME:
	case MY_LOG_ELAPSE_TIME:
	case MY_LOG_CMD:
		return 0;
	default:
		return -1;
	}
}

int log_set_notice_info(my_log_notice_type notice_type, const char* fmt, ...) {

	if(log_check_notice_type(notice_type) < 0) {
		WARNING_LOG_IN("notice_type is illegal!");
		return -1;
	}

	log_thread_unit* p_thread_unit = NULL;
	p_thread_unit = (log_thread_unit*) pthread_getspecific(g_log_thread_key);
	if(p_thread_unit == NULL) {
		WARNING_LOG_IN("Fail to get log_thread_unit! Please execute log_init_thread_attr() firstly!");
		return -1;
	}

	char notice_buf[MY_LOG_STR_LEN];

	va_list args;
	va_start(args, fmt);
	vsnprintf(notice_buf, sizeof(notice_buf), fmt, args);
	notice_buf[sizeof(notice_buf)-1] = '\0';
	va_end(args);

	switch(notice_type) {
	case MY_LOG_LOG_ID:
//		p_thread_unit->log_notice.log_id = (unsigned long) atol(notice_buf);
		snprintf(p_thread_unit->log_notice.log_id,
				sizeof(p_thread_unit->log_notice.log_id), "%s", notice_buf);
		break;
	case MY_LOG_FROM_IP:
		snprintf(p_thread_unit->log_notice.log_from_ip,
				sizeof(p_thread_unit->log_notice.log_from_ip), "%s", notice_buf);
		break;
	case MY_LOG_FROM_SRV_NAME:
		snprintf(p_thread_unit->log_notice.log_from_srv_name,
				sizeof(p_thread_unit->log_notice.log_from_srv_name), "%s", notice_buf);
		break;
	case MY_LOG_SRV_NAME:
		snprintf(p_thread_unit->log_notice.log_srv_name,
				sizeof(p_thread_unit->log_notice.log_srv_name), "%s", notice_buf);
		break;
	case MY_LOG_ELAPSE_TIME:
		snprintf(p_thread_unit->log_notice.log_elapse_time,
				sizeof(p_thread_unit->log_notice.log_elapse_time), "%s", notice_buf);
		break;
	case MY_LOG_CMD:
		snprintf(p_thread_unit->log_notice.log_cmd,
				sizeof(p_thread_unit->log_notice.log_cmd), "%s", notice_buf);
		break;
	default:
		WARNING_LOG_IN("notice_type is illegal!");
		break;
	}

	return 0;
}

const char* log_get_notice_info(my_log_notice_type notice_type) {

	if(log_check_notice_type(notice_type) < 0) {
		WARNING_LOG_IN("notice_type is illegal!");
		return NULL;
	}

	log_thread_unit* p_thread_unit = NULL;
	p_thread_unit = (log_thread_unit*) pthread_getspecific(g_log_thread_key);
	if(p_thread_unit == NULL) {
		WARNING_LOG_IN("Fail to get log_thread_unit! Please execute log_init_thread_attr() firstly!");
		return NULL;
	}

	switch(notice_type) {
	case MY_LOG_LOG_ID:
		return p_thread_unit->log_notice.log_id;
	case MY_LOG_FROM_IP:
		return p_thread_unit->log_notice.log_from_ip;
	case MY_LOG_FROM_SRV_NAME:
		return p_thread_unit->log_notice.log_from_srv_name;
	case MY_LOG_SRV_NAME:
		return p_thread_unit->log_notice.log_srv_name;
	case MY_LOG_ELAPSE_TIME:
		return p_thread_unit->log_notice.log_elapse_time;
	case MY_LOG_CMD:
		return p_thread_unit->log_notice.log_cmd;
	default:
		return NULL;
	}

	return NULL;
}

unsigned long log_get_logid() {

	log_thread_unit* p_thread_unit = NULL;
	p_thread_unit = (log_thread_unit*) pthread_getspecific(g_log_thread_key);
	if(p_thread_unit == NULL) {
		WARNING_LOG_IN("Fail to get log_thread_unit! Please execute log_init_thread_attr() firstly!");
		return 0;
	}

	return (unsigned long) atol(p_thread_unit->log_notice.log_id);
}

int log_set_self_notice(const char* notice_key, const char* fmt, ...) {

	if(notice_key == NULL) {
		WARNING_LOG_IN("The input parameter notice_key is NULL!");
		return -1;
	}

	log_thread_unit* p_thread_unit = NULL;
	p_thread_unit = (log_thread_unit*) pthread_getspecific(g_log_thread_key);
	if(p_thread_unit == NULL) {
		WARNING_LOG_IN("Fail to get log_thread_unit! Please execute log_init_thread_attr() firstly!");
		return -1;
	}

	int notice_key_len = strlen(notice_key);
	//check
	for(int i = 0; i < p_thread_unit->log_item_no && i < MY_LOG_ITEM_NUM; i++) {
		int log_key_len = strlen(p_thread_unit->log_item[i].log_key);
		int cmp_len = log_key_len > notice_key_len ? log_key_len:notice_key_len;
		if(strncmp(p_thread_unit->log_item[i].log_key, notice_key, cmp_len) == 0) {
			va_list args;
			va_start(args, fmt);
			char* p_value = p_thread_unit->log_item[i].log_value;
			unsigned int value_len = sizeof(p_thread_unit->log_item[i].log_value);
			vsnprintf(p_value, value_len, fmt, args);
			p_value[value_len-1] = '\0';
			va_end(args);

			p_thread_unit->log_item_no++;

			return 0;
		}
	}


	if(p_thread_unit->log_item_no >= MY_LOG_ITEM_NUM) {
		WARNING_LOG_IN("Already set self_notice too much! more than the limit[%d]", MY_LOG_ITEM_NUM);
		return -1;
	}

	char* p_key = p_thread_unit->log_item[p_thread_unit->log_item_no].log_key;
	unsigned int key_len = sizeof(p_thread_unit->log_item[p_thread_unit->log_item_no].log_key);
	char* p_value = p_thread_unit->log_item[p_thread_unit->log_item_no].log_value;
	unsigned int value_len = sizeof(p_thread_unit->log_item[p_thread_unit->log_item_no].log_value);

	snprintf(p_key, key_len, "%s", notice_key);

	va_list args;
	va_start(args, fmt);
	vsnprintf(p_value, value_len, fmt, args);
	p_value[value_len-1] = '\0';
	va_end(args);

	p_thread_unit->log_item_no++;

	return 0;
}

int log_check_level(const unsigned int log_level) {

	switch(log_level) {
	case MY_LOG_FATAL:
	case MY_LOG_WARNING:
	case MY_LOG_NOTICE:
	case MY_LOG_TRACE:
	case MY_LOG_DEBUG:
		return 0;
	default:
		return -1;
	}
}

int log_check_size(log_file_info* target_logf) {

	if(target_logf == NULL) {
		WARNING_LOG_IN("The input parameter target_logf is NULL!");
		return -1;
	}

	struct stat st;
	int ret = stat(target_logf->file_name, &st);
	if(ret == -1 || st.st_size == 0) {
		if(target_logf->fp != NULL) {
			fclose(target_logf->fp);
			target_logf->fp = NULL;
			target_logf->fp = log_open_file_in(target_logf->file_name, "a");
			if(target_logf->fp == NULL) {
				return -1;
			}
			ret = stat(target_logf->file_name, &st);
			if(ret == -1) {
				return -1;
			}
		}
	}
	if(st.st_size < (long) target_logf->limit_file_size) {
		return 0;
	}

	time_t cur_time;
	struct tm cur_tm;
	time(&cur_time);
	localtime_r(&cur_time, &cur_tm);
	char tmp_filename[MY_LOG_FILENAME_LEN];
	int len = snprintf(tmp_filename, sizeof(tmp_filename), "%s.%04d%02d%02d%02d%02d%02d",
						target_logf->file_name, cur_tm.tm_year+1900, cur_tm.tm_mon+1,
						cur_tm.tm_mday, cur_tm.tm_hour, cur_tm.tm_min, cur_tm.tm_sec);
	int log_index = 0;
	while(stat(tmp_filename, &st) == 0) {
		log_index++;
		snprintf(tmp_filename+len, sizeof(tmp_filename)-len, ".%d", log_index);
	}
	rename(target_logf->file_name, tmp_filename);
	fclose(target_logf->fp);
	target_logf->fp = NULL;
	target_logf->fp = log_open_file_in(target_logf->file_name, "a");
	if(target_logf->fp == NULL) {
		return -1;
	}

	return 0;

}

int log_write_self_notice(log_thread_unit* p_thread_unit, char* p_data, int& data_pos, int& data_len) {

	if(p_thread_unit == NULL || p_data == NULL || data_pos <= data_len) {
		return -1;
	}

	if(p_thread_unit->log_item_no <= 0) {
		return -1;
	}

	for(int i = 0; i < p_thread_unit->log_item_no && i < MY_LOG_ITEM_NUM; i++) {
		if(data_len-data_pos <= 0) {
			WARNING_LOG_IN("log data_buf_len[%d] is too little! overlap!", data_len);
			return -1;;
		}
		if(strlen(p_thread_unit->log_item[i].log_key) != 0) {
			data_pos += snprintf((p_data+data_pos), (data_len-data_pos), "[%s:%s] ",
								p_thread_unit->log_item[i].log_key, p_thread_unit->log_item[i].log_value);
		}
	}

	return 0;
}

int log_write(const unsigned int log_level, const char* fmt, ... ) {

	if(log_check_level(log_level) < 0) {
		WARNING_LOG_IN("The input paramter log_level is illegal!");
		return -1;
	}
	if(g_log_unit == NULL || g_log_unit->p_logf == NULL || g_log_unit->p_logf_wf == NULL) {
		WARNING_LOG_IN("Error! g_log_unit is NULL! Please execute log_init() firstly!");
		return -1;
	}

	if(log_level > g_log_unit->log_level) {
		return 0;
	}

	log_file_info* target_logf = NULL;
	log_thread_unit* p_thread_unit = (log_thread_unit*) pthread_getspecific(g_log_thread_key);
	if(p_thread_unit == NULL) {
//		WARNING_LOG_IN("Fail to get log_thread_unit! Please execute log_init_thread_attr() firstly!");
//		return -1;
		log_init_thread_attr();
		p_thread_unit = (log_thread_unit*) pthread_getspecific(g_log_thread_key);
		if(p_thread_unit == NULL) {
			WARNING_LOG_IN("Fail to get log_thread_unit! Please execute log_init_thread_attr() firstly!");
			return -1;
		}
	}

	char* p_data = p_thread_unit->log_buf;
	int data_len = sizeof(p_thread_unit->log_buf);
	int data_pos = 0;

	switch(log_level) {
	case MY_LOG_FATAL:
		target_logf = g_log_unit->p_logf_wf;
		snprintf(p_data, data_len, "%s: ", "FATAL");
		data_pos += strlen(p_data);
		break;
	case MY_LOG_WARNING:
		target_logf = g_log_unit->p_logf_wf;
		snprintf(p_data, data_len, "%s: ", "WARN");
		data_pos += strlen(p_data);
		break;
	case MY_LOG_NOTICE:
		target_logf = g_log_unit->p_logf;
		snprintf(p_data, data_len, "%s: ", "NOTICE");
		data_pos += strlen(p_data);
		break;
	case MY_LOG_TRACE:
		target_logf = g_log_unit->p_logf;
		snprintf(p_data, data_len, "%s: ", "TRACE");
		data_pos += strlen(p_data);
		break;
	case MY_LOG_DEBUG:
		target_logf = g_log_unit->p_logf;
		snprintf(p_data, data_len, "%s: ", "DEBUG");
		data_pos += strlen(p_data);
		break;
	default:
		break;
	}

	va_list args;
	time_t cur_time = 0;
	struct tm cur_tm;
	time(&cur_time);
	localtime_r(&cur_time, &cur_tm);

	if(data_len-data_pos <= 0) {
		WARNING_LOG_IN("log data_buf_len[%d] is too little! overlap!", data_len);
		return -1;
	}
	data_pos += snprintf((p_data+data_pos), (data_len-data_pos), "%02d-%02d %02d:%02d:%02d ",
						cur_tm.tm_mon+1, cur_tm.tm_mday, cur_tm.tm_hour, cur_tm.tm_min, cur_tm.tm_sec);

	if(data_len-data_pos <= 0) {
		WARNING_LOG_IN("log data_buf_len[%d] is too little! overlap!", data_len);
		goto handle;
	}
	if(strlen(p_thread_unit->log_notice.log_srv_name) != 0) {
		data_pos += snprintf((p_data+data_pos), (data_len-data_pos), "[%s] [tid:%lu]",
							p_thread_unit->log_notice.log_srv_name, p_thread_unit->log_tid);
	}else{
		data_pos += snprintf((p_data+data_pos), (data_len-data_pos), "[tid:%lu]",
							p_thread_unit->log_tid);
	}

	if(data_len-data_pos <= 0) {
		WARNING_LOG_IN("log data_buf_len[%d] is too little! overlap!", data_len);
		goto handle;
	}
	/*�ر�log_id����־��ӡ
	if(strlen(p_thread_unit->log_notice.log_id) != 0) {
		data_pos += snprintf((p_data+data_pos), (data_len-data_pos), "[logid:%s]", p_thread_unit->log_notice.log_id);
	}else{
		data_pos += snprintf((p_data+data_pos), (data_len-data_pos), "[logid:%d]", 0);
	}

	if(data_len-data_pos <= 0) {
		WARNING_LOG_IN("log data_buf_len[%d] is too little! overlap!", data_len);
		goto handle;
	}*/
	if(strlen(p_thread_unit->log_notice.log_from_ip) != 0) {
		data_pos += snprintf((p_data+data_pos), (data_len-data_pos), "[reqip:%s]", p_thread_unit->log_notice.log_from_ip);
	}

	if(data_len-data_pos <= 0) {
		WARNING_LOG_IN("log data_buf_len[%d] is too little! overlap!", data_len);
		goto handle;
	}
	if(strlen(p_thread_unit->log_notice.log_from_srv_name) != 0) {
		data_pos += snprintf((p_data+data_pos), (data_len-data_pos), "[reqname:%s]", p_thread_unit->log_notice.log_from_srv_name);
	}

	if(data_len-data_pos <= 0) {
		WARNING_LOG_IN("log data_buf_len[%d] is too little! overlap!", data_len);
		goto handle;
	}
	if(strlen(p_thread_unit->log_notice.log_elapse_time) != 0) {
		data_pos += snprintf((p_data+data_pos), (data_len-data_pos), "[%sus]", p_thread_unit->log_notice.log_elapse_time);
	}

	if(data_len-data_pos <= 0) {
		WARNING_LOG_IN("log data_buf_len[%d] is too little! overlap!", data_len);
		goto handle;
	}
	if(strlen(p_thread_unit->log_notice.log_cmd) != 0) {
		data_pos += snprintf((p_data+data_pos), (data_len-data_pos), "[cmd:%s]", p_thread_unit->log_notice.log_cmd);
	}


	//print self_notice
	log_write_self_notice(p_thread_unit, p_data, data_pos, data_len);

	if(data_len-data_pos <= 0) {
		WARNING_LOG_IN("log data_buf_len[%d] is too little! overlap!", data_len);
		goto handle;
	}

	va_start(args, fmt);
	vsnprintf((p_data+data_pos), (data_len-data_pos), fmt, args);
	va_end(args);

handle:
	pthread_mutex_lock(&target_logf->file_lock);
	if(log_check_size(target_logf) < 0) {
		WARNING_LOG_IN("Fail to check log_size!");
		pthread_mutex_unlock(&target_logf->file_lock);
		return -1;
	}
	fprintf(target_logf->fp, "%s\n", p_data);
	fflush(target_logf->fp);
	pthread_mutex_unlock(&target_logf->file_lock);

	return 0;
}
