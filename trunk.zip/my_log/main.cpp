/*
 * main.cpp
 *
 *  Created on: Oct 27, 2011
 *      Author: wapthen
 */
#include "my_log.h"
#include <unistd.h>
void* print_log(void* param);

int main() {

	int ret = log_init();
	if(ret < 0) {
		printf("Fail to log_init!\n");
		return -1;
	}


	printf("###start thread###\n");
	pthread_t pid[10];

	int i = 0;
	while(i < 6) {
		int* thread_param = (int *) malloc(sizeof(int));
		*thread_param = i;
		printf("create thread[%d]\n", *thread_param);
		pthread_create(&pid[i], NULL, print_log, thread_param);

		i++;
	}

	i--;
	while(i >= 0) {
		pthread_join(pid[i], NULL);
		i--;
	}

	printf("Finish!");

	return 0;
}

void* print_log(void* param) {
	unsigned int i = *((unsigned int*) param);
	free(param);
	param = NULL;
	log_init_thread_attr();
	int ret = log_set_notice_info(MY_LOG_LOG_ID, "%u", i);
	if(ret < 0) {
		WARNING_LOG("Fail to MY_LOG_LOG_ID!");
		return NULL;
	}
	ret = log_set_notice_info(MY_LOG_FROM_IP, "%s", "127.0.0.1");
	if(ret < 0) {
		WARNING_LOG("Fail to MY_LOG_FROM_IP");
		return NULL;
	}
	ret = log_set_notice_info(MY_LOG_FROM_SRV_NAME, "srv_%u", i);
	if(ret < 0) {
		WARNING_LOG("Fail to MY_LOG_FROM_SRV_NAME");
		return NULL;
	}
	ret = log_set_notice_info(MY_LOG_CMD, "%u%u%u", i, i, i);
	if(ret < 0) {
		WARNING_LOG("Fail to MY_LOG_CMD");
		return NULL;
	}
	NOTICE_LOG("=============Thread_%u RUN==========", i);


	while(1) {

		WARNING_LOG("WARN!!! [%u]", i);
		FATAL_LOG("FATAL!!! [%u]", i);
		NOTICE_LOG("NOTICE!!! [%u]", i);
		DEBUG_LOG("DEBUG!!! [%u]", i);
		TRACE_LOG("TRACE!!! [%u]", i);
	}


	return NULL;
}

