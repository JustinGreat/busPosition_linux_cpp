/*
 * srv_pool.h
 *
 *  Created on: Oct 25, 2011
 *      Author: wapthen
 */

#ifndef SRV_POOL_H_
#define SRV_POOL_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <unistd.h>

#include "srv_struct.h"

//start functions
int srv_load_conf(srv_conf* p_srv_conf, conf_data* raw_conf);
int srv_default_conf(srv_conf* p_srv_conf);
srv_unit* srv_create(srv_conf* p_srv_conf);
int srv_set_rw_data(srv_unit* srv, void** read_buf, unsigned int read_size,
					void** write_buf, unsigned int write_size);
int srv_set_user_data(srv_unit* srv, void** user_buf, unsigned int user_size);
int srv_set_call_back(srv_unit* srv, call_back_func cb_func);
int srv_run(srv_unit* srv);
int srv_join(srv_unit* srv);
int srv_destroy(srv_unit* srv);

// use functions
void* srv_get_read_data();
int srv_get_read_size();
void* srv_get_write_data();
int srv_get_write_size();
void* srv_get_user_data();
int srv_get_user_size();
int srv_read_sock(int time_out);
int srv_write_sock(unsigned int body_len, int time_out);
int srv_write_sock_tail(unsigned int body_len, int time_out);
/*
 * ����ֵΪ-1��ʾ������-2��ʾ��http��get��������ֵ��ʾ��http��post�����ҷ���ֵ��ʾcontent-len��ֵ
 */
int srv_read_http_is_get(char* src);
int srv_read_http_head(int sock, void* buf, unsigned int len, unsigned int time_out);
int srv_read_http_line(int sock, void* buf, unsigned int len, unsigned int time_out);
int srv_read_peek(int sock, void* buf, unsigned int len, unsigned int time_out);
int srv_get_sequence_id(void* src, char* seq_id_buf, int seq_id_buf_len);
/*
 * mode_type Ϊ1��ʾGET��Ϊ2��ʾPOST
 */
int srv_read_http(int time_out, int& mode_type, char* seq_id_buf=NULL, int seq_id_buf_len=0);
int srv_write_raw(void* buf, unsigned int buf_len, int time_out);

int srv_set_name(srv_unit* srv, const char* name);
int srv_set_port(srv_unit* srv, const unsigned int port);
int srv_set_timeout(srv_unit* srv, const unsigned int read_to,
					const unsigned int write_to, const unsigned int conn_to);
int srv_get_conn_timeout(srv_unit* srv);
int srv_set_backlog(srv_unit* srv, const unsigned int backlog);

int srv_set_conn_type(srv_unit* srv, const unsigned int connect_type);
int srv_get_conn_type(srv_unit* srv);
int srv_set_srv_type(srv_unit* srv, const unsigned int type);

int srv_set_pending_queue_cap(srv_unit* srv, unsigned int cap);
int srv_set_sock_arr_size(srv_unit* srv, unsigned int arr_size);
int srv_set_stack_size(srv_unit* srv, unsigned int stack_size);

int srv_set_thread_num(srv_unit* srv, const unsigned int thread_num);

srv_unit* srv_get_server();

int srv_set_thread_data(srv_thread_data* data);
srv_thread_data* srv_get_thread_data();

int srv_setsocketnoblock(int sock);
int srv_setsocketcom(int sock);

#endif /* SRV_POOL_H_ */
