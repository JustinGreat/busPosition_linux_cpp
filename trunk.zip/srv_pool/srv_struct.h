/*
 * srv_struct.h
 *
 *  Created on: Oct 25, 2011
 *      Author: wapthen
 */

#ifndef SRV_STRUCT_H_
#define SRV_STRUCT_H_

#include "read_conf.h"
#include <netinet/in.h>

#define MAGIC_GOD (0xFFFFEEEE)
#define MAGIC_TAIL (0xEEEEFFFF)



typedef int (*call_back_func) ();

typedef struct _srv_thread_data {
	pthread_t pid;
	unsigned int id;
	int sock;
	in_addr_t ip;
	unsigned int stack_size;

	void* read_buf;
	unsigned int read_size;
	void* write_buf;
	unsigned int write_size;
	void* user_buf;
	unsigned int user_size;

	void* parent;

} srv_thread_data;

typedef struct _srv_unit{
	char srv_name[WORD_SIZE];
	unsigned int srv_type;
	unsigned int srv_connect_type;
	unsigned int srv_port;
	unsigned int srv_backlog;
	unsigned int srv_thread_num;

	unsigned int srv_connect_to;
	unsigned int srv_read_to;
	unsigned int srv_write_to;

	int srv_sock;

	int srv_is_run;
	srv_thread_data* srv_data;
	call_back_func cb_fun;

	void* pool;
	unsigned int pool_sock_arr_size;
	unsigned int pool_pending_queue_cap;
	unsigned int srv_stack_size;

} srv_unit;

typedef struct _srv_conf {
	char name[WORD_SIZE];
	unsigned int srv_type; // select pool, epool
	unsigned int connect_type; // long_connect, short_connect
	unsigned int port;
	unsigned int backlog;
	unsigned int thread_num;

	unsigned int connect_to;
	unsigned int read_to;
	unsigned int write_to;

	unsigned int read_size;
	unsigned int write_size;
	unsigned int user_size;

	unsigned int pool_sock_arr_size;
	unsigned int pool_pending_queue_cap;
	unsigned int srv_stack_size;
} srv_conf;

enum CONNECT_TYPE {
	SHORT_CONNECT = 0,
	LONG_CONNECT
};

typedef struct _srv_head {
	unsigned int magic_num;
	unsigned int body_len;
} srv_head;

enum SRV_TYPE {
	SELECT_POOL = 0,
	EPOLL_POOL = 1,
};

enum S_STATUS {
	IDLE = 0,
	READY,
	BUSY
};

typedef struct _q_unit {
	int sock;
	int status;
	time_t last_active;
	in_addr_t ip;
}q_unit;

#endif /* SRV_STRUCT_H_ */
