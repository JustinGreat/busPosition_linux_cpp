/*
 * select_pool.cpp
 *
 *  Created on: Oct 25, 2011
 *      Author: wapthen
 */
#include "select_pool.h"
#include "srv_pool.h"
#include "srv_frame.h"
#include "my_log.h"

#define IP_BUF_LEN (128)
#define S_DEFAULT_READY_Q_SIZE (100)
#define S_DEFAULT_SOCK_ARR_SIZE (300)
#define S_DEFAULT_CHK_INTERVAL (10) //ms
#define S_DEFAULT_CONN_TIMEOUT (60) //s

void* produce_spool(void* param);
void produce(srv_unit* srv);
void* work_spool(void* param);
void work(srv_unit* srv, srv_thread_data* data);
int add_sock_arr(s_pool* p_sp, int new_client, in_addr_t client_addr);
int check_ready_sock_arr(s_pool* p_sp);




int init_spool(srv_unit* srv) {

	if(srv->pool != NULL) {
		FATAL_LOG("Already init_spool!");
		return -1;
	}
	s_pool* p_sp = NULL;
	srv->pool = calloc(1, sizeof(s_pool));
	if(srv->pool == NULL) {
		FATAL_LOG("Fail to calloc memory for spool!");
		goto err_exit;
	}

	p_sp = (s_pool*) srv->pool;
	p_sp->pool_ready_queue = new std::queue<int>;
	if(p_sp->pool_ready_queue == NULL) {
		FATAL_LOG("Fail to new memory for pool_ready_queue!");
		goto err_exit;
	}

	p_sp->pool_ready_queue_cap = srv->pool_pending_queue_cap;
	if(p_sp->pool_ready_queue_cap == 0) {
		p_sp->pool_ready_queue_cap = S_DEFAULT_READY_Q_SIZE;
	}

	p_sp->pool_sock_arr_size = srv->pool_sock_arr_size;
	if(p_sp->pool_sock_arr_size == 0) {
		p_sp->pool_sock_arr_size = S_DEFAULT_SOCK_ARR_SIZE;
	}

	p_sp->pool_sock_arr = (q_unit *) calloc(p_sp->pool_sock_arr_size, sizeof(q_unit));
	if(p_sp->pool_sock_arr == NULL) {
		FATAL_LOG("Fail to calloc memory for pool_sock_arr!");
		goto err_exit;
	}
	for(unsigned int i = 0; i < p_sp->pool_sock_arr_size; i++) {
		p_sp->pool_sock_arr[i].sock = -1;
		p_sp->pool_sock_arr[i].status = IDLE;
		p_sp->pool_sock_arr[i].ip = 0;
	}

	p_sp->pool_check_interval.tv_sec = S_DEFAULT_CHK_INTERVAL / 1000;
	p_sp->pool_check_interval.tv_usec = (S_DEFAULT_CHK_INTERVAL % 1000) * 1000;

	p_sp->pool_timeout = srv_get_conn_timeout(srv) / 1000;
	if(p_sp->pool_timeout <= 0) {
		p_sp->pool_timeout = S_DEFAULT_CONN_TIMEOUT;
	}

	pthread_mutex_init(&p_sp->ready_mutex, NULL);
	pthread_cond_init(&p_sp->ready_cond, NULL);

	NOTICE_LOG("========SUCCESS FINISH INIT SELECT_POOL SERVER!========");
	return 0;

err_exit:
	if(srv->pool != NULL) {
		free(srv->pool);
		srv->pool = NULL;
	}
	if(p_sp->pool_ready_queue != NULL) {
		delete p_sp->pool_ready_queue;
		p_sp->pool_ready_queue = NULL;
	}
	if(p_sp->pool_sock_arr != NULL) {
		free(p_sp->pool_sock_arr);
		p_sp->pool_sock_arr = NULL;
	}
	return -1;

}

int run_spool(srv_unit* srv) {
	if(srv == NULL) {
		FATAL_LOG("The input parameter is NULL!");
		return -1;
	}
	if(srv->pool == NULL) {
		FATAL_LOG("server pool is NULL! Please firstly init_spool()!");
		return -1;
	}

	s_pool* p_sp = (s_pool*) srv->pool;
	if(srv->srv_stack_size > 0) {
		pthread_attr_t thread_attr;
		if(pthread_attr_init(&thread_attr) != 0) {
			WARNING_LOG("Fail to init pthread_attr_t!");
			return -1;
		}
		if(pthread_attr_setstacksize(&thread_attr, srv->srv_stack_size) != 0) {
			WARNING_LOG("Fail to pthread_attr_setstacksize!");
			pthread_attr_destroy(&thread_attr);
			return -1;
		}
		if(pthread_create(&p_sp->pool_pthread, &thread_attr, produce_spool, srv) != 0) {
			WARNING_LOG("Fail to pthread_create produce_spool!");
			pthread_attr_destroy(&thread_attr);
			return -1;
		}

		pthread_attr_destroy(&thread_attr);
	}else{
		if(pthread_create(&p_sp->pool_pthread, NULL, produce_spool, srv) != 0) {
			WARNING_LOG("Fail to pthread_create produce_spool!");
			return -1;
		}
	}

	for(unsigned int i = 0; i < srv->srv_thread_num; i++) {
		srv->srv_data[i].id = i;
		if(srv->srv_stack_size > 0) {
			pthread_attr_t thread_attr;
			if(pthread_attr_init(&thread_attr) != 0) {
				WARNING_LOG("Fail to init pthread_attr_t!");
				return -1;
			}
			if(pthread_attr_setstacksize(&thread_attr, srv->srv_stack_size) != 0) {
				WARNING_LOG("Fail to pthread_attr_setstacksize!");
				pthread_attr_destroy(&thread_attr);
				return -1;
			}
			if(pthread_create(&srv->srv_data[i].pid, &thread_attr, work_spool, &srv->srv_data[i]) != 0) {
				WARNING_LOG("Fail to pthread_create worker_spool!");
				pthread_attr_destroy(&thread_attr);
				return -1;
			}

			pthread_attr_destroy(&thread_attr);
		}else{
			if(pthread_create(&srv->srv_data[i].pid, NULL, work_spool, &srv->srv_data[i]) != 0) {
				WARNING_LOG("Fail to pthread_create worker_spool!");
				return -1;
			}
		}
	}

	return 0;

}

int join_spool(srv_unit* srv) {
	if(srv == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}

	s_pool* p_sp = (s_pool*) srv->pool;
	if(p_sp == NULL) {
		return -1;
	}

	pthread_join(p_sp->pool_pthread, NULL);

	for(unsigned int i = 0; i < srv->srv_thread_num; i++) {
		pthread_join(srv->srv_data[i].pid, NULL);
	}

	return 0;
}


#define MAX_SPOOL(a,b) ((a)>(b)?(a):(b))
void produce(srv_unit* srv) {
	if(srv == NULL) {
		FATAL_LOG("srv_unit is NULL!");
		return;
	}
	s_pool* p_sp = (s_pool*) srv->pool;
	FD_ZERO(&p_sp->pool_set);
	FD_SET(srv->srv_sock, &p_sp->pool_set);
	int max_sock = 0;
	for(unsigned int i = 0; i < p_sp->pool_sock_arr_size; i++) {
		if(p_sp->pool_sock_arr[i].status == READY) {
			FD_SET(p_sp->pool_sock_arr[i].sock, &p_sp->pool_set);
			if(p_sp->pool_sock_arr[i].sock > max_sock) {
				max_sock = p_sp->pool_sock_arr[i].sock;
			}
		}
	}
	struct timeval time_out = p_sp->pool_check_interval;
	int ret = select(MAX_SPOOL(max_sock, srv->srv_sock)+1, &(p_sp->pool_set), 0, 0, &time_out);
	if(ret <= 0) {
		return;
	}

	//handl new client tcp connection
	if(FD_ISSET(srv->srv_sock, &(p_sp->pool_set))) {
		struct sockaddr_in client_addr;
		unsigned int client_addr_len = sizeof(client_addr);
		int new_client = accept(srv->srv_sock, (struct sockaddr*) &client_addr, &client_addr_len);
		if(new_client >= 0) {
			srv_setsocketcom(new_client);
			if(add_sock_arr(p_sp, new_client, client_addr.sin_addr.s_addr) == 0) {
				DEBUG_LOG("new client connect!socket[%d]", new_client);
				FD_SET(new_client, &p_sp->pool_set);
			}else{
				close(new_client);
			}
		}
	}

	//put all sock in which new data arrives into ready queue
	check_ready_sock_arr(p_sp);
	return;
}

int check_ready_sock_arr(s_pool* p_sp) {

	if(p_sp == NULL) {
		return -1;
	}

	time_t cur_time;
	time(&cur_time);

	for(unsigned int i = 0; i < p_sp->pool_sock_arr_size; i++) {
		switch(p_sp->pool_sock_arr[i].status) {
		case IDLE:
			break;
		case BUSY:
			time(&(p_sp->pool_sock_arr[i].last_active));
			break;
		case READY:
		{
			if(FD_ISSET(p_sp->pool_sock_arr[i].sock, &p_sp->pool_set)) {
				pthread_mutex_lock(&p_sp->ready_mutex);
				if(p_sp->pool_ready_queue->size() >= p_sp->pool_ready_queue_cap) {
					WARNING_LOG("server ready_queue is full! limit_num[%u], close socket[%d]",
								 p_sp->pool_ready_queue_cap,
								 p_sp->pool_sock_arr[i].sock);

					pthread_mutex_unlock(&p_sp->ready_mutex);
					close(p_sp->pool_sock_arr[i].sock);
					p_sp->pool_sock_arr[i].sock = -1;
					p_sp->pool_sock_arr[i].status = IDLE;
					p_sp->pool_sock_arr[i].last_active = 0;
					break;
				}
//				DEBUG_LOG("Push socket[%d] int read_queue!", p_sp->pool_sock_arr[i].sock);
				p_sp->pool_ready_queue->push(i);
				p_sp->pool_sock_arr[i].status = BUSY;
				pthread_cond_signal(&p_sp->ready_cond);
				pthread_mutex_unlock(&p_sp->ready_mutex);
			}else if(cur_time - p_sp->pool_sock_arr[i].last_active >= (p_sp->pool_timeout)) {
				WARNING_LOG("sock[%d] is timeout! will be closed!", p_sp->pool_sock_arr[i].sock);
				//handle long connect type and timeout
				char ip_str[IP_BUF_LEN];
				struct in_addr tmp_ip;
				bzero(&tmp_ip, sizeof(struct in_addr));
				tmp_ip.s_addr = p_sp->pool_sock_arr[i].ip;
				if(inet_ntop(AF_INET, (void*) &tmp_ip, ip_str, IP_BUF_LEN) == NULL) {
					WARNING_LOG("sock[%d] Fail to inet_ntop! err[%s]",
							     p_sp->pool_sock_arr[i].sock, strerror(errno));
				}else {
					WARNING_LOG("sock[%d] ip[%s] in ready queue timeout! Have removed from queue!",
								 p_sp->pool_sock_arr[i].sock, ip_str);
				}
				if(p_sp->pool_sock_arr[i].sock >= 0) {
					close(p_sp->pool_sock_arr[i].sock);
					p_sp->pool_sock_arr[i].sock = -1;
				}
				p_sp->pool_sock_arr[i].status = IDLE;
				p_sp->pool_sock_arr[i].last_active = 0;
			}

			break;
		}
		default:
			break;
		}
	}

	return 0;
}


int add_sock_arr(s_pool* p_sp, int new_client, in_addr_t client_addr) {

	int idle_index = -1;
	for(unsigned int i = 0; i < p_sp->pool_sock_arr_size; i++) {
		if(p_sp->pool_sock_arr[i].status == IDLE) {
			idle_index = i;
			break;
		}
	}
	if(idle_index < 0) {
		WARNING_LOG("server socket array is full! limit_num[%u], close socket[%d]",
					p_sp->pool_sock_arr_size,
					new_client);
		return -1;
	}

	p_sp->pool_sock_arr[idle_index].sock = new_client;
	time(&(p_sp->pool_sock_arr[idle_index].last_active));
	p_sp->pool_sock_arr[idle_index].status = READY;
	p_sp->pool_sock_arr[idle_index].ip = client_addr;

	return 0;
}

void* produce_spool(void* param) {
	srv_unit* srv = (srv_unit*) param;

	log_init_thread_attr();
	log_set_notice_info(MY_LOG_SRV_NAME, "%s", srv->srv_name);
	srv_setsocketnoblock(srv->srv_sock);
	NOTICE_LOG("Start produce thread!");
	while(srv->srv_is_run) {
		produce(srv);
	}
	log_destroy_thread_attr();
	pthread_exit(NULL);
	return NULL;
}

void* work_spool(void* param) {
	srv_thread_data* data= (srv_thread_data*) param;
	srv_unit* srv = (srv_unit*) data->parent;
	if(srv == NULL) {
		return NULL;
	}
	log_init_thread_attr();
	log_set_notice_info(MY_LOG_SRV_NAME, "%s", srv->srv_name);
	srv_set_thread_data(data);
	NOTICE_LOG("Start work thread! id[%u]", data->id);

	while(srv->srv_is_run) {
		work(srv, data);
	}
	log_destroy_thread_attr();
	pthread_exit(NULL);
	return NULL;
}

void work(srv_unit* srv, srv_thread_data* data) {
	if(srv == NULL) {
		return;
	}
	s_pool* p_sp = (s_pool*) srv->pool;
	if(p_sp == NULL) {
		return;
	}
	pthread_mutex_lock(&p_sp->ready_mutex);
	while(p_sp->pool_ready_queue->empty()) {
		struct timeval cur_time;
		struct timespec timeout;
		gettimeofday(&cur_time, NULL);
		timeout.tv_sec = cur_time.tv_sec + 5;
		timeout.tv_nsec = cur_time.tv_usec * 1000;
		pthread_cond_timedwait(&p_sp->ready_cond, &p_sp->ready_mutex, &timeout);
	}
	int q_index = -1;
	if(!p_sp->pool_ready_queue->empty()) {
		q_index = p_sp->pool_ready_queue->front();
		p_sp->pool_ready_queue->pop();
	}
	pthread_mutex_unlock(&p_sp->ready_mutex);

	if(q_index < 0 || q_index >= (int) p_sp->pool_sock_arr_size) {
		WARNING_LOG("get illegal socket index[%d] from queue!", q_index);
		return;
	}

	data->ip = p_sp->pool_sock_arr[q_index].ip;
	data->sock = p_sp->pool_sock_arr[q_index].sock;
	int ret = srv->cb_fun();

	if(ret == 0 && srv_get_conn_type(srv) == LONG_CONNECT) {
//		WARNING_LOG("sock[%d] Long Connect type!! Still connection!", p_sp->pool_sock_arr[q_index].sock);
		if(p_sp->pool_sock_arr[q_index].status == BUSY) {
			p_sp->pool_sock_arr[q_index].status = READY;
			time(&(p_sp->pool_sock_arr[q_index].last_active));
		}
	}else{
//		WARNING_LOG("sock[%d] Short Connect type!!", p_sp->pool_sock_arr[q_index].sock);
		if(p_sp->pool_sock_arr[q_index].sock >= 0) {
			close(p_sp->pool_sock_arr[q_index].sock);
		}
		p_sp->pool_sock_arr[q_index].sock = -1;
		p_sp->pool_sock_arr[q_index].status = IDLE;
		p_sp->pool_sock_arr[q_index].last_active = 0;

		data->sock = -1;
		data->ip = 0;
	}

}

int destroy_spool(srv_unit* srv) {
	if(srv == NULL) {
		WARNING_LOG("The input paramter is NULL!");
		return -1;
	}

	s_pool* p_sp = (s_pool*) srv->pool;
	if(p_sp == NULL) {
		return 0;
	}

	pthread_mutex_destroy(&p_sp->ready_mutex);
	pthread_cond_destroy(&p_sp->ready_cond);
	if(p_sp->pool_ready_queue != NULL) {
		delete p_sp->pool_ready_queue;
		p_sp->pool_ready_queue = NULL;
	}
	if(p_sp->pool_sock_arr != NULL) {
		free(p_sp->pool_sock_arr);
		p_sp->pool_sock_arr = NULL;
	}
	free(srv->pool);
	srv->pool = NULL;

	return 0;
}
