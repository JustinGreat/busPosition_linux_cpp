/*
 * srv_pool.cpp
 *
 *  Created on: Oct 25, 2011
 *      Author: wapthen
 */

#include "my_log.h"
#include "srv_pool.h"
#include "srv_frame.h"


#include <netinet/tcp.h>
#include <signal.h>

#define SRV_DEFAULT_BACKLOG (500)
#define SRV_DEFAULT_RD_TO (500)
#define SRV_DEFAULT_WR_TO (500)
#define SRV_DEFAULT_RD_SIZE (2*1024*1024)
#define SRV_DEFAULT_WR_SIZE (2*1024*1024)
#define SRV_DEFAULT_US_SIZE (2*1024*1024)
#define SRV_DEFAULT_THREAD_STACK_SIZE (10485760)

static pthread_key_t g_pool_key;
static pthread_once_t g_pool_once = PTHREAD_ONCE_INIT;

void srv_create_pool_key() {
	pthread_key_create(&g_pool_key, NULL);
}

int srv_set_thread_data(srv_thread_data* data) {
	if(data == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}
	pthread_once(&g_pool_once, srv_create_pool_key);
	if(pthread_getspecific(g_pool_key) == NULL) {
		pthread_setspecific(g_pool_key, data);
	}

	return 0;
}

srv_thread_data* srv_get_thread_data() {
	return (srv_thread_data*) pthread_getspecific(g_pool_key);
}

int srv_setsocketnoblock(int sock) {
	int flag = 0;
	while((flag = fcntl(sock, F_GETFL, 0)) == -1) {
		if(errno == EINTR) {
			continue;
		}
		WARNING_LOG("Fail to fcntl[%d] no_block! err[%s]", sock, strerror(errno));
		return -1;
	}

	if(flag & O_NONBLOCK) {
		return 0;
	}
	flag |= O_NONBLOCK;
	while(fcntl(sock, F_SETFL, flag) == -1) {
		if(errno == EINTR) {
			continue;
		}
		WARNING_LOG("Fail to fcntl[0] no_block! err[%s]", strerror(errno));
		return -1;
	}
	return 0;
}

int srv_setsocketcom(int sock) {
	int on = 1;
	setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, &on, sizeof(on));

//	struct linger li;
//	memset(&li, 0, sizeof(struct linger));
//	li.l_onoff = 1;
//	li.l_linger = 1;
//	setsockopt(sock, SOL_SOCKET, SO_LINGER, &li, sizeof(struct linger));
	return 0;
}

void* srv_get_read_data() {
	srv_thread_data* p_data = srv_get_thread_data();
	if(p_data == NULL) {
		return NULL;
	}

	return p_data->read_buf;
}
int srv_get_read_size() {
	srv_thread_data* p_data = srv_get_thread_data();
	if(p_data == NULL) {
		return 0;
	}

	return p_data->read_size;
}

void* srv_get_write_data() {
	srv_thread_data* p_data = srv_get_thread_data();
	if(p_data == NULL) {
		return NULL;
	}
	return p_data->write_buf;
}

int srv_get_write_size() {
	srv_thread_data* p_data = srv_get_thread_data();
	if(p_data == NULL) {
		return 0;
	}
	return p_data->write_size;
}

void* srv_get_user_data() {
	srv_thread_data* p_data = srv_get_thread_data();
	if(p_data == NULL) {
		return NULL;
	}
	return p_data->user_buf;
}

int srv_get_user_size() {
	srv_thread_data* p_data = srv_get_thread_data();
	if(p_data == NULL) {
		return 0;
	}
	return p_data->user_size;
}

srv_unit* srv_get_server() {
	srv_thread_data* p_data = srv_get_thread_data();
	if(p_data == NULL) {
		return 0;
	}
	return (srv_unit*) p_data->parent;
}
int srv_default_conf(srv_conf* p_srv_conf) {

	if(p_srv_conf == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}

	p_srv_conf->backlog = SRV_DEFAULT_BACKLOG;
	p_srv_conf->connect_type = SHORT_CONNECT;

	p_srv_conf->name[0] = '\0';

	p_srv_conf->port = 0;
	p_srv_conf->read_to = SRV_DEFAULT_RD_TO;
	p_srv_conf->thread_num = 0;
	p_srv_conf->srv_type = SELECT_POOL;
	p_srv_conf->write_to = SRV_DEFAULT_WR_TO;

	p_srv_conf->read_size = SRV_DEFAULT_RD_SIZE;
	p_srv_conf->write_size = SRV_DEFAULT_WR_SIZE;
	p_srv_conf->user_size = SRV_DEFAULT_US_SIZE;

	p_srv_conf->pool_pending_queue_cap = 0;
	p_srv_conf->pool_sock_arr_size = 0;
	p_srv_conf->srv_stack_size = SRV_DEFAULT_THREAD_STACK_SIZE;


	return 0;
}

int srv_load_conf(srv_conf* p_srv_conf, conf_data* raw_conf) {
	if(p_srv_conf == NULL || raw_conf == NULL) {
		FATAL_LOG("The input parameter is NULL!");
		return -1;
	}

	if(srv_default_conf(p_srv_conf) < 0) {
		WARNING_LOG("Fail to srv_default_conf()!");
		return -1;
	}

	get_conf_nstr(raw_conf, "srv_name", p_srv_conf->name, sizeof(p_srv_conf->name));
	get_conf_uint32(raw_conf, "srv_port", &p_srv_conf->port);
	get_conf_uint32(raw_conf, "srv_thread_num", &p_srv_conf->thread_num);
	get_conf_uint32(raw_conf, "srv_type", &p_srv_conf->srv_type);
	get_conf_uint32(raw_conf, "srv_read_to", &p_srv_conf->read_to);
	get_conf_uint32(raw_conf, "srv_write_to", &p_srv_conf->write_to);
	get_conf_uint32(raw_conf, "srv_connect_to", &p_srv_conf->connect_to);
	get_conf_uint32(raw_conf, "srv_connect_type", &p_srv_conf->connect_type);
	get_conf_uint32(raw_conf, "srv_backlog", &p_srv_conf->backlog);
	get_conf_uint32(raw_conf, "srv_rd_size", &p_srv_conf->read_size);
	get_conf_uint32(raw_conf, "srv_wr_size", &p_srv_conf->write_size);
	get_conf_uint32(raw_conf, "srv_us_size", &p_srv_conf->user_size);
	get_conf_uint32(raw_conf, "pool_sock_arr_size", &p_srv_conf->pool_sock_arr_size);
	get_conf_uint32(raw_conf, "pool_pending_queue_cap", &p_srv_conf->pool_pending_queue_cap);
	get_conf_uint32(raw_conf, "srv_stack_size", &p_srv_conf->srv_stack_size);

	if(strlen(p_srv_conf->name) == 0) {
		snprintf(p_srv_conf->name, sizeof(p_srv_conf->name), "%s", "ServerPool");
	}
	if(p_srv_conf->backlog == 0) {
		p_srv_conf->backlog = SRV_DEFAULT_BACKLOG;
	}
	if(p_srv_conf->connect_type == 0) {
		p_srv_conf->connect_type = SHORT_CONNECT;
	}
	if(p_srv_conf->read_to == 0) {
		p_srv_conf->read_to = SRV_DEFAULT_RD_TO;
	}
	if(p_srv_conf->srv_type == 0) {
		p_srv_conf->srv_type = SELECT_POOL;
	}else if(p_srv_conf->srv_type == 1) {
		p_srv_conf->srv_type = EPOLL_POOL;
	}
	if(p_srv_conf->write_to == 0) {
		p_srv_conf->write_to = SRV_DEFAULT_WR_TO;
	}

	if(p_srv_conf->read_size == 0) {
		p_srv_conf->read_size = SRV_DEFAULT_RD_SIZE;
	}
	if(p_srv_conf->write_size == 0) {
		p_srv_conf->write_size = SRV_DEFAULT_WR_SIZE;
	}
	if(p_srv_conf->user_size == 0) {
		p_srv_conf->user_size = SRV_DEFAULT_US_SIZE;
	}
	if(p_srv_conf->srv_stack_size < 8*1024*1024) {
		p_srv_conf->srv_stack_size = SRV_DEFAULT_THREAD_STACK_SIZE;
	}

	return 0;
}

//int srv_clear_thread_data(srv_thread_data* p_data, unsigned int thread_num) {
//
//	if(p_data != NULL) {
//		for(unsigned int i = 0; i < thread_num; i++) {
//			if(p_data[i].read_buf != NULL) {
//				free(p_data[i].read_buf);
//				p_data[i].read_buf = NULL;
//			}
//			if(p_data[i].write_buf != NULL) {
//				free(p_data[i].write_buf);
//				p_data[i].write_buf = NULL;
//			}
//			if(p_data[i].user_buf != NULL) {
//				free(p_data[i].user_buf);
//				p_data[i].user_buf = NULL;
//			}
//		}
//		free(p_data);
//		p_data = NULL;
//	}
//	return 0;
//}

int srv_set_rw_data(srv_unit* srv, void** read_buf, unsigned int read_size,
					void** write_buf, unsigned int write_size) {
	if(srv == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}
	if(srv->srv_thread_num == 0) {
		FATAL_LOG("Please set thread_num firstly!");
		return -1;
	}
	int thread_num = srv->srv_thread_num;

	for(int i = 0; i < (int) thread_num; i++) {
		if(srv->srv_data[i].read_buf != NULL || srv->srv_data[i].write_buf != NULL) {
			WARNING_LOG("Already set read buffer or write buffer early! Can't set again!");
			return -1;
		}
		srv->srv_data[i].id = i;
		if(read_buf != NULL) {
			srv->srv_data[i].read_buf = read_buf[i];
		}
		if(write_buf != NULL) {
			srv->srv_data[i].write_buf = write_buf[i];
		}
		srv->srv_data[i].read_size = read_size;
		srv->srv_data[i].write_size = write_size;
	}

	return 0;
}

int srv_set_sock_arr_size(srv_unit* srv, unsigned int arr_size) {
	if(srv == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}
	srv->pool_sock_arr_size = arr_size;
	return 0;
}

int srv_set_pending_queue_cap(srv_unit* srv, unsigned int cap) {
	if(srv == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}
	srv->pool_pending_queue_cap = cap;
	return 0;
}

int srv_set_stack_size(srv_unit* srv, unsigned int stack_size) {
	if(srv == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}
	srv->srv_stack_size = stack_size;
	return 0;
}

srv_unit* srv_create(srv_conf* p_srv_conf) {

	if(p_srv_conf == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return NULL;
	}

	srv_unit* srv = (srv_unit*) calloc(1, sizeof(srv_unit));
	if(srv == NULL) {
		FATAL_LOG("Fail to calloc memory for srv_unit!");
		return NULL;
	}

	srv_set_backlog(srv, p_srv_conf->backlog);
	srv_set_name(srv, p_srv_conf->name);
	srv_set_port(srv, p_srv_conf->port);
	srv_set_timeout(srv, p_srv_conf->read_to, p_srv_conf->write_to, p_srv_conf->connect_to);
	srv_set_conn_type(srv, p_srv_conf->connect_type);
	srv_set_srv_type(srv, p_srv_conf->srv_type);
	srv_set_thread_num(srv, p_srv_conf->thread_num);
	srv_set_sock_arr_size(srv, p_srv_conf->pool_sock_arr_size);
	srv_set_pending_queue_cap(srv, p_srv_conf->pool_pending_queue_cap);
	srv_set_stack_size(srv, p_srv_conf->srv_stack_size);

	srv->srv_data = NULL;

	srv->srv_data = (srv_thread_data*) calloc(srv->srv_thread_num, sizeof(srv_thread_data));
	if(srv->srv_data == NULL) {
		FATAL_LOG("Fail to calloc memory for srv_thread_data");
		if(srv != NULL) {
			free(srv);
			srv = NULL;
		}
		return NULL;
	}
	signal(SIGPIPE, SIG_IGN);

	return srv;
}

int srv_set_user_data(srv_unit* srv, void** user_buf, unsigned int user_size) {

	if(srv == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}
	if(srv->srv_thread_num == 0) {
		FATAL_LOG("Please execute srv_create() firstly!");
		return -1;
	}
	if(srv->srv_data == NULL) {
		FATAL_LOG("Please srv_create() firstly!");
		return -1;
	}

	for(int i = 0; i < (int) srv->srv_thread_num; i++) {
		if(user_buf != NULL) {
			srv->srv_data[i].user_buf = user_buf[i];
		}
		srv->srv_data[i].user_size = user_size;
	}

	return 0;
}

int srv_set_name(srv_unit* srv, const char* name) {
	if(srv == NULL || name == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}
	snprintf(srv->srv_name, sizeof(srv->srv_name), "%s", name);
	return 0;
}

int srv_set_port(srv_unit* srv, const unsigned int port) {
	if(srv == NULL || port < 1024) {
		WARNING_LOG("The input parameter is NULL or illegal!");
		return -1;
	}
	srv->srv_port = port;
	return 0;
}

int srv_set_backlog(srv_unit* srv, const unsigned int backlog) {
	if(srv == NULL) {
		WARNING_LOG("The input parameter is NULL or illegal!");
		return -1;
	}

	if(backlog == 0) {
		srv->srv_backlog = SRV_DEFAULT_BACKLOG;
	}else{
		srv->srv_backlog = backlog;
	}

	return 0;
}

int srv_set_timeout(srv_unit* srv, const unsigned int read_to,
					const unsigned int write_to, const unsigned int conn_to) {
	if(srv == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}
	srv->srv_read_to = read_to;
	srv->srv_write_to = write_to;
	srv->srv_connect_to = conn_to;
	return 0;
}

int srv_get_conn_timeout(srv_unit* srv) {
	if(srv == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}

	return srv->srv_connect_to;
}
int srv_set_conn_type(srv_unit* srv, const unsigned int connect_type) {
	if(srv == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}
	srv->srv_connect_type = connect_type;
	return 0;
}

int srv_get_conn_type(srv_unit* srv) {
	if(srv == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}

	return srv->srv_connect_type;
}

int srv_set_srv_type(srv_unit* srv, const unsigned int type) {
	if(srv == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}
	srv->srv_type = type;
	return 0;
}

int srv_set_thread_num(srv_unit* srv, const unsigned int thread_num) {
	if(srv == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}
	srv->srv_thread_num = thread_num;
	return 0;
}

int srv_set_call_back(srv_unit* srv, call_back_func cb_func) {
	if(srv == NULL || cb_func == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}
	srv->cb_fun = cb_func;
	return 0;
}

int srv_run(srv_unit* srv) {
	if(srv == NULL) {
		FATAL_LOG("The input parameter is NULL!");
		return -1;
	}
	if(srv->srv_thread_num == 0 || srv->srv_data == NULL) {
		FATAL_LOG("Please execute srv_create() firstly!");
		return -1;
	}

	for(int i = 0; i < (int) srv->srv_thread_num; i++) {
		if(srv->srv_data[i].read_buf == NULL) {
			srv->srv_data[i].read_buf = calloc(srv->srv_data[i].read_size, sizeof(char));
			if(srv->srv_data[i].read_buf == NULL) {
				FATAL_LOG("Fail to calloc memory for read_buf!");
				return -1;
			}
		}
		if(i == 0) {
			DEBUG_LOG("[%d] read_buf size:[%d]", i, srv->srv_data[i].read_size);
		}
		if(srv->srv_data[i].write_buf == NULL) {
			srv->srv_data[i].write_buf = calloc(srv->srv_data[i].write_size, sizeof(char));
			if(srv->srv_data[i].write_buf == NULL) {
				FATAL_LOG("Fail to calloc memory for write_buf!");
				return -1;
			}
		}
		if(i == 0) {
			DEBUG_LOG("[%d] write_buf size:[%d]", i, srv->srv_data[i].write_size);
		}
		if(srv->srv_data[i].user_buf == NULL) {
			srv->srv_data[i].user_buf = calloc(srv->srv_data[i].user_size, sizeof(char));
			if(srv->srv_data[i].user_buf == NULL) {
				FATAL_LOG("Fail to calloc memory for user_buf!");
				return -1;
			}
		}
		if(i == 0) {
			DEBUG_LOG("[%d] user_buf size:[%d]", i, srv->srv_data[i].user_size);
		}
		srv->srv_data[i].parent = srv;
	}

	int on = 1;
	struct sockaddr_in srv_addr;
	memset(&srv_addr, 0, sizeof(struct sockaddr_in));

	if(g_pool[srv->srv_type].init(srv) < 0) {
		FATAL_LOG("Fail to init srv_pool!");
		goto err_exit;
	}


	srv->srv_sock = socket(PF_INET, SOCK_STREAM, 0);
	if(srv->srv_sock < 0) {
		FATAL_LOG("Fail to create socket! err:[%s]", strerror(errno));
		goto err_exit;
	}


	setsockopt(srv->srv_sock, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));

	srv_addr.sin_family = AF_INET;
	srv_addr.sin_port = htons(srv->srv_port);
	srv_addr.sin_addr.s_addr = htonl(INADDR_ANY);

	if(bind(srv->srv_sock, (struct sockaddr*) &srv_addr, sizeof(srv_addr)) < 0) {
		FATAL_LOG("Fail to bind socket port[%u]! err:[%s]", srv->srv_port, strerror(errno));
		goto err_exit;
	}

	if(listen(srv->srv_sock, srv->srv_backlog) < 0) {
		close(srv->srv_sock);
		FATAL_LOG("Fail to listen port[%u]! err:[%s]", srv->srv_port, strerror(errno));
		goto err_exit;
	}

	NOTICE_LOG("Success Bind Listen Port[%u]", srv->srv_port);
	srv->srv_is_run = 1;
	if(g_pool[srv->srv_type].run(srv) < 0) {
		FATAL_LOG("Fail to run srv_pool!");
		goto err_exit;
	}

	return 0;

err_exit:
	for(int i = 0; i < (int) srv->srv_thread_num; i++) {
		if(srv->srv_data[i].read_buf != NULL) {
			free(srv->srv_data[i].read_buf);
			srv->srv_data[i].read_buf = NULL;
		}
		if(srv->srv_data[i].write_buf != NULL) {
			free(srv->srv_data[i].write_buf);
			srv->srv_data[i].write_buf = NULL;
		}
		if(srv->srv_data[i].user_buf != NULL) {
			free(srv->srv_data[i].user_buf);
			srv->srv_data[i].user_buf = NULL;
		}
	}
	return -1;

}

int srv_read_core(int sock, void* buf, unsigned int len, unsigned int time_out) {
	if(buf == NULL) {
		WARNING_LOG("Input parameter read_buffer is NULL!");
		return -1;
	}
	struct timeval tv;
	tv.tv_sec = time_out / 1000;
	tv.tv_usec = (time_out % 1000) * 1000;

	fd_set read_fs;
	unsigned int left_len = len;
	int read_len = 0;
	char* cursor = (char*) buf;

	while(left_len > 0) {
		read_len = 0;
		FD_ZERO(&read_fs);
		FD_SET(sock, &read_fs);

		int ret = select(sock+1, &read_fs, NULL, NULL, &tv);
		if(ret < 0) {//error
			if(errno == EINTR) {
				continue;
			}
			return -1;
		}else if(ret == 0) { //timeout
			errno = ETIMEDOUT;
			return -1;
		}

		read_len = read(sock, cursor, left_len);
		if(read_len == -1) {//error
			return -1;
		}else if(read_len == 0) { // EOF
			break;
		}else {
			cursor += read_len;
			left_len -= read_len;
		}
	}

	return (len - left_len);
}

int srv_write_core(int sock, void* buf, unsigned int len, unsigned int time_out) {
	if(buf == NULL) {
		WARNING_LOG("Input parameter read_buffer is NULL!");
		return -1;
	}
	struct timeval tv;
	tv.tv_sec = time_out / 1000;
	tv.tv_usec = (time_out % 1000) * 1000;

	fd_set write_fs;
	unsigned int left_len = len;
	int write_len = 0;
	char* cursor = (char*) buf;

	if(srv_setsocketnoblock(sock) < 0) {
		return -1;
	}

	while(left_len > 0) {
		FD_ZERO(&write_fs);
		FD_SET(sock, &write_fs);

		int ret = select(sock+1, NULL, &write_fs, NULL, &tv);
		if(ret < 0) {//error
			if(errno == EINTR) {
//				WARNING_LOG("[write] EINTR!");
				continue;
			}
			return -1;
		}else if(ret == 0) { //timeout
			errno = ETIMEDOUT;
//			WARNING_LOG("[write] to peer time out!");
			return -1;
		}

		write_len = write(sock, cursor, left_len);
		if(write_len == -1) {
//			WARNING_LOG("[write] sock[%d], all_len[%d] left_len[%d] err[%s]!", sock, len, left_len, strerror(errno));
			return -1;
		}
		left_len -= write_len;
		cursor += write_len;
	}

	return (len - left_len);
}

int srv_read_sock_in(srv_head* read_head, int time_out) {

	if(read_head == NULL) {
		WARNING_LOG("[read] The input parameter is NULL!");
		return -1;
	}

	srv_thread_data* p_data = (srv_thread_data*) pthread_getspecific(g_pool_key);
	if(p_data == NULL) {
		WARNING_LOG("[read] Fail to pthread_getspecific thread self_data!");
		return -1;
	}

	int sock = p_data->sock;
	if(p_data->sock <= 0) {
		WARNING_LOG("[read] Wrong socket file descriptor!");
		return -1;
	}

	int read_len = 0;
	read_len = srv_read_core(sock, read_head, sizeof(srv_head), time_out);
	if(read_len < 0) {
		WARNING_LOG("[read] Fail to read head_data from socket[%d]!", sock);
		return -1;
	}else if(read_len != sizeof(srv_head)) {
		WARNING_LOG("[read] head error! real_read_size[%d], espect_read_size[%zd]",
					read_len, sizeof(srv_head));
		return -1;
	}

	if(read_head->magic_num != MAGIC_GOD) {
		WARNING_LOG("[read] head_magic_num[%u] is wrong! espect_magic_num[%0X]",
					read_head->magic_num, MAGIC_GOD);
		return -1;
	}

	unsigned int body_len = read_head->body_len;
	if(body_len > p_data->read_size) {
		WARNING_LOG("[read] receive too big body request! real_size[%u], limit_size[%u]",
					 body_len, p_data->read_size);
		return -1;
	}

	read_len = srv_read_core(sock, p_data->read_buf, body_len, time_out);
	if(read_len < 0) {
		WARNING_LOG("[read] Fail to read body_data from socket[%d]!", sock);
		return -1;
	}else if(read_len != (int) body_len) {
		WARNING_LOG("[read] head error! real_read_size[%d], espect_read_size[%d]",
					read_len, body_len);
		return -1;
	}

	return body_len;
}

int srv_write_sock_in(srv_head* write_head, int time_out) {
	if(write_head == NULL) {
		WARNING_LOG("[write] The input parameter is NULL!");
		return -1;
	}

	srv_thread_data* p_data = (srv_thread_data*) pthread_getspecific(g_pool_key);
	if(p_data == NULL) {
		WARNING_LOG("[write] Fail to pthread_getspecific thread self_data!");
		return -1;
	}

	int sock = p_data->sock;
	if(p_data->sock <= 0) {
		WARNING_LOG("[write] Wrong socket file descriptor!");
		return -1;
	}

	if(write_head->magic_num != MAGIC_GOD && write_head->magic_num != MAGIC_TAIL) {
		WARNING_LOG("[write] head_magic_num[%0X] is wrong! espect_magic_num[%0X] or [%0X]",
					write_head->magic_num, MAGIC_GOD, MAGIC_TAIL);
		return -1;
	}

	unsigned int body_len = write_head->body_len;
	if(body_len > p_data->write_size) {
		WARNING_LOG("[write] send too big body response! real_size[%u], limit_size[%u]",
					 body_len, p_data->write_size);
		return -1;
	}


	int write_len = srv_write_core(sock, write_head, sizeof(write_head), time_out);
	if(write_len < 0) {
		WARNING_LOG("[write]Fail to write head into socket[%d]! err[%s]", sock, strerror(errno));
		return -1;
	}else if(write_len != sizeof(write_head)) {
		WARNING_LOG("[write] head error! real_write_size[%d], espect_write_size[%zd]",
				write_len, sizeof(write_head));
		return -1;
	}

	write_len = srv_write_core(sock, p_data->write_buf, body_len, time_out);
	if(write_len < 0) {
		WARNING_LOG("[write] Fail to write body_data into socket[%d]! err[%s]", sock, strerror(errno));
		return -1;
	}else if(write_len != (int)body_len) {
		WARNING_LOG("[write] body data error! real_write_size[%d], espect_write_size[%u]",
					write_len, body_len);
		return -1;
	}

	return body_len;
}

int srv_get_sequence_id(void* src, char* seq_id_buf, int seq_id_buf_len) {
	if(src == NULL || seq_id_buf == NULL || seq_id_buf_len <= 0) {
		WARNING_LOG("[read] The input parameter is NULL!");
		return -1;
	}
	seq_id_buf[0] = '\0';
	char* cursor = NULL;
	char* head =  (char*) src;
	char crlf[3];
	snprintf(crlf, sizeof(crlf), "%c%c", '\r', '\n');

	if((cursor = strstr(head, "Client-SequenceId")) != NULL) {
		char* end = strstr(cursor, crlf);
		if(end != NULL) {
			*end = '\0';
			snprintf(seq_id_buf, seq_id_buf_len, "%s", cursor);
			*end = '\r';
		}
	}
	return 0;
}

int srv_read_sock(int time_out) {
	srv_head read_head;
	memset(&read_head, 0, sizeof(srv_head));

	return srv_read_sock_in(&read_head, time_out);
}
/*
 * mode_type Ϊ1��ʾGET��Ϊ2��ʾPOST
 */
int srv_read_http(int time_out, int& mode_type, char* seq_id_buf, int seq_id_buf_len) {
	srv_thread_data* p_data = (srv_thread_data*) pthread_getspecific(g_pool_key);
	if(p_data == NULL) {
		WARNING_LOG("[read] Fail to pthread_getspecific thread self_data!");
		return -1;
	}

	int sock = p_data->sock;
	if(p_data->sock <= 0) {
		WARNING_LOG("[read] Wrong socket file descriptor!");
		return -1;
	}
	int read_len = srv_read_http_head(sock, p_data->read_buf, p_data->read_size, time_out);
	if(read_len < 0) {
		WARNING_LOG("[read] Fail to read http_data from http socket[%d]!", sock);
		return -1;
	}
	if(seq_id_buf != NULL && srv_get_sequence_id(p_data->read_buf, seq_id_buf, seq_id_buf_len) < 0) {
		WARNING_LOG("[read] Fail to read srv_get_sequence_id from http socket[%d]!", sock);
	}
	/*
	 * ����ֵΪ-1��ʾ������-2��ʾ��http��get������ֵ��ʾ��http��post�����ҷ���ֵ��ʾcontent-len��ֵ
	 */
	int ret = srv_read_http_is_get((char*) p_data->read_buf);
	if(ret == -1 || ret == 0) {
		WARNING_LOG("[read] Fail to parse http_head get or post mode from http socket[%d]!", sock);
		return -1;
	}else if(ret == -2) {
		//��GETģʽ
		char crlf[3];
		snprintf(crlf, sizeof(crlf), "%c%c", '\r', '\n');
		char* request_line = strstr((char*) p_data->read_buf, crlf);
		if(request_line == NULL) {
			WARNING_LOG("The http request is illegal! content:[%s]", (char*) p_data->read_buf);
			return -1;
		}
		*request_line = '\0';

		char* get_ptr = strstr((char*) p_data->read_buf, "GET ");
		if(get_ptr == NULL) {
			*request_line = '\r';
			WARNING_LOG("The http request is illegal! content:[%s]", (char*) p_data->read_buf);
			return -1;
		}
		*request_line = '\r';

		request_line = strchr(get_ptr+4, ' ');
		if(request_line == NULL) {
			WARNING_LOG("The http request is illegal! content:[%s]", (char*) p_data->read_buf);
			return -1;
		}
		*request_line = '\0';

		read_len = snprintf((char*) p_data->read_buf, p_data->read_size, "%s", get_ptr+4);
		if(read_len < 0 || (unsigned int) read_len >= p_data->read_size) {
			*request_line = ' ';
			WARNING_LOG("http request too long! content:[%s]", (char*) p_data->read_buf);
			return -1;
		}
		*request_line = ' ';
		mode_type = 1;
	}else if(ret > 0) {
		//��POSTģʽ, ret��ʾ�����������ֽ���
		if((unsigned int) ret >= p_data->read_size) {
			WARNING_LOG("[read] No enough read buffer[%u] for http request_body data from "
					"socket[%d]! espect request_body len[%d]", p_data->read_size, sock, ret);
			return -1;
		}
		read_len = srv_read_core(sock, p_data->read_buf, ret, time_out);
		if(read_len < 0) {
			WARNING_LOG("[read] Fail to read http request_body data from socket[%d]! espect request_body len[%d]", sock, ret);
			return -1;
		}else if(read_len != ret) {
			WARNING_LOG("[read] read http request_body error! real_read_len[%d], espect request_body_len[%d]",
						read_len, ret);
			return -1;
		}
		mode_type = 2;
	}

	*(((char*) p_data->read_buf)+read_len) = '\0';

	return read_len;
}
/*
 * ����ֵΪ-1��ʾ������-2��ʾ��http��get��������ֵ��ʾ��http��post�����ҷ���ֵ��ʾcontent-len��ֵ
 */
int srv_read_http_is_get(char* src) {
	if(src == NULL) {
		WARNING_LOG("Input parameter src is NULL!");
		return -1;
	}
	char* cursor = NULL;
	char* head = (char*) src;
	char crlf[3];
	int http_content_len = -2;//is_get_mode
	snprintf(crlf, sizeof(crlf), "%c%c", '\r', '\n');

	if((cursor = strstr(head, "Content-Length")) != NULL) {
		cursor = strchr(cursor, ':');
		if(cursor != NULL) {
			char* end = strstr(cursor, crlf);
			if(end != NULL) {
				*end = '\0';
				http_content_len = atoi(cursor+1);
				*end = '\r';
			}
		}
	}

	if(http_content_len == -2) {
		//��GETģʽ
		return -2;
	}else {
		//��POSTģʽ
		return http_content_len;
	}
}
/*
int srv_read_http_head(int sock, void* buf, unsigned int len, unsigned int time_out) {
	if(buf == NULL) {
		WARNING_LOG("Input parameter read_buffer is NULL!");
		return -1;
	}
	char* cursor = (char*) buf;
	int cursor_offset = 0;
	int read_len = 0;
	int each_read_step = 1;
	int crlf_num = 0;

	while(1) {
		if((unsigned int) (cursor_offset+each_read_step) >= len) {
			WARNING_LOG("[read] http_head length is overlap the buffer length[%u]", len);
			return -1;
		}

		read_len = srv_read_core(sock, cursor+cursor_offset, each_read_step, time_out);
		if(read_len != each_read_step) {
			WARNING_LOG("[read] Fail to read http_head from http socket[%d]!", sock);
			return -1;
		}
		if(*(cursor+cursor_offset) == '\r' || *(cursor+cursor_offset) == '\n') {
			crlf_num++;
		}else{
			crlf_num = 0;
		}

		cursor_offset += read_len;
		if(crlf_num == 4) {
			//ͷ������
			*(cursor+cursor_offset) = '\0';
			break;
		}
	}

	return cursor_offset;
}*/

int srv_read_http_head(int sock, void* buf, unsigned int len, unsigned int time_out) {
	if(buf == NULL) {
		WARNING_LOG("Input parameter read_buffer is NULL!");
		return -1;
	}
	char* cursor = (char*) buf;
	int read_len = 0;
	int left_len = len;

	while(1) {
		if(left_len <= 1) {
			WARNING_LOG("[read] http_head length is overlap the buffer length[%u]", len);
			return -1;
		}
		read_len = srv_read_http_line(sock, cursor, left_len, time_out);
		if(read_len < 0) {
			WARNING_LOG("[read] Fail to read http_head from http socket[%d]!", sock);
			return -1;
		}else if(read_len == 0) {
			break;
		}else if(read_len == 2) {
			//������http head��ĩβ����\r\n
			if(cursor[0] == '\r' && cursor[1] == '\n') {
				break;
			}
		}

		cursor += read_len;
		left_len -= read_len;
	}

	cursor[0] = '\0';

	if(left_len == (int) len) {
		//δ��ȡ���κ�����
		return -1;
	}

	return (len - left_len);
}

int srv_write_raw(void* buf, unsigned int buf_len, int time_out) {
	srv_thread_data* p_data = (srv_thread_data*) pthread_getspecific(g_pool_key);
	if(p_data == NULL) {
		WARNING_LOG("[write] Fail to pthread_getspecific thread self_data!");
		return -1;
	}

	int sock = p_data->sock;
	if(p_data->sock <= 0) {
		WARNING_LOG("[write] Wrong socket file descriptor!");
		return -1;
	}
	if(buf == NULL) {
		WARNING_LOG("[write]the buf pointer is NULL! illegal!");
		return -1;
	}
	int write_len = srv_write_core(sock, buf, buf_len, time_out);
	if(write_len < 0) {
		WARNING_LOG("[write] Fail to write into socket[%d]! err[%s]", sock, strerror(errno));
		return -1;
	}else if(write_len != (int)buf_len) {
		WARNING_LOG("[write] body data error! real_write_size[%d], espect_write_size[%u]",
					write_len, buf_len);
		return -1;
	}

	return buf_len;
}

int srv_write_sock(unsigned int body_len, int time_out) {
	srv_head write_head;
	memset(&write_head, 0, sizeof(srv_head));
	write_head.magic_num = MAGIC_GOD;
	write_head.body_len = body_len;

	return srv_write_sock_in(&write_head, time_out);
}

int srv_write_sock_tail(unsigned int body_len, int time_out) {
	srv_head write_tail;
	memset(&write_tail, 0, sizeof(srv_head));
	write_tail.magic_num = MAGIC_TAIL;
	write_tail.body_len = body_len;

	return srv_write_sock_in(&write_tail, time_out);
}

int srv_join(srv_unit* srv) {
	if(srv == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}
	if(g_pool[srv->srv_type].join(srv) < 0) {
		FATAL_LOG("Fail to join srv_pool!");
		return -1;
	}
	return 0;
}

int srv_destroy(srv_unit* srv) {
	if(srv == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}
	srv_join(srv);

	if(srv->srv_sock >= 0) {
		close(srv->srv_sock);
	}
	g_pool[srv->srv_type].destroy(srv);
	if(srv->srv_data != NULL) {
		for(int i = 0; i < (int) srv->srv_thread_num; i++) {
			if(srv->srv_data[i].read_buf != NULL) {
				free(srv->srv_data[i].read_buf);
				srv->srv_data[i].read_buf= NULL;
			}
			if(srv->srv_data[i].write_buf != NULL) {
				free(srv->srv_data[i].write_buf);
				srv->srv_data[i].write_buf = NULL;
			}
			if(srv->srv_data[i].user_buf != NULL) {
				free(srv->srv_data[i].user_buf);
				srv->srv_data[i].user_buf = NULL;
			}
		}
		free(srv->srv_data);
		srv->srv_data = NULL;
	}
	free(srv);
	srv = NULL;
	return 0;
}

int srv_read_http_line(int sock, void* buf, unsigned int len, unsigned int time_out) {
	if(buf == NULL || len == 0) {
		return -1;
	}
	char * cursor = (char*) buf;
	int left_len = (int) len;
	bool is_finish = false;

#define READ_SIZE (32)
	while(left_len > READ_SIZE && !is_finish) {
		int real_peek_len = srv_read_peek(sock, cursor, READ_SIZE, time_out);
		if(real_peek_len < 0) {//�����ݳ���
			return -1;
		}else if(real_peek_len == 0) {
			//������peek��
			break;
		}

		int real_read_len = 0;
		for(int i = 0; i < real_peek_len; i++) {
			if(*(cursor+i) == '\n') {
				real_read_len = srv_read_core(sock, cursor, i+1, time_out);
				if(real_read_len < 0 || real_read_len != i+1) {
					return -1;
				}

				*(cursor+real_read_len) = '\0';

				is_finish = true;
				break;
			}
		}

		if(!is_finish) {
			real_read_len = srv_read_core(sock, cursor, real_peek_len, time_out);
			if(real_read_len < 0 || real_read_len != real_peek_len) {
				return -1;
			}
			*(cursor+real_read_len) = '\0';
		}
		//������Ե�����λ��
		cursor += real_read_len;
		left_len -= real_read_len;
	}
#undef READ_SIZE

	return (len - left_len);
}

int srv_read_peek(int sock, void* buf, unsigned int len, unsigned int time_out) {
	if(buf == NULL) {
		WARNING_LOG("Input parameter read_buffer is NULL!");
		return -1;
	}
	struct timeval tv;
	tv.tv_sec = time_out / 1000;
	tv.tv_usec = (time_out % 1000) * 1000;

	fd_set read_fs;
	unsigned int left_len = len;
	int read_len = 0;
	char* cursor = (char*) buf;

	while(left_len > 0) {
		read_len = 0;
		FD_ZERO(&read_fs);
		FD_SET(sock, &read_fs);

		int ret = select(sock+1, &read_fs, NULL, NULL, &tv);
		if(ret < 0) {//error
			if(errno == EINTR) {
				continue;
			}
			return -1;
		}else if(ret == 0) { //timeout
			errno = ETIMEDOUT;
			return -1;
		}

		read_len = recv(sock, cursor, left_len, MSG_PEEK);
		if(read_len == -1) {//error
			return -1;
		}else if(read_len == 0) { // EOF
			break;
		}else {
			cursor += read_len;
			left_len -= read_len;
		}
	}

	return (len - left_len);
}
