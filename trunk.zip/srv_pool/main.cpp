/*
 * main.cpp
 *
 *  Created on: Oct 29, 2011
 *      Author: wapthen
 */

#include "srv_pool.h"
#include "select_pool.h"
#include "my_log.h"

#define PORT 12345
#define RD_SIZE (5*1024)
#define WR_SIZE (5*1024)
#define THREAD_NUM 1


struct svf {
	char buf[20*1024];
};

int process();

int main() {
	srv_conf conf;
	memset(&conf, 0, sizeof(conf));

	conf.backlog = 50;
	conf.connect_to = 10;
//	conf.connect_type =LONG_CONNECT;
	conf.connect_type =SHORT_CONNECT;
	snprintf(conf.name, sizeof(conf.name), "%s", "server");
	conf.pool_pending_queue_cap = 10;
	conf.pool_sock_arr_size = 20;
	conf.port = PORT;
	conf.read_size = 0;
	conf.read_to = 100;
	conf.srv_stack_size = 5*1024*1024;
	conf.thread_num = THREAD_NUM;
	conf.write_to = 100;
	//conf.srv_type = 0;//select pool
	conf.srv_type = 1;//epoll pool

	if(log_init() < 0) {
		printf("Fail to log_init!\n");
		return -1;
	}
	NOTICE_LOG("START SERVER!!");
	if(log_init_thread_attr() < 0) {
		printf("Fail to log_init_thread_attr()\n");
		return -1;
	}

//	int ret = log_set_notice_info(MY_LOG_SRV_NAME, "%s", "Server");
//	if(ret < 0) {
//		printf("Fail to set notice MY_LOG_SRV_NAME\n");
//		return -1;
//	}

	srv_unit* srv = srv_create(&conf);
	if(srv == NULL) {
		printf("Fail to create server!\n");
		return -1;
	}

	int ret = srv_set_rw_data(srv, NULL, RD_SIZE, NULL, WR_SIZE);
	if(ret < 0) {
		printf("Fail to set_rw_data!\n");
		return -1;
	}

	svf* buf = new svf[THREAD_NUM];
	if(buf == NULL) {
		printf("Fail to new svf!\n");
		return -1;
	}

	ret = srv_set_user_data(srv, (void**)&buf, sizeof(svf));
	if(ret < 0) {
		printf("Fail to srv_set_user_data!\n");
		return -1;
	}

	ret = srv_set_call_back(srv, process);
	if(ret < 0) {
		printf("Fail to srv_set_call_back!\n");
		return -1;
	}

	ret = srv_run(srv);
	if(ret < 0) {
		printf("Fail to srv_run!\n");
		return -1;
	}

	srv_join(srv);

	return 0;
}

int process() {

//	log_set_notice_info(MY_LOG_LOG_ID, "%lu", log_get_logid());
//	svf* p__data = (svf*) srv_get_user_data();
//	if(p_user_data == NULL) {
//		printf("Fail srv_get_thread_data!\n");
//		return -1;
//	}
////	int user_len = srv_get_user_size();

//	char* p_write_data = (char *) srv_get_write_data();
//	int write_len = srv_get_write_size();

//	int aa = srv_read_sock(500);
//	if(aa < 0) {
//		return 0;
//	}
	char* read_data = (char*) srv_get_read_data();
	unsigned int read_size = srv_get_read_size();
	memset(read_data, 0, read_size);

	int aa = 0;
	errno = 0;
	int mode_type = 0;
	aa = srv_read_http(500, mode_type);
//	if(aa < 0) {
//		return 0;
//	}

	NOTICE_LOG("Read:[%s], err[%s]", read_data, strerror(errno));


//	snprintf(p_write_data, write_len, "%s", "#######SUCCESS######");
//
//
//	srv_write_sock(strlen(p_write_data)+1, 500);
//
//	char ip_str[128];
//	struct in_addr tmp_ip;
//	bzero(&tmp_ip, sizeof(struct in_addr));
//	tmp_ip.s_addr = srv_get_thread_data()->ip;
//	inet_ntop(AF_INET, (void*)&tmp_ip, ip_str, sizeof(ip_str));
//	NOTICE_LOG("ip[%s]", ip_str);
//	NOTICE_LOG("Success send the response!");

	return 0;
}
