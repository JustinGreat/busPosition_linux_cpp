/*
 * select_pool.h
 *
 *  Created on: Oct 25, 2011
 *      Author: wapthen
 */

#ifndef SELECT_POOL_H_
#define SELECT_POOL_H_

#include <pthread.h>
#include <unistd.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <queue>
#include "srv_struct.h"

typedef struct _s_pool_t {
	fd_set pool_set;

	std::queue<int> *pool_ready_queue;
	unsigned int pool_ready_queue_cap;

	q_unit* pool_sock_arr;
	unsigned int pool_sock_arr_size;

	struct timeval pool_check_interval;
	int pool_timeout; //��λΪs

	pthread_t pool_pthread;
	pthread_mutex_t ready_mutex;
	pthread_cond_t ready_cond;

} s_pool;

int init_spool(srv_unit* srv);
int run_spool(srv_unit* srv);
int destroy_spool(srv_unit* srv);
int join_spool(srv_unit* srv);



#endif /* SELECT_POOL_H_ */
