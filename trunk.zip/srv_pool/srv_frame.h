/*
 * srv_frame.h
 *
 *  Created on: Oct 29, 2011
 *      Author: wapthen
 */

#ifndef SRV_FRAME_H_
#define SRV_FRAME_H_

#include "select_pool.h"
#include "epoll_pool.h"

typedef int (*init_pool) (srv_unit*);
typedef int (*run_pool) (srv_unit*);
typedef int (*join_pool) (srv_unit*);
typedef int (*destroy_pool) (srv_unit*);

typedef struct _srv_pool{
	init_pool init;
	run_pool run;
	join_pool join;
	destroy_pool destroy;
} srv_pool;

static const srv_pool g_pool[] = {
		{init_spool, run_spool, join_spool, destroy_spool},
		{init_epool, run_epool, join_epool, destroy_epool},
};


#endif /* SRV_FRAME_H_ */
