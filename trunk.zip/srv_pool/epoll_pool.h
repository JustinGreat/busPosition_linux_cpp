/*
 * epoll_pool.h
 *
 *  Created on: Jul 5, 2012
 *      Author: wapthen
 */

#ifndef EPOLL_POOL_H_
#define EPOLL_POOL_H_

#include <pthread.h>
#include <unistd.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <queue>
#include <sys/epoll.h>

#include "srv_struct.h"


typedef struct _e_pool_t {
	int pool_ep;
	struct epoll_event *pool_ep_events;
	unsigned int pool_ep_events_size;

	std::queue<int> *pool_ready_queue;
	unsigned int pool_ready_queue_cap;

	q_unit* pool_sock_arr;
	unsigned int pool_sock_arr_size;

	int pool_listen_index;

	int pool_check_interval;
	int pool_timeout; //epoll�ĳ�ʱʱ�䵥λΪs
	time_t pool_next_check_time;

	pthread_t pool_pthread;
	pthread_mutex_t ready_mutex;
	pthread_cond_t ready_cond;

} e_pool;

int init_epool(srv_unit* srv);
int run_epool(srv_unit* srv);
int destroy_epool(srv_unit* srv);
int join_epool(srv_unit* srv);

#endif /* EPOLL_POOL_H_ */
