/*
 * epoll_pool.cpp
 *
 *  Created on: Jul 5, 2012
 *      Author: wapthen
 */
#include "epoll_pool.h"
#include "srv_pool.h"
#include "srv_frame.h"
#include "my_log.h"

#define IP_BUF_LEN (128)
#define E_DEFAULT_READY_Q_SIZE (100)
#define E_DEFAULT_SOCK_ARR_SIZE (500)
#define E_DEFAULT_CHK_INTERVAL (10) //ms
#define E_DEFAULT_CONN_TIMEOUT (60) //s


int add_sock_arr(e_pool* p_ep, int new_client, in_addr_t client_addr);
int ep_add(e_pool* p_ep, int idle_index);
int ep_del(e_pool* p_ep, int index);
void* produce_epool(void* param);
int check_timeout(e_pool* p_ep);
void e_produce(srv_unit* srv);
void* work_epool(void* param);
void e_work(srv_unit* srv, srv_thread_data* data);

int init_epool(srv_unit* srv) {

	if(srv->pool != NULL) {
		FATAL_LOG("Already init_epool!");
		return -1;
	}
	e_pool* p_ep = NULL;
	srv->pool = calloc(1, sizeof(e_pool));
	if(srv->pool == NULL) {
		FATAL_LOG("Fail to calloc memory for epool!");
		goto err_exit;
	}

	p_ep = (e_pool*) srv->pool;
	p_ep->pool_ready_queue = new std::queue<int>;
	if(p_ep->pool_ready_queue == NULL) {
		FATAL_LOG("Fail to new memory for pool_ready_queue!");
		goto err_exit;
	}

	p_ep->pool_ready_queue_cap = srv->pool_pending_queue_cap;
	if(p_ep->pool_ready_queue_cap == 0) {
		p_ep->pool_ready_queue_cap = E_DEFAULT_READY_Q_SIZE;
	}

	p_ep->pool_sock_arr_size = srv->pool_sock_arr_size;
	if(p_ep->pool_sock_arr_size == 0) {
		p_ep->pool_sock_arr_size = E_DEFAULT_SOCK_ARR_SIZE;
	}
	p_ep->pool_ep_events_size = p_ep->pool_sock_arr_size;

	p_ep->pool_sock_arr = (q_unit *) calloc(p_ep->pool_sock_arr_size, sizeof(q_unit));
	if(p_ep->pool_sock_arr == NULL) {
		FATAL_LOG("Fail to calloc memory for pool_sock_arr!");
		goto err_exit;
	}
	for(unsigned int i = 0; i < p_ep->pool_sock_arr_size; i++) {
		p_ep->pool_sock_arr[i].sock = -1;
		p_ep->pool_sock_arr[i].status = IDLE;
		p_ep->pool_sock_arr[i].ip = 0;
	}

	p_ep->pool_ep_events = (struct epoll_event*) calloc(p_ep->pool_ep_events_size, sizeof(struct epoll_event));
	if(p_ep->pool_ep_events == NULL) {
		FATAL_LOG("Fail to calloc memory for pool_ep_events!");
		goto err_exit;
	}
	p_ep->pool_ep = epoll_create(p_ep->pool_ep_events_size);
	if(p_ep->pool_ep < 0) {
		FATAL_LOG("Fail to create epoll! err[%s]", strerror(errno));
		goto err_exit;
	}

	p_ep->pool_check_interval = E_DEFAULT_CHK_INTERVAL;

	p_ep->pool_timeout = srv_get_conn_timeout(srv) / 1000;
	if(p_ep->pool_timeout <= 0) {
		p_ep->pool_timeout = E_DEFAULT_CONN_TIMEOUT;
	}

	pthread_mutex_init(&p_ep->ready_mutex, NULL);
	pthread_cond_init(&p_ep->ready_cond, NULL);

	NOTICE_LOG("========SUCCESS FINISH INIT EPOLL_POOL SERVER!========");
	return 0;

err_exit:
	if(srv->pool != NULL) {
		free(srv->pool);
		srv->pool = NULL;
	}
	if(p_ep->pool_ready_queue != NULL) {
		delete p_ep->pool_ready_queue;
		p_ep->pool_ready_queue = NULL;
	}
	if(p_ep->pool_sock_arr != NULL) {
		free(p_ep->pool_sock_arr);
		p_ep->pool_sock_arr = NULL;
	}
	if(p_ep->pool_ep_events != NULL) {
		free(p_ep->pool_ep_events);
		p_ep->pool_ep_events = NULL;
	}
	if(p_ep->pool_ep > 0) {
		close(p_ep->pool_ep);
	}
	return -1;

}

int run_epool(srv_unit* srv) {
	if(srv == NULL) {
		FATAL_LOG("The input parameter is NULL!");
		return -1;
	}
	if(srv->pool == NULL) {
		FATAL_LOG("server pool is NULL! Please firstly init_epool()!");
		return -1;
	}

	e_pool* p_ep = (e_pool*) srv->pool;
	if(srv->srv_stack_size > 0) {
		pthread_attr_t thread_attr;
		if(pthread_attr_init(&thread_attr) != 0) {
			WARNING_LOG("Fail to init pthread_attr_t!");
			return -1;
		}
		if(pthread_attr_setstacksize(&thread_attr, srv->srv_stack_size) != 0) {
			WARNING_LOG("Fail to pthread_attr_setstacksize!");
			pthread_attr_destroy(&thread_attr);
			return -1;
		}
		if(pthread_create(&p_ep->pool_pthread, &thread_attr, produce_epool, srv) != 0) {
			WARNING_LOG("Fail to pthread_create produce_epool!");
			pthread_attr_destroy(&thread_attr);
			return -1;
		}

		pthread_attr_destroy(&thread_attr);
	}else{
		if(pthread_create(&p_ep->pool_pthread, NULL, produce_epool, srv) != 0) {
			WARNING_LOG("Fail to pthread_create produce_epool!");
			return -1;
		}
	}

	for(unsigned int i = 0; i < srv->srv_thread_num; i++) {
		srv->srv_data[i].id = i;
		if(srv->srv_stack_size > 0) {
			pthread_attr_t thread_attr;
			if(pthread_attr_init(&thread_attr) != 0) {
				WARNING_LOG("Fail to init pthread_attr_t!");
				return -1;
			}
			if(pthread_attr_setstacksize(&thread_attr, srv->srv_stack_size) != 0) {
				WARNING_LOG("Fail to pthread_attr_setstacksize!");
				pthread_attr_destroy(&thread_attr);
				return -1;
			}
			if(pthread_create(&srv->srv_data[i].pid, &thread_attr, work_epool, &srv->srv_data[i]) != 0) {
				WARNING_LOG("Fail to pthread_create worker_epool!");
				pthread_attr_destroy(&thread_attr);
				return -1;
			}

			pthread_attr_destroy(&thread_attr);
		}else{
			if(pthread_create(&srv->srv_data[i].pid, NULL, work_epool, &srv->srv_data[i]) != 0) {
				WARNING_LOG("Fail to pthread_create worker_epool!");
				return -1;
			}
		}
	}

	return 0;

}

int join_epool(srv_unit* srv) {
	if(srv == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return -1;
	}

	e_pool* p_ep = (e_pool*) srv->pool;
	if(p_ep == NULL) {
		return -1;
	}

	pthread_join(p_ep->pool_pthread, NULL);

	for(unsigned int i = 0; i < srv->srv_thread_num; i++) {
		pthread_join(srv->srv_data[i].pid, NULL);
	}

	return 0;
}

int add_sock_arr(e_pool* p_ep, int new_client, in_addr_t client_addr) {

	int idle_index = -1;
	for(unsigned int i = 0; i < p_ep->pool_sock_arr_size; i++) {
		if(p_ep->pool_sock_arr[i].status == IDLE) {
			idle_index = i;
			break;
		}
	}
	if(idle_index < 0) {
		WARNING_LOG("server socket array is full! limit_num[%u], close socket[%d]",
					p_ep->pool_sock_arr_size,
					new_client);
		return -1;
	}

	p_ep->pool_sock_arr[idle_index].sock = new_client;
	time(&(p_ep->pool_sock_arr[idle_index].last_active));
	p_ep->pool_sock_arr[idle_index].status = READY;
	p_ep->pool_sock_arr[idle_index].ip = client_addr;

	if(ep_add(p_ep, idle_index) < 0) {
		WARNING_LOG("Fail to epoll_ctl add socket[%d]", new_client);
		return -1;
	}

	return idle_index;
}

int ep_add(e_pool* p_ep, int idle_index) {
	if(p_ep == NULL || idle_index < 0) {
		WARNING_LOG("The input parameter is illegal!");
		return -1;
	}
	if(p_ep->pool_ep < 0) {
		WARNING_LOG("illegal epoll fd[%d]", p_ep->pool_ep);
		return -1;
	}
	struct epoll_event ev;
	memset(&ev, 0, sizeof(struct epoll_event));
	ev.events = EPOLLIN | EPOLLHUP | EPOLLERR;
	ev.data.fd = idle_index;
	int new_sock = p_ep->pool_sock_arr[idle_index].sock;
	if(epoll_ctl(p_ep->pool_ep, EPOLL_CTL_ADD, new_sock, &ev) < 0) {
		WARNING_LOG("Fail to epoll_ctl add socket[%d], err[%s]", new_sock, strerror(errno));
		return -1;
	}

	return 0;
}

int ep_del(e_pool* p_ep, int index) {
	if(p_ep == NULL || index < 0) {
		WARNING_LOG("The input parameter is illegal!");
		return -1;
	}
	if(p_ep->pool_ep < 0) {
		WARNING_LOG("illegal epoll fd[%d]", p_ep->pool_ep);
		return -1;
	}
	struct epoll_event ev;
	ev.events = EPOLLIN | EPOLLHUP | EPOLLERR;
	ev.data.fd = index;
	int new_sock = p_ep->pool_sock_arr[index].sock;
	if(epoll_ctl(p_ep->pool_ep, EPOLL_CTL_DEL, new_sock, &ev) < 0) {
		WARNING_LOG("Fail to epoll_ctl delete socket[%d], err[%s]", new_sock, strerror(errno));
		return -1;
	}

	return 0;
}

void* produce_epool(void* param) {
	srv_unit* srv = (srv_unit*) param;

	log_init_thread_attr();
	log_set_notice_info(MY_LOG_SRV_NAME, "%s", srv->srv_name);
	srv_setsocketnoblock(srv->srv_sock);
	e_pool* p_ep = (e_pool*) srv->pool;
	int listen_index = add_sock_arr(p_ep, srv->srv_sock, (in_addr_t) 0);
	if(listen_index < 0) {
		WARNING_LOG("Fail to add listen socket into array! err[%s]", strerror(errno));
		log_destroy_thread_attr();
		pthread_exit(NULL);
		return NULL;
	}
	p_ep->pool_sock_arr[listen_index].status = BUSY;
	p_ep->pool_listen_index = listen_index;
	NOTICE_LOG("Start produce thread!");
	while(srv->srv_is_run) {
		e_produce(srv);
	}
	log_destroy_thread_attr();
	pthread_exit(NULL);
	return NULL;
}

int check_timeout(e_pool* p_ep) {
	time_t cur_time = 0;
	time(&cur_time);
	if (cur_time < p_ep->pool_next_check_time) {
		return 0;
	}
	p_ep->pool_next_check_time = cur_time + p_ep->pool_timeout;
	time_t local_time = 0;
	for(int i = 0; i < (int)p_ep->pool_sock_arr_size; ++i) {
		switch (p_ep->pool_sock_arr[i].status) {
		case IDLE:
			break;
		case READY:
			local_time = p_ep->pool_sock_arr[i].last_active + p_ep->pool_timeout;
			if (cur_time >= local_time) {
				char ip_str[IP_BUF_LEN];
				struct in_addr tmp_ip;
				bzero(&tmp_ip, sizeof(struct in_addr));
				tmp_ip.s_addr = p_ep->pool_sock_arr[i].ip;
				if(inet_ntop(AF_INET, (void*) &tmp_ip, ip_str, IP_BUF_LEN) == NULL) {
					WARNING_LOG("sock[%d] Fail to inet_ntop! err[%s]",
								 p_ep->pool_sock_arr[i].sock, strerror(errno));
				}else {
					WARNING_LOG("sock[%d] ip[%s] in ready queue timeout! will be closed!",
								 p_ep->pool_sock_arr[i].sock, ip_str);
				}
				if(p_ep->pool_sock_arr[i].sock >= 0) {
					close(p_ep->pool_sock_arr[i].sock);
					p_ep->pool_sock_arr[i].sock = -1;
				}
				p_ep->pool_sock_arr[i].status = IDLE;
				p_ep->pool_sock_arr[i].last_active = 0;
			} else if (p_ep->pool_next_check_time > local_time) {
				p_ep->pool_next_check_time = local_time;
			}

			break;
		case BUSY:
			p_ep->pool_sock_arr[i].last_active = cur_time;
			break;
		}
	}
	return 0;
}

void e_produce(srv_unit* srv) {
	if(srv == NULL) {
		FATAL_LOG("srv_unit is NULL!");
		return;
	}
	e_pool* p_ep = (e_pool*) srv->pool;

	check_timeout(p_ep);

	int num = epoll_wait(p_ep->pool_ep, p_ep->pool_ep_events, p_ep->pool_ep_events_size, p_ep->pool_check_interval);
	if(num <= 0) {
		return;
	}
	for(int i = 0; i < num; i++) {
		//handl new client tcp connection
		if(p_ep->pool_ep_events[i].data.fd == p_ep->pool_listen_index) {
			struct sockaddr_in client_addr;
			unsigned int client_addr_len = sizeof(client_addr);
			int new_client = accept(srv->srv_sock, (struct sockaddr*) &client_addr, &client_addr_len);
			if(new_client >= 0) {
				srv_setsocketcom(new_client);
				if(add_sock_arr(p_ep, new_client, client_addr.sin_addr.s_addr) >= 0) {
					DEBUG_LOG("new client connect!socket[%d]", new_client);
				}else{
					close(new_client);
				}
			}
		}else if(p_ep->pool_ep_events[i].data.fd >= 0) {
			int index = p_ep->pool_ep_events[i].data.fd;
			if((p_ep->pool_ep_events[i].events & EPOLLHUP)//��ʾ��Ӧ���ļ����������Ҷ�
					|| (p_ep->pool_ep_events[i].events & EPOLLERR)) { //����
				char ip_str[IP_BUF_LEN];
				ip_str[0] = '\0';
				struct in_addr tmp_ip;
				bzero(&tmp_ip, sizeof(struct in_addr));
				tmp_ip.s_addr = p_ep->pool_sock_arr[index].ip;
				inet_ntop(AF_INET, (void*) &tmp_ip, ip_str, IP_BUF_LEN);
				WARNING_LOG("invalid socket[%d] in epoll! from_ip[%s]", p_ep->pool_sock_arr[index].sock, ip_str);
				if(p_ep->pool_sock_arr[index].sock >= 0) {
					close(p_ep->pool_sock_arr[index].sock);
				}
				p_ep->pool_sock_arr[index].sock = -1;
				p_ep->pool_sock_arr[index].status = IDLE;
				p_ep->pool_sock_arr[index].last_active = 0;
			}else if(p_ep->pool_ep_events[i].events & EPOLLIN) { //�ɶ�
				ep_del(p_ep, index);//�������epoll���Ƴ�
				pthread_mutex_lock(&p_ep->ready_mutex);
				if(p_ep->pool_ready_queue->size() >= p_ep->pool_ready_queue_cap) {
					WARNING_LOG("server ready_queue is full! limit_num[%u], close socket[%d]",
							p_ep->pool_ready_queue_cap, p_ep->pool_sock_arr[index].sock);

					pthread_mutex_unlock(&p_ep->ready_mutex);
					if(p_ep->pool_sock_arr[index].sock >= 0) {
						close(p_ep->pool_sock_arr[index].sock);
					}
					p_ep->pool_sock_arr[index].sock = -1;
					p_ep->pool_sock_arr[index].status = IDLE;
					p_ep->pool_sock_arr[index].last_active = 0;
					continue;
				}

				p_ep->pool_ready_queue->push(index);
				p_ep->pool_sock_arr[index].status = BUSY;
				pthread_cond_signal(&p_ep->ready_cond);
				pthread_mutex_unlock(&p_ep->ready_mutex);
			}
		}
	}

	return;
}

void* work_epool(void* param) {
	srv_thread_data* data= (srv_thread_data*) param;
	srv_unit* srv = (srv_unit*) data->parent;
	if(srv == NULL) {
		return NULL;
	}
	log_init_thread_attr();
	log_set_notice_info(MY_LOG_SRV_NAME, "%s", srv->srv_name);
	srv_set_thread_data(data);
	NOTICE_LOG("Start work thread! id[%u]", data->id);

	while(srv->srv_is_run) {
		e_work(srv, data);
	}
	log_destroy_thread_attr();
	pthread_exit(NULL);
	return NULL;
}

void e_work(srv_unit* srv, srv_thread_data* data) {
	if(srv == NULL) {
		return;
	}
	e_pool* p_ep = (e_pool*) srv->pool;
	if(p_ep == NULL) {
		return;
	}
	pthread_mutex_lock(&p_ep->ready_mutex);
	while(p_ep->pool_ready_queue->empty()) {
		struct timeval cur_time;
		struct timespec timeout;
		gettimeofday(&cur_time, NULL);
		timeout.tv_sec = cur_time.tv_sec + 3;
		timeout.tv_nsec = cur_time.tv_usec * 1000;
		pthread_cond_timedwait(&p_ep->ready_cond, &p_ep->ready_mutex, &timeout);
	}
	int q_index = -1;
	if(!p_ep->pool_ready_queue->empty()) {
		q_index = p_ep->pool_ready_queue->front();
		p_ep->pool_ready_queue->pop();
	}
	pthread_mutex_unlock(&p_ep->ready_mutex);

	if(q_index < 0 || q_index >= (int) p_ep->pool_sock_arr_size) {
		WARNING_LOG("get illegal socket index[%d] from queue!", q_index);
		return;
	}

	data->ip = p_ep->pool_sock_arr[q_index].ip;
	data->sock = p_ep->pool_sock_arr[q_index].sock;
	int ret = srv->cb_fun();

	if(ret == 0 && srv_get_conn_type(srv) == LONG_CONNECT) {
//		WARNING_LOG("sock[%d] Long Connect type!! Still connection!", p_ep->pool_sock_arr[q_index].sock);
		if(p_ep->pool_sock_arr[q_index].status == BUSY) {
			p_ep->pool_sock_arr[q_index].status = READY;
			time(&(p_ep->pool_sock_arr[q_index].last_active));
			ep_add(p_ep, q_index);
		}
	}else{
//		WARNING_LOG("sock[%d] Short Connect type!!", p_ep->pool_sock_arr[q_index].sock);
		if(p_ep->pool_sock_arr[q_index].sock >= 0) {
			close(p_ep->pool_sock_arr[q_index].sock);
		}
		p_ep->pool_sock_arr[q_index].sock = -1;
		p_ep->pool_sock_arr[q_index].status = IDLE;
		p_ep->pool_sock_arr[q_index].last_active = 0;

		data->sock = -1;
		data->ip = 0;
	}

}
int destroy_epool(srv_unit* srv) {
	if(srv == NULL) {
		WARNING_LOG("The input paramter is NULL!");
		return -1;
	}

	e_pool* p_ep = (e_pool*) srv->pool;
	if(p_ep == NULL) {
		return 0;
	}

	pthread_mutex_destroy(&p_ep->ready_mutex);
	pthread_cond_destroy(&p_ep->ready_cond);
	if(p_ep->pool_ready_queue != NULL) {
		delete p_ep->pool_ready_queue;
		p_ep->pool_ready_queue = NULL;
	}
	if(p_ep->pool_sock_arr != NULL) {
		free(p_ep->pool_sock_arr);
		p_ep->pool_sock_arr = NULL;
	}
	if(p_ep->pool_ep_events != NULL) {
		free(p_ep->pool_ep_events);
		p_ep->pool_ep_events = NULL;
	}
	if(p_ep->pool_ep > 0) {
		close(p_ep->pool_ep);
	}
	free(srv->pool);
	srv->pool = NULL;

	return 0;
}
