#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#define PORT 3666
#define IP "127.0.0.1"

int handle(int sock);
int main() {

	struct sockaddr_in srv_addr;
	memset(&srv_addr, 0, sizeof(struct sockaddr_in));

	srv_addr.sin_family = AF_INET;
	srv_addr.sin_port = htons(PORT);
	if (inet_pton(AF_INET, IP, &(srv_addr.sin_addr)) != 1) {
		printf("Fail to inet_pton! err[%s]\n", strerror(errno));
	}

	struct sockaddr_in cli_addr;
	memset(&cli_addr, 0, sizeof(struct sockaddr_in));

	cli_addr.sin_family = AF_INET;
	cli_addr.sin_port = htons(0);
	cli_addr.sin_addr.s_addr = htonl(INADDR_ANY);

	int sock = socket(PF_INET, SOCK_STREAM, 0);
	if (sock < 0) {
		printf("Fail to create socket!\n");
	}

	if (bind(sock, (struct sockaddr*) &(cli_addr), sizeof(struct sockaddr_in))
			== -1) {
		printf("Fail to bind local sockaddr! err[%s]\n", strerror(errno));
		return -1;
	}

	if (connect(sock, (struct sockaddr*) &srv_addr, sizeof(struct sockaddr_in))
			== -1) {
		printf("Fail to connect server[%s:%d]! err[%s]!\n", IP, PORT,
				strerror(errno));
		return -1;
	}

//	char opt[128];
	while (1) {
//		printf("#############\n");
//		printf("1. send msg!\n");
//		printf("2. quit!\n\n");
//
////	fgets(opt, sizeof(opt), stdin);
//		fgets(opt, sizeof(opt), stdin);
//
//		if (atoi(opt) == 2) {
//			break;
//		} else if (atoi(opt) == 1) {
			handle(sock);
//		} else {
//			printf("Wrong Number! Please choose again!\n");
//		}
	}

	if (sock > 0) {
		close(sock);
	}

	return 0;
}
struct head {
	unsigned int magic_num;
	unsigned int body_len;
};

int handle(int sock) {

	char buf[1024];
	memset(buf, 0, sizeof(buf));

	head *hd = (head *) buf;
	hd->magic_num = 0xFFFFEEEE;
	char *body = (char*) (hd+1);
	int ret = snprintf(body, sizeof(buf)-sizeof(head), "%s", "222Hello World!!");
	hd->body_len = ret+1;
	int left_len = sizeof(head)+ret+1;

	ret = send(sock, buf, left_len, 0);
	if (ret == -1) {
		printf("Fail to send msg to server! err[%s]\n",
				strerror(errno));
		return -1;
	}

	printf("Success send msg to server!\n");



	head rcv_head;
	memset(&rcv_head, 0, sizeof(rcv_head));

	char rcv_buf[1024];
	memset(rcv_buf, 0, sizeof(rcv_buf));

	ret = read(sock, &rcv_head, sizeof(rcv_head));
	if (ret == -1) {
		printf("Fail to recv head! err[%s]\n", strerror(errno));
		return -1;
	}

	printf("Recive Body Length:[%u]\n", rcv_head.body_len);

	ret = read(sock, &rcv_buf, rcv_head.body_len);
	printf("Body:[%s]\n", rcv_buf);
	printf("Finish!\n");

	sleep(1);

	return 0;
}

