#include <stdio.h>
#include <stdlib.h>
#include <queue>
#include <errno.h>
#include <string.h>

int main() {
	std::queue<int> myq;
	myq.push(1);
	myq.push(2);
	int a = myq.front();
	printf("%d\n", a);
	myq.pop();
	a = myq.front();
	printf("%d\n", a);
	int i = 10;
	while(i-- > 0) {
	myq.pop();
	a = myq.front();
	printf("%d\n", a);
	}


	fd_set pool_set;
	
while(i++ < 10) {
FD_ZERO(&pool_set);
	FD_SET(6, &pool_set);
	int max_sock = 0;
	struct timeval time_out = {1,0};
	int ret = select(7, &(pool_set), 0, 0, &time_out);
	if(ret <= 0) {
		printf("fail to select! err%s\n", strerror(errno));
		return -1;
	}
	if(FD_ISSET(6, &pool_set)) {
	printf("in pool set!\n");
	}else{
	printf("NOT pool set!\n");
	}
}



















return 0;
}
