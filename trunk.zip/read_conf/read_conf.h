/*
 * read_conf.h
 *
 *  Created on: Oct 21, 2011
 *      Author: wapthen
 */

#ifndef READ_CONF_H_
#define READ_CONF_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#define WORD_SIZE (1024)
#define LINE_SIZE (2048)
#define MIN_LIMIT_NUM (1024)


typedef struct _conf_item {
	char key[WORD_SIZE];
	char value[WORD_SIZE];
} conf_item;

typedef struct _conf_data {
	int real_num;
	int limit_num;
	conf_item* item;
} conf_data;


conf_data* init_conf(int limit_num=MIN_LIMIT_NUM);

int free_conf(conf_data* p_conf);

int read_conf(const char* work_path, const char* file_name, conf_data* p_conf);

int get_conf_int32(conf_data* p_conf, const char* conf_key, int* conf_value);
int get_conf_uint32(conf_data* p_conf, const char* conf_key, unsigned int* conf_value);
int get_conf_int64(conf_data* p_conf, const char* conf_key, long* conf_value);
int get_conf_uint64(conf_data* p_conf, const char* conf_key, unsigned long* conf_value);

int get_conf_nstr(conf_data* p_conf, const char* conf_key, char* conf_value, const size_t len);
int get_conf_float(conf_data* p_conf, const char* conf_key, float* conf_value);


#endif /* READ_CONF_H_ */
