/*
 * main.cpp
 *
 *  Created on: Oct 27, 2011
 *      Author: wapthen
 */

#include "read_conf.h"
conf_data* my_conf = NULL;

int handle(int opt);

int print_usage() {
	printf("USAGE:\n");
	printf("\tread_conf path_of_configure_file file_name\n");
	return 0;
}

int main(int argc, char* argv[]) {
	if(argc != 3) {
		print_usage();
		return -1;
	}

	my_conf = init_conf(2);
	if(my_conf == NULL) {
		printf("Fail to init_conf()\n");
		return -1;
	}

	int ret = read_conf(argv[1], argv[2], my_conf);
	if(ret < 0) {
		printf("Fail to read_conf!");
		free_conf(my_conf);
		return -1;
	}

	int opt = 0;
	while(1) {
		printf("######################\n");
		printf("2: print key-value!\n");
		printf("3: print ALL key-value!\n");
		printf("4: quit!\n\n\n");

		scanf("%d", &opt);
		if(opt == 4) {
			break;
		}
		if(opt>0 && opt<4) {
			handle(opt);
		}

	}
	free_conf(my_conf);
	printf("Successfully Finish!\n");
	return 0;
}

int handle(int opt) {
	char buf[128];
	char v_buf[128];
	if(opt == 2) {
		printf("input key!\n");
		fgets(buf, sizeof(buf), stdin);
		fgets(buf, sizeof(buf), stdin);
		if(buf[0] == '\0') {
			return -1;
		}
		if(buf[strlen(buf)-1] == '\n') {
			buf[strlen(buf)-1] = '\0';
		}
		int ret = get_conf_nstr(my_conf, buf, v_buf, sizeof(v_buf));
		if(ret < 0) {
			printf("Fail to get key[%s]\n", buf);
			return -1;
		}
		printf("value:[%s]\n", v_buf);
		return 0;
	}else if(opt == 3) {
		for(int i = 0; i < my_conf->real_num; i++) {
			printf("[%d] [%s] [%s]\n", i, my_conf->item[i].key, my_conf->item[i].value);
		}
		printf("real_num[%d], limit_num[%d]\n", my_conf->real_num, my_conf->limit_num);
		printf("Success Print All!\n");
		return 0;
	}
	return 0;
}

