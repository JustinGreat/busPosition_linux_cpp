/*
 * read_conf.cpp
 *
 *  Created on: Oct 21, 2011
 *      Author: wapthen
 */

#include "read_conf.h"


#define WARNING_LOG(format, arg...) \
	fprintf(stderr, "[read_conf] [%s:%d]" format "\n", __FILE__, __LINE__, ##arg)

enum LINE_STATUS {
	START,
	GET_KEY,
	OMMIT_SPACE,
	NEW_LINE = 6,
	COLON,
	SUCCESS,
	ERROR,
	GET_VALUE
};


int read_conf_unit(const char* full_path, conf_data* p_conf, int start_item_num);
int read_conf_include(const char* full_path, conf_data* p_conf);


conf_data* init_conf(int limit_num) {
	conf_data* p_conf = NULL;

	p_conf = (conf_data*) calloc(1, sizeof(conf_data));
	if(p_conf == NULL) {
		WARNING_LOG("Fail to calloc memory! err:[%s]", strerror(errno));
		return NULL;
	}

	p_conf->limit_num = limit_num;
	if(limit_num < MIN_LIMIT_NUM) {
		p_conf->limit_num = MIN_LIMIT_NUM;
	}

	p_conf->item = (conf_item*) calloc(p_conf->limit_num, sizeof(conf_item));
	if(p_conf->item == NULL) {
		WARNING_LOG("Fail to calloc memory! err:[%s]", strerror(errno));
		return NULL;
	}

	return p_conf;
}

int free_conf(conf_data* p_conf) {
	if(p_conf != NULL) {
		if(p_conf->item != NULL) {
			free(p_conf->item);
			p_conf->item = NULL;
		}
		free(p_conf);
		p_conf = NULL;
	}
	return 0;
}

int read_conf(const char* work_path, const char* file_name, conf_data* p_conf) {
	if(work_path == NULL || file_name == NULL || p_conf == NULL) {
		WARNING_LOG("The input parameters for read_conf() is illegal!");
		return -1;
	}
	char total_name[LINE_SIZE];
	snprintf(total_name, sizeof(total_name), "%s/%s", work_path, file_name);
	int ret = read_conf_unit(total_name, p_conf, 0);
	if(ret < 0) {
		WARNING_LOG("read_conf failed!");
		return -1;
	}

	return read_conf_include(work_path, p_conf);
}

int read_conf_unit(const char* full_path, conf_data* p_conf, int start_item_num) {
	if(full_path == NULL || p_conf == NULL) {
		WARNING_LOG("The input parameter for read_conf_unit() is illegal!\n");
		return -1;
	}

	FILE* fp = NULL;
	fp = fopen(full_path, "r");
	if(fp == NULL) {
		WARNING_LOG("Fail to open file:[%s],err:[%s]", full_path, strerror(errno));
		return -1;
	}

	char tmp_key[WORD_SIZE];
	char tmp_value[WORD_SIZE];
	char file_line[LINE_SIZE];
	int cur_item_num = start_item_num;
	int len = 0;
	int line_num = 0;

	while(fgets(file_line, sizeof(file_line), fp) != NULL) {
		tmp_key[0] = '\0';
		tmp_value[0] = '\0';
		if(cur_item_num >= p_conf->limit_num) {
			WARNING_LOG("Error! the configure_num is over than limit_num[%d] [%s]\n", p_conf->limit_num, full_path);
			fclose(fp);
			fp = NULL;
			return -1;
		}
		line_num++;
		int index = 0;
		len = strlen(file_line);
		while(index < len && (file_line[index] == ' ' || file_line[index] == '\t')) {
			index++;
		}
		if(index >= len) {
			continue;
		}
		if(file_line[index] == '#') {
			continue;
		}


		LINE_STATUS status = START;
		int j = 0;
		bool sep_sign = false;

		for(int i = index; i <= len-index && status != ERROR && status != SUCCESS; i++) {
			char letter = file_line[i];

			switch(status) {
			case START:
			{
				if(letter == ' ' || letter == '\t') {
					break;
				}else if(letter == '\r' || letter == '\n') {
					status = NEW_LINE;
					break;
				}else if(letter == ':') {
					status = ERROR;
					break;
				}
				j = 0;
				tmp_key[j++] = letter;
				status = GET_KEY;
				break;
			}
			case GET_KEY:
			{
				if(letter == ' ' || letter == '\t' || letter == ':') {
					if(letter == ':') {
						sep_sign = true;
					}
					tmp_key[j] = '\0';
					status = OMMIT_SPACE;
					break;
				}else if(letter == '\r' || letter == '\n') {
					status = ERROR;
					break;
				}
				tmp_key[j++] = letter;
				break;
			}
			case OMMIT_SPACE:
			{
				if(letter == ' ' || letter == '\t' || letter == ':') {
					if(letter == ':' && !sep_sign) {
						sep_sign = true;
					}else if(letter == ':') {
						j = 0;
						status = GET_VALUE;
					}
					break;
				}else if(letter == '\r' || letter == '\n') {
					tmp_value[0] = '\0';
					status = SUCCESS;
					break;
				}
				j = 0;
				status = GET_VALUE;
				break;
			}
			case GET_VALUE:
			{
				int tail = len - 1;
				while(tail >= 0 && (file_line[tail] == ' ' || file_line[tail] == '\t' || file_line[tail] == '\r' || file_line[tail] == '\n')) {
					file_line[tail--] = '\0';
				}
				if((tail >= (i - 1)) && ((tail - i + 2) < (int) sizeof(tmp_value))) {
					snprintf(tmp_value, sizeof(tmp_value), "%s", &file_line[i-1]);
					status = SUCCESS;
					break;
				}
				status = ERROR;
				break;
			}
			default:
				break;
			}
		}

		if(status == SUCCESS && sep_sign) {
			snprintf(p_conf->item[cur_item_num].key, sizeof(p_conf->item[cur_item_num].key), "%s", tmp_key);
			snprintf(p_conf->item[cur_item_num].value, sizeof(p_conf->item[cur_item_num].value), "%s", tmp_value);
			cur_item_num++;
			continue;
		}
		if(status == NEW_LINE) {
			continue;
		}
		WARNING_LOG("line [%d] in conf file [%s] error", line_num, full_path);
	}
	p_conf->real_num = cur_item_num;

	fclose(fp);
	fp = NULL;

	return 0;
}

int read_conf_include(const char* full_path, conf_data* p_conf) {
	if(full_path == NULL || p_conf == NULL) {
		WARNING_LOG("The input parameter for read_conf_include() is illegal!");
		return -1;
	}

	int cur_item_num = p_conf->real_num;
	char inc_file[LINE_SIZE];
	char inc_full_path[LINE_SIZE];

	for(int i = 0; i < cur_item_num; i++) {
		if(strncasecmp(p_conf->item[i].key, "$include", strlen("$include")) == 0) {
			char *value = p_conf->item[i].value;
			int pos = 0;
			int inc_pos = 0;

			while(value[pos] != '\0' && (value[pos] == ' ' || value[pos] == '\t' || value[pos] == '"')) {
				pos++;
			}
			while(value[pos] != '\0' && value[pos] != '"') {
				inc_file[inc_pos++] = value[pos++];
			}
			inc_file[inc_pos] = '\0';
			if(value[pos] == '"') {
				if(inc_file[0] == '/') {
					if(read_conf_unit(inc_file, p_conf, p_conf->real_num) < 0) {
						WARNING_LOG("Fail to read conf file:[%s]", inc_file);
					}
				}else{
					snprintf(inc_full_path, sizeof(inc_full_path), "%s/%s", full_path, inc_file);
					if(read_conf_unit(inc_full_path, p_conf, p_conf->real_num) < 0) {
						WARNING_LOG("Fail to read conf file:[%s]", inc_full_path);
					}
				}
			}
		}
	}
	return 0;
}

int get_conf_int32(conf_data* p_conf, const char* conf_key, int* conf_value) {
	if(p_conf == NULL || conf_key == NULL || conf_value == NULL) {
		WARNING_LOG("The input parameter for get_conf_int32() is illegal!");
		return -1;
	}

	char buf[WORD_SIZE];
	*conf_value = 0;
	int ret = get_conf_nstr(p_conf, conf_key, buf, sizeof(buf));
	if(ret < 0) {
		return -1;
	}

	if(buf[0] == 0) {
		if(buf[1] == 'x') {
			ret = sscanf(buf+2, "%x", conf_value);
		}else if(buf[1] != '0') {
			ret = sscanf(buf+1, "%o", conf_value);
		}else{
			return 0;
		}
	}else{
		ret = sscanf(buf, "%d", conf_value);
	}

	if(ret <= 0) {
		return -1;
	}
	return 0;
}

int get_conf_uint32(conf_data* p_conf, const char* conf_key, unsigned int* conf_value) {
	if(p_conf == NULL || conf_key == NULL || conf_value == NULL) {
		WARNING_LOG("The input parameter for get_conf_uint32() is illegal!");
		return -1;
	}

	char buf[WORD_SIZE];
	*conf_value = 0;
	int ret = get_conf_nstr(p_conf, conf_key, buf, sizeof(buf));
	if(ret < 0) {
		return -1;
	}

	if(buf[0] == 0) {
		if(buf[1] == 'x') {
			ret = sscanf(buf+2, "%x", conf_value);
		}else if(buf[1] != '0') {
			ret = sscanf(buf+1, "%o", conf_value);
		}else{
			return 0;
		}
	}else{
		ret = sscanf(buf, "%u", conf_value);
	}

	if(ret <= 0) {
		return -1;
	}
	return 0;
}

int get_conf_int64(conf_data* p_conf, const char* conf_key, long* conf_value) {
	if(p_conf == NULL || conf_key == NULL || conf_value == NULL) {
		WARNING_LOG("The input parameter for get_conf_int64() is illegal!");
		return -1;
	}

	char buf[WORD_SIZE];
	*conf_value = 0;
	int ret = get_conf_nstr(p_conf, conf_key, buf, sizeof(buf));
	if(ret < 0) {
		return -1;
	}

	if(buf[0] == 0) {
		if(buf[1] == 'x') {
			ret = sscanf(buf+2, "%lx", conf_value);
		}else if(buf[1] != '0') {
			ret = sscanf(buf+1, "%lo", conf_value);
		}else{
			return 0;
		}
	}else{
		ret = sscanf(buf, "%ld", conf_value);
	}

	if(ret <= 0) {
		return -1;
	}
	return 0;
}

int get_conf_uint64(conf_data* p_conf, const char* conf_key, unsigned long* conf_value) {
	if(p_conf == NULL || conf_key == NULL || conf_value == NULL) {
		WARNING_LOG("The input parameter for get_conf_uint64() is illegal!");
		return -1;
	}

	char buf[WORD_SIZE];
	*conf_value = 0;
	int ret = get_conf_nstr(p_conf, conf_key, buf, sizeof(buf));
	if(ret < 0) {
		return -1;
	}

	if(buf[0] == 0) {
		if(buf[1] == 'x') {
			ret = sscanf(buf+2, "%lx", conf_value);
		}else if(buf[1] != '0') {
			ret = sscanf(buf+1, "%lo", conf_value);
		}else{
			return 0;
		}
	}else{
		ret = sscanf(buf, "%lu", conf_value);
	}

	if(ret <= 0) {
		return -1;
	}
	return 0;
}

int get_conf_nstr(conf_data* p_conf, const char* conf_key, char* conf_value, const size_t len) {
	if(p_conf == NULL || conf_key == NULL || conf_value == NULL) {
		WARNING_LOG("The input parameter for get_conf_nstr() is illegal!");
		return -1;
	}
	conf_value[0] = '\0';

	for(int i = 0; i < p_conf->real_num; i++) {
		if(strncmp(p_conf->item[i].key, conf_key, strlen(conf_key)) == 0) {
			snprintf(conf_value, len, "%s", p_conf->item[i].value);
			return 0;
		}
	}
	return -1;
}

int get_conf_float(conf_data* p_conf, const char* conf_key, float* conf_value) {
	if(p_conf == NULL || conf_key == NULL || conf_value == NULL) {
		WARNING_LOG("The input parameter for get_conf_float() is illegal!");
		return -1;
	}

	char buf[WORD_SIZE];
	*conf_value = 0.0;
	int ret = get_conf_nstr(p_conf, conf_key, buf, sizeof(buf));
	if(ret < 0) {
		return -1;
	}

	ret = sscanf(buf, "%f", conf_value);

	if(ret <= 0) {
		return -1;
	}
	return 0;
}
