#!/bin/bash

start() {
    echo "start bus_position server..."
    ulimit -c unlimited
    ./bin/bus_position &
    echo "finish start!"
}

stop() {
    echo "stopping bus_position server..."
    pid=`/sbin/pidof ./bin/bus_position`
    echo "pid:$pid"
    kill -9 $pid
    echo "finish stop!"
}

restart() {
    echo "restart bus_position server..."
    pid=`/sbin/pidof ./bin/bus_position`
    echo "pid:$pid"
    kill -9 $pid
    sleep 3
    ulimit -c unlimited
    ./bin/bus_position &
    echo "finish restart!"
}

case "$1" in
start)
    start;;
stop)
    stop;;
restart)
    restart;;
esac
