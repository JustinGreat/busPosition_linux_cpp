/*
 * bp_update.cpp
 *
 *  Created on: 2013-3-16
 *      Author: pengcheng.wang
 */


#include <pthread.h>

#include "bp_type.h"
#include "bp_head.h"
#include "bp_blk_list.h"
#include "my_log.h"
#include "err_head.h"
#include "bp_update.h"

#define BEGIN_TIME(begin_time) \
    do{ \
        gettimeofday(&begin_time, NULL); \
    }while(0)

 #define NOTICE_TIME(begin_time, comment) \
     do{ \
         struct timeval end_time; \
         gettimeofday(&end_time, NULL); \
         double diff_time = (end_time.tv_sec - begin_time.tv_sec) * 1000.0 + (end_time.tv_usec - begin_time.tv_usec)/1000.0;\
         NOTICE_LOG("%s time: [%f] ms", comment, diff_time); \
     }while(0)

extern struct bp_conf* g_bp_conf;
extern struct city_list* g_city_list;
extern struct city_hash* g_city_hash;

bool sort_by_st_index_ascend(struct trip_st_unit a, struct trip_st_unit b) {

	if(a.index < b.index) {
		return true;
	}

	return false;
}

int32 start_update() {
	if(g_bp_conf == NULL) {
		WARNING_LOG("g_bp_conf pointer is NULL!");
		return ERR_ILLEGAL;
	}

	struct update_unit* up = new(std::nothrow) update_unit();
	if(up == NULL) {
		FATAL_LOG("No enough memory for update_unit");
		return ERR_NO_MEM;
	}

	up->up_curl = curl_easy_init();
	if(up->up_curl == NULL) {
		WARNING_LOG("Fail to create new curl http for update data");
		return ERR_ILLEGAL;
	}
	cur_handle_optimize(up->up_curl);
	/*
	 * �������п�֧�ֳ��е�ȫ������
	 */
	struct timeval begin_time;

	BEGIN_TIME(begin_time);
	//��ȡÿ�������£�֧��ʵʱ���ݵ�ȫ����·id
	int32 ret = load_all_data(up);
	
	NOTICE_TIME(begin_time, "load all data");

	if(ret < 0) {
		WARNING_LOG("Fail to load_all_data()");
		return ERR_ILLEGAL;
	}
	/*//����ʱ����city_hash��ֻ������ʱִ�д˺���
	//��������ṹ�����������ţ����Ա���ȫ���ɹ��ſ��ԣ���һ������ʧ��������ʧ�ܡ�
	//����֮��city_hash�򲻻������κα仯
	ret = build_city_hash();
	if(ret < 0) {
		WARNING_LOG("Fail to build_city_hash()");
		return ERR_ILLEGAL;
	}*/
	//��һ���ֶ�������ѯ
	handle_data(up);
	
	/*
	 * �������̣߳�������ʱˢ��������
	 */
	pthread_t pid;
	if(pthread_create(&pid, NULL, update_data, (void*) up) != 0) {
		FATAL_LOG("Fail to create thread to update data!");
		return ERR_ILLEGAL;
	}

	return 0;
}

/*
 * �����±�֤����֮��ÿ��ִֻ��һ��load_all_data������ʱ�����ִ��handle_data
 */
void* update_data(void* arg) {
	if(arg == NULL) {
		FATAL_LOG("input parameter is NULL, illegal");
		pthread_exit(NULL);
	}
	log_init_thread_attr();
	log_set_notice_info(MY_LOG_SRV_NAME, "%s", "UPDATE");

	pthread_detach(pthread_self());

	struct update_unit* up = (struct update_unit*) arg;
	int32 ret = 0;
	time_t cur_time;
	struct tm cur_tm;
	bool today_is_cleared = true;
	int32 pre_day = 0;
	int32 cur_day = 0;

	time(&cur_time);
	localtime_r(&cur_time, &cur_tm);

	pre_day = cur_tm.tm_mday;
	cur_day = cur_tm.tm_mday;

	while(1) {
		sleep(g_bp_conf->update_interval);

		time(&cur_time);
		localtime_r(&cur_time, &cur_tm);
		cur_day = cur_tm.tm_mday;

		if(pre_day != cur_day) {
			pre_day = cur_day;
			today_is_cleared = false;
		}

		if(cur_tm.tm_hour == g_bp_conf->update_clear_time && !today_is_cleared) {
			//ÿ�춨ʱ����������ݲ�����ȫ�����ݵ������������,ÿ��ִֻ��һ��
			NOTICE_LOG("=====Start clear and update all line trip");
			ret = load_all_data(up);
			if(ret < 0) {
				WARNING_LOG("Fail to clear and reload");
			}
			NOTICE_LOG("=====End clear and update all line trip");
			today_is_cleared = true;
		}else {
			//��ʱ��ѯblk_list�е����ݽ��и���
			//NOTICE_LOG("=====Start update line trip");
			ret = handle_data(up);
			if(ret < 0) {
				WARNING_LOG("Fail to update data");
			}
			//NOTICE_LOG("=====End update line trip");
		}

	}

	log_destroy_thread_attr();
	pthread_exit(NULL);
}

/* Function: http_res_call_back()
 * Description: the call function for curl receive message from peer
 * Input:
 *   @data: the message received by curl, The size of the data pointed to by ptr is size multiplied with nmemb
 *   @n_size: the size of the data pointed to by data is size multiplied with nmemb
 *   @n_memb: the size of the data pointed to by data is size multiplied with nmemb
 *   @user_buf: the buffer set by user through curl_easy_setopt(easy_handle, CURLOPT_WRITEDATA, userData)
 * Output:
 *   @  return the number of bytes actually taken care of
 *   ��URL��Ӧ���յĹ����У�ֻҪ�յ�һ�����ݰ�����������ͻᱻ����
 *   �ڲ����У���������http_res_call_back��curl�������ص����Σ�������ͬһ��Ӧ����������ݰ��������������˶�ͬһ��Ӧ�����ƴװ
 */
int32 http_res_call_back(char *data, size_t n_size, size_t n_memb, void *user_buf) {
    if(user_buf == NULL || data == NULL) {
    	return 0;
    }
    std::string* page = (std::string*) user_buf;
    uint32 len = page->size();

    uint32 real_size = n_size * n_memb;
    uint32 limit = g_bp_conf->http_res_buf_size;
    if((len + real_size) >= limit) {
    	WARNING_LOG("The length of received data is more than buffer length[%u]", limit);
    	return -1;
    }

    page->append(data, real_size);

    return n_size * n_memb;
}

int32 bp_http_request(int to_ms, struct update_unit* up) {
	if(up == NULL || up->up_curl == NULL) {
		WARNING_LOG("The input paramter is illegal");
		return ERR_ILLEGAL;
	}

	up->up_response.clear();

	CURLcode code;
	code = curl_easy_setopt(up->up_curl, CURLOPT_URL, up->up_request.c_str());
	if (code != CURLE_OK) {
		WARNING_LOG("url[%s] could not set CURLOPT_URL. error [%d]:[%s]",
				up->up_request.c_str(), code, curl_easy_strerror(code));
		return ERR_CURL_FAIL;
	}

	code = curl_easy_setopt(up->up_curl, CURLOPT_NOSIGNAL, 1);
	if (code != CURLE_OK) {
		WARNING_LOG("url[%s] could not set CURLOPT_NOSIGNAL. error [%d]:[%s]",
				up->up_request.c_str(), code, curl_easy_strerror(code));
		return ERR_CURL_FAIL;
	}

	code = curl_easy_setopt(up->up_curl, CURLOPT_TIMEOUT_MS, to_ms);
	if (code != CURLE_OK) {
		WARNING_LOG("url[%s] could not set CURLOPT_TIMEOUT_MS. error [%d]:[%s]",
				up->up_request.c_str(), code, curl_easy_strerror(code));
		return ERR_CURL_FAIL;
	}

    code = curl_easy_setopt(up->up_curl, CURLOPT_WRITEFUNCTION, http_res_call_back);
    if (code != CURLE_OK) {
		WARNING_LOG("could not set write function.error [%d]:[%s]", code, curl_easy_strerror(code));
		return ERR_CURL_FAIL;
    }

    code = curl_easy_setopt(up->up_curl, CURLOPT_WRITEDATA, (void*) &(up->up_response));
    if (code != CURLE_OK) {
		WARNING_LOG("could not set the write data, error [%d]:[%s]", code, curl_easy_strerror(code));
		return ERR_CURL_FAIL;
    }

    code = curl_easy_perform(up->up_curl);
    if (code != CURLE_OK) {
		WARNING_LOG("url[%s], curl perform error [%d]:[%s]", up->up_request.c_str(), code, curl_easy_strerror(code));
		return ERR_CURL_FAIL;
    }

    return 0;
}

int32 cur_handle_optimize(CURL* curl_handle) {
	if(curl_handle == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}
    static CURLSH* share_handle = NULL;
    if(!share_handle) {
        share_handle = curl_share_init();
        curl_share_setopt(share_handle, CURLSHOPT_SHARE, CURL_LOCK_DATA_DNS);
    }
    curl_easy_setopt(curl_handle, CURLOPT_SHARE, share_handle);
    curl_easy_setopt(curl_handle, CURLOPT_DNS_CACHE_TIMEOUT, -1);//dns cache remain forever
    return 0;
}

int32 handle_data(struct update_unit* up) {
	if(up == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}
	if(up->up_curl == NULL) {
		FATAL_LOG("curl for update is NULL, illegal");
		return ERR_ILLEGAL;
	}
	if(g_city_list == NULL) {
		FATAL_LOG("g_city_list is NULL, illegal");
		return ERR_ILLEGAL;
	}

	int32 ret = 0;
	struct city_list* cl = g_city_list;
	while(cl != NULL) {
		DEBUG_LOG("update city[%s][%s]", cl->city_code, cl->city_name);
		if(cl->bl != NULL) {
			struct blk_node* cur_node = cl->bl->head;
			while(cur_node != NULL) {
				ret = process_blk_node(cl, cur_node, up);
				if(ret < 0) {
					WARNING_LOG("Fail to update current blk_node. will continue to update next node");
				}
				cur_node = cur_node->next;
			}
		}else{
			WARNING_LOG("this city blk_list is NULL, illegal");
		}

		cl = cl->next;
	}


	return 0;
}

int32 process_blk_node(struct city_list* cl, struct blk_node* node, struct update_unit* up) {
	if(cl == NULL || node == NULL || up == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}
	if(node->used_num == 0) {
		WARNING_LOG("current blk_node no used ln_info");
		return 0;
	}
	/*
	 * ����http����
	 */
	int32 ret = 0;

	ret = build_http_request(cl->city_name_encoded, up->up_request, node);
	if(ret < 0) {
		WARNING_LOG("Fail to build http request for update");
		return ERR_ILLEGAL;
	}

	ret = update_blk_node(cl, up);
	if(ret < 0) {
		WARNING_LOG("Fail to update_blk_node");
		return ERR_ILLEGAL;
	}

	return 0;
}

int32 build_http_request(const char* city_name_encoded, std::string& req, struct blk_node* node) {
	if(city_name_encoded == NULL || node == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}

	req.clear();
	req.append(g_bp_conf->update_http_url);
	req.append("?type=0&city=");
	req.append(city_name_encoded);
	req.append("&lineIds=");

	uint32 count = 0;
	char str_buf[BUF_SIZE];
	while(count < node->used_num) {
		snprintf(str_buf, sizeof(str_buf), "%ld,", node->ln_arr[count].ln_id);
		req.append(str_buf);
		count++;
	}
	/*
	 * ȥ�����һ������
	 */
	if(!req.empty()) {
		req.erase(req.end() - 1);
	}

	return 0;
}

int32 update_blk_node(struct city_list* cl, struct update_unit* up) {
	if(cl == NULL || up == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}
	struct blk_list* bl = cl->bl;
	//NOTICE_LOG("update request:[%s], city[%s]", up->up_request.c_str(), cl->city_name);

	struct timeval begin_time;
	BEGIN_TIME(begin_time);

	int32 ret = bp_http_request(g_bp_conf->update_http_timeout, up);
	if(ret < 0) {
		WARNING_LOG("Fail to get response from data source, city[%s]", cl->city_name);
		return ERR_UPDATE;
	}

	//NOTICE_TIME(begin_time, "http response");

	char* response = (char*) up->up_response.c_str();
	int32 response_len = up->up_response.size();
	if(response_len <= 0) {
		WARNING_LOG("response is empty! city[%s]", cl->city_name);
		return ERR_UPDATE;
	}
	//fprintf(stderr, "request:%s\n", up->up_request.c_str());
	//fprintf(stderr, "response:%s\n\n", response);

	Json::Reader reader;

	Json::Value root;
	bool is_parse_json = reader.parse(response, response+response_len, root);
	if(!is_parse_json) {
		WARNING_LOG("http update data json format error, city[%s]", cl->city_name);
		return ERR_UPDATE;
	}

	if(!(root.isObject() && root.isMember("status"))) {
		WARNING_LOG("no \"status\" field in updated json, city[%s]", cl->city_name);
		return ERR_UPDATE;
	}

	int32 status = root["status"].asInt();
	if(status != 0) {
		WARNING_LOG("receive update json status[%d], city[%s]", status, cl->city_name);
		return ERR_UPDATE;
	}

	if(!(root.isObject() && root.isMember("info"))) {
		WARNING_LOG("no \"info\" field in updated json, city[%s]", cl->city_name);
		return ERR_UPDATE;
	}

	Json::Value info_list = root["info"];
	uint32 info_limit = info_list.size();
	for(uint32 index = 0; index < info_limit; index++) {
		ret = parse_json(info_list, index, up->up_ln);
		if(ret < 0) {
			return ret;
		}
		ret = blk_list_update(bl, &(up->up_ln));
		if(ret < 0) {
			WARNING_LOG("Fail to update ln_info for ln_id[%lu], city[%s]", up->up_ln.ln_id, cl->city_name);
			return ERR_ILLEGAL;
		}
	}

	//NOTICE_LOG("receive line number[%u]", info_limit);
	return 0;
}

int32 parse_json(Json::Value& info_list, uint32 index, struct ln_info& ln) {

	Json::Value info = info_list[index];
	ln.ln_id = 0;
	ln.ln_expire_time = 0;
	ln.ln_trip_arr.clear();

	if(!(info.isObject() && info.isMember("lineId"))) {
		WARNING_LOG("no \"lineId\" field in updated json");
		return ERR_UPDATE;
	}

	ln.ln_id = info["lineId"].asUInt64();


	struct trip_info trip;
	struct trip_st_unit data;

	if(!(info.isObject() && info.isMember("trip"))) {
		WARNING_LOG("no \"trip\" field in updated json");
		return ERR_UPDATE;
	}

	Json::Value trip_list = info["trip"];
	uint32 trip_limit = trip_list.size();
	for(uint32 t_index = 0; t_index < trip_limit; t_index++) {

		clear_trip_info(&trip);
		if(!(trip_list[t_index].isObject())) {
			WARNING_LOG("index[%u] over than trip in updated json", t_index);
			return ERR_UPDATE;
		}

		if(!(trip_list[t_index].isMember("x"))) {
			WARNING_LOG("no \"x\" field in updated json");
			return ERR_UPDATE;
		}
		trip.longitude = trip_list[t_index]["x"].asDouble();

		if(!(trip_list[t_index].isMember("y"))) {
			WARNING_LOG("no \"y\" field in updated json");
			return ERR_UPDATE;
		}
		trip.latitude = trip_list[t_index]["y"].asDouble();

		if(!(trip_list[t_index].isMember("v1"))) {
			WARNING_LOG("no \"v1\" field in updated json");
			return ERR_UPDATE;
		}
		trip.speed_instent = trip_list[t_index]["v1"].asInt();

		if(!(trip_list[t_index].isMember("v2"))) {
			WARNING_LOG("no \"v2\" field in updated json");
			return ERR_UPDATE;
		}
		trip.speed_avg = trip_list[t_index]["v2"].asInt();

		if(!(trip_list[t_index].isMember("nextStId"))) {
			WARNING_LOG("no \"nextStId\" field in updated json");
			return ERR_UPDATE;
		}
		trip.nxt_st_id = trip_list[t_index]["nextStId"].asUInt64();

		if(!(trip_list[t_index].isMember("data"))) {
			WARNING_LOG("no \"data\" field in updated json");
			return ERR_UPDATE;
		}

		Json::Value data_list = trip_list[t_index]["data"];
		uint32 data_limit = data_list.size();
		for(uint32 d_index = 0; d_index < data_limit; d_index++) {
			if(!(data_list[d_index].isObject())) {
				WARNING_LOG("index[%u] over than data in updated json", d_index);
				return ERR_UPDATE;
			}

			memset(&data, 0, sizeof(struct trip_st_unit));

			if(!(data_list[d_index].isMember("stId"))) {
				WARNING_LOG("no \"stId\" field in updated json");
				return ERR_UPDATE;
			}
			data.st_id = data_list[d_index]["stId"].asInt64();

			if(!(data_list[d_index].isMember("dis"))) {
				WARNING_LOG("no \"dis\" field in updated json");
				return ERR_UPDATE;
			}
			data.dis = data_list[d_index]["dis"].asInt();

			if(!(data_list[d_index].isMember("index"))) {
				WARNING_LOG("no \"index\" field in updated json");
				return ERR_UPDATE;
			}
			data.index = data_list[d_index]["index"].asInt();

			trip.st_unit_arr.push_back(data);
		}
		/*
		 * ��ȫ����վ��������鰴��վ�������������
		 */
		sort(trip.st_unit_arr.begin(), trip.st_unit_arr.end(), sort_by_st_index_ascend);
		/*
		 * ��������վ�����������st_unit_arr���飬ȷ��nxt_st_id��Ӧ�������±��
		 */
		bool is_find = false;
		uint32 st_limit = trip.st_unit_arr.size();
		for(uint32 d_index = 0; d_index < st_limit; d_index++) {
			if(trip.nxt_st_id == trip.st_unit_arr[d_index].st_id) {
				trip.nxt_st_index = (int32) d_index;
				is_find = true;
				break;
			}
		}

		if(!is_find) {
			WARNING_LOG("in updated json data, no nxt_st_id[%lu] in data", trip.nxt_st_id);
			continue;
		}

		ln.ln_trip_arr.push_back(trip);
	}

	time_t cur_time = 0;
	time(&cur_time);
	ln.ln_expire_time =cur_time + g_bp_conf->expire_time;

	return 0;
}

int32 clear_trip_info(struct trip_info* trip) {
	if(trip == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}

	trip->latitude = 0.0;
	trip->longitude = 0.0;
	trip->nxt_st_id = 0;
	trip->nxt_st_index = 0;
	trip->speed_avg = 0;
	trip->speed_instent = 0;
	trip->st_unit_arr.clear();

	return 0;
}

int32 load_all_data(struct update_unit* up) {
	if(up == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}
	int32 ret = 0;

	if(g_city_list == NULL) {
		FATAL_LOG("g_city_list is NULL! illegal");
		return ERR_ILLEGAL;
	}

	//���ݳ���citycode��������������
	struct city_list* cl = g_city_list;
	while(cl != NULL) {
		ret = blk_list_clear(cl->bl);
		if(ret < 0) {
			WARNING_LOG("Fail to clear blk_list for city[%s]", cl->city_code);
		}
		ret = load_city_data(cl, up);
		if(ret < 0) {
			WARNING_LOG("Fail to load city[%s][%s] bus data, will continue to load other cities", 
						cl->city_code, cl->city_name);
		}
		cl = cl->next;
	}

	return 0;
}

/*
int32 build_city_hash() {
	struct city_list* cl = g_city_list;
	while(cl != NULL) {
		if(cl->bl->ln_hash_map->empty()) {
			FATAL_LOG("no line in \"type=lines\" for city[%s] during start", cl->city_name);
			return ERR_ILLEGAL;
		}

		cl->ln_sign = LN_SIGN(cl->bl->head->ln_arr[0].ln_id);
		if(cl->ln_sign == 0) {
			FATAL_LOG("illegal line_id in city[%s] during start", cl->city_name);
			return ERR_ILLEGAL;
		}

		g_city_hash->hp.insert(std::pair<uint64, struct city_list*>(cl->ln_sign, cl));

		cl = cl->next;
	}

	return 0;
}
*/

int32 load_city_data(struct city_list* cl, struct update_unit* up) {
	if(cl == NULL || up == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}

	/*
	 * ����http����
	 */

	up->up_request.clear();
	up->up_request.append(g_bp_conf->update_http_url);
	up->up_request.append("?type=lines&city=");
	up->up_request.append(cl->city_name_encoded);

	int32 ret = update_ln_blk_node(cl, up);
	if(ret < 0) {
		return ERR_ILLEGAL;
	}

	return 0;
}


int32 update_ln_blk_node(struct city_list* cl, struct update_unit* up) {
	if(cl == NULL || up == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}
	struct blk_list* bl = cl->bl;
	//NOTICE_LOG("update request:[%s], city[%s]", up->up_request.c_str(), cl->city_name);

	//struct timeval begin_time;
	//BEGIN_TIME(begin_time);

	int32 ret = bp_http_request(g_bp_conf->update_http_timeout, up);
	if(ret < 0) {
		WARNING_LOG("Fail to get response from data source, city[%s]", cl->city_name);
		return ERR_UPDATE;
	}

	//NOTICE_TIME(begin_time, "http response");

	char* response = (char*) up->up_response.c_str();
	int32 response_len = up->up_response.size();
	if(response_len <= 0) {
		WARNING_LOG("response is empty! city[%s]", cl->city_name);
		return ERR_UPDATE;
	}
	//fprintf(stderr, "request:%s\n", up->up_request.c_str());
	//fprintf(stderr, "response:%s\n\n", response);

	Json::Reader reader;

	Json::Value root;
	bool is_parse_json = reader.parse(response, response+response_len, root);
	if(!is_parse_json) {
		WARNING_LOG("http update data json format error, city[%s]", cl->city_name);
		return ERR_UPDATE;
	}

	if(!(root.isObject() && root.isMember("status"))) {
		WARNING_LOG("no \"status\" field in updated json, city[%s]", cl->city_name);
		return ERR_UPDATE;
	}

	int32 status = root["status"].asInt();
	if(status != 0) {
		WARNING_LOG("receive update json status[%d], city[%s]", status, cl->city_name);
		return ERR_UPDATE;
	}

	if(!(root.isObject() && root.isMember("lineIds"))) {
		WARNING_LOG("no \"lineIds\" field in updated json, city[%s]", cl->city_name);
		return ERR_UPDATE;
	}

	Json::Value info_list = root["lineIds"];
	uint32 info_limit = info_list.size();
	for(uint32 index = 0; index < info_limit; index++) {
		up->up_ln.ln_id = 0;
		up->up_ln.ln_expire_time = 0;
		up->up_ln.ln_trip_arr.clear();
		
		Json::Value info = info_list[index];
		if(!(info.isObject() && info.isMember("lineId"))) {
			WARNING_LOG("no \"lineId\" field in updated json, city[%s]", cl->city_name);
			return ERR_UPDATE;
		}

		up->up_ln.ln_id = info["lineId"].asUInt64();
		
		ret = blk_list_update(bl, &(up->up_ln));
		if(ret < 0) {
			WARNING_LOG("Fail to update ln_info for ln_id[%lu], city[%s]", up->up_ln.ln_id, cl->city_name);
			return ERR_ILLEGAL;
		}
	}
	

	//NOTICE_LOG("receive line number[%u]", info_limit);
	return 0;
}


