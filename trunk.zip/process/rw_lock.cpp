/*
 * rw_lock.cpp
 *
 *  Created on: 2012-5-9
 *      Author: pengcheng.wang
 */
#include "rw_lock.h"
#include "my_log.h"
#include "err_head.h"

RWLock::RWLock(pthread_rwlock_t* rw_lock) {
	if(rw_lock == NULL) {
		WARNING_LOG("The input parameter is illegal!");
		return;
	}
	_rw_lock = rw_lock;
}

RWLock::~RWLock() {
	if(_rw_lock != NULL) {
		int ret = pthread_rwlock_unlock(_rw_lock);
		if(ret != 0) {
			WARNING_LOG("Fail to unlock! err[%d][%s]", ret, strerror(ret));
		}

		_rw_lock = NULL;
	}
}

int RWLock::read_lock() {
	if(_rw_lock == NULL) {
		WARNING_LOG("The input parameter is illegal!");
		return ERR_ILLEGAL;
	}
	int ret = 0;
	if((ret = pthread_rwlock_rdlock(_rw_lock)) != 0) {
		WARNING_LOG("Fail to rdlock! err[%d][%s]", ret, strerror(ret));
		return ERR_ILLEGAL;
	}
	return 0;
}

int RWLock::write_lock() {
	if(_rw_lock == NULL) {
		WARNING_LOG("The input parameter is illegal!");
		return ERR_ILLEGAL;
	}
	int ret = 0;
	if((ret = pthread_rwlock_wrlock(_rw_lock)) != 0) {
		WARNING_LOG("Fail to wrlock! err[%d][%s]", ret, strerror(ret));
		return ERR_ILLEGAL;
	}
	return 0;
}

int RWLock::un_lock() {
	if(_rw_lock == NULL) {
		WARNING_LOG("The input parameter is illegal!");
		return ERR_ILLEGAL;
	}
	int ret = 0;
	if((ret = pthread_rwlock_unlock(_rw_lock)) != 0) {
		WARNING_LOG("Fail to unlock! err[%d][%s]", ret, strerror(ret));
		return ERR_ILLEGAL;
	}
	_rw_lock = NULL;
	return 0;
}


