/*
 * bp_main.cpp
 *
 *  Created on: 2013-3-12
 *      Author: pengcheng.wang
 */

#include <signal.h>

#include "read_conf.h"
#include "my_log.h"
#include "srv_pool.h"
#include "err_head.h"
#include "bp_head.h"
#include "bp_process.h"
#include "bp_update.h"
#include "util.h"

#define DEFAULT_CONF_DIR "./conf/"
#define DEFAULT_CONF_FILE "bp_server.conf"

#define WARNING_LOG_BP(fmt, arg...) \
	fprintf(stderr, "[bus_position][%s:%d]"fmt"\n", __FILE__, __LINE__, ##arg)

#define SAFE_EXIT \
	do{ \
		do{ raise(SIGKILL);}while(1); \
		exit(0); \
	}while(0)

#define _VER_STR(x) #x
#define VER_STR(x) _VER_STR(x)

struct bp_conf* g_bp_conf = NULL;
static srv_unit* g_srv_http = NULL;
void** g_bp_user_data = NULL;
struct city_list* g_city_list = NULL;
//struct city_hash* g_city_hash = NULL;

int32 bp_load_conf();
int32 load_city_code(conf_data* bp_conf);
int32 bp_init();
int32 print_bp_conf();
int32 bp_run();

int32 print_usage() {
	printf("USAGE:\n");
	printf("\t-d : the directory path of configure\n");
	printf("\t-f : the name of configure file\n");
	printf("\t-h : help\n");
	printf("\t-v : show version information\n");
	printf("\n");
	return ERR_ILLEGAL;
}

int32 main(int32 argc, char* argv[]) {
	g_bp_conf = new bp_conf();
	if(g_bp_conf == NULL) {
		WARNING_LOG_BP("No enouth memory for g_bp_conf");
		return ERR_NO_MEM;
	}
	snprintf(g_bp_conf->conf_dir, sizeof(g_bp_conf->conf_dir), "%s", DEFAULT_CONF_DIR);
	snprintf(g_bp_conf->conf_file, sizeof(g_bp_conf->conf_file), "%s", DEFAULT_CONF_FILE);

	char opt = 0;
	while((opt = getopt(argc, argv, "d:f:hv")) != -1) {
		switch(opt) {
		case 'd' :
			snprintf(g_bp_conf->conf_dir, sizeof(g_bp_conf->conf_dir), "%s", optarg);
			break;
		case 'f' :
			snprintf(g_bp_conf->conf_file, sizeof(g_bp_conf->conf_file), "%s", optarg);
			break;
		case 'h' :
			print_usage();
			goto usage_exit;
		case 'v' :
			fprintf(stderr, "%s\n", VER_STR(VERSION));
			goto usage_exit;
		default :
			print_usage();
			goto usage_exit;
		}
	}

	if(bp_load_conf() < 0) {
		WARNING_LOG_BP("fail to bp_load_conf()");
		goto out_exit;
	}

	if(bp_init() < 0) {
		WARNING_LOG_BP("fail to bp_init()");
		goto out_exit;
	}

	if(bp_run() < 0) {
		WARNING_LOG_BP("fail to bp_run()");
		goto out_exit;
	}

out_exit:
	SAFE_EXIT;

usage_exit :
	if(g_bp_conf != NULL) {
		delete g_bp_conf;
		g_bp_conf = NULL;
	}
	return 0;
}

int32 bp_load_conf() {
	if(g_bp_conf == NULL) {
		WARNING_LOG_BP("g_bp_conf is NULL, illegal");
		return ERR_ILLEGAL;
	}
	if(g_bp_conf->conf_dir[0] == '\0' || g_bp_conf->conf_file[0] == '\0') {
		WARNING_LOG_BP("g_bp_conf->conf_dir or conf_file is empty");
		return ERR_ILLEGAL;
	}

	int32 ret = 0;
	conf_data* bp_conf = init_conf();
	if(bp_conf == NULL) {
		WARNING_LOG_BP("fail to init_conf()");
		ret = ERR_ILLEGAL;
		goto out_exit;
	}
	ret = read_conf(g_bp_conf->conf_dir, g_bp_conf->conf_file, bp_conf);
	if(ret < 0) {
		WARNING_LOG_BP("fail to read_conf()");
		goto out_exit;
	}

	get_conf_nstr(bp_conf, "log_dir", g_bp_conf->log_dir, sizeof(g_bp_conf->log_dir));
	get_conf_nstr(bp_conf, "log_file", g_bp_conf->log_file, sizeof(g_bp_conf->log_file));
	get_conf_int32(bp_conf, "log_level", &g_bp_conf->log_level);
	get_conf_int32(bp_conf, "log_split_limit", &g_bp_conf->log_split_limit);

	get_conf_nstr(bp_conf, "srv_name_http", g_bp_conf->srv_name_http, sizeof(g_bp_conf->srv_name_http));
	get_conf_int32(bp_conf, "pool_pending_queue_cap_http", &g_bp_conf->pool_pending_queue_cap_http);
	get_conf_int32(bp_conf, "pool_sock_arr_size_http", &g_bp_conf->pool_sock_arr_size_http);
	get_conf_int32(bp_conf, "port_http", &g_bp_conf->port_http);
	get_conf_int32(bp_conf, "srv_type_http", &g_bp_conf->srv_type_http);
	get_conf_int32(bp_conf, "thread_num_http", &g_bp_conf->thread_num_http);
	get_conf_int32(bp_conf, "connect_type_http", &g_bp_conf->connect_type_http);
	get_conf_int32(bp_conf, "backlog", &g_bp_conf->backlog);

	get_conf_uint32(bp_conf, "req_buf_limit", &g_bp_conf->req_buf_limit);
	get_conf_uint32(bp_conf, "res_buf_limit", &g_bp_conf->res_buf_limit);
	get_conf_int32(bp_conf, "srv_stack_size", &g_bp_conf->srv_stack_size);
	get_conf_int32(bp_conf, "read_timeout", &g_bp_conf->read_timeout);
	get_conf_int32(bp_conf, "write_timeout", &g_bp_conf->write_timeout);
	get_conf_int32(bp_conf, "connect_timeout", &g_bp_conf->connect_timeout);

	get_conf_int32(bp_conf, "update_clear_time", &g_bp_conf->update_clear_time);
	get_conf_nstr(bp_conf, "update_http_url", g_bp_conf->update_http_url, sizeof(g_bp_conf->update_http_url));
	if(g_bp_conf->update_http_url[0] == '\0') {
		ret = ERR_ILLEGAL;
		WARNING_LOG_BP("update_http_url is empty! illegal");
		goto out_exit;
	}
	get_conf_int32(bp_conf, "update_http_timeout", &g_bp_conf->update_http_timeout);
	get_conf_int32(bp_conf, "update_interval", &g_bp_conf->update_interval);

	get_conf_int32(bp_conf, "expire_time", &g_bp_conf->expire_time);
	if(g_bp_conf->expire_time <= 0) {
		WARNING_LOG_BP("expire_time[%d] is illegal! will be set default value[%d]",
				g_bp_conf->expire_time, DEFAULT_NODE_VOL);

		g_bp_conf->expire_time = DEFAULT_NODE_VOL;
	}

	get_conf_int32(bp_conf, "blk_vol_size", &g_bp_conf->blk_vol_size);
	if(g_bp_conf->blk_vol_size <= 0) {
		WARNING_LOG_BP("blk_vol_size[%d] is illegal! will be set default value[%d]",
				g_bp_conf->blk_vol_size, DEFAULT_NODE_VOL);

		g_bp_conf->blk_vol_size = DEFAULT_NODE_VOL;
	}
	get_conf_int32(bp_conf, "http_res_buf_size", &g_bp_conf->http_res_buf_size);

	ret = load_city_code(bp_conf);
	if(ret < 0) {
		goto out_exit;
	}

out_exit :
	if(bp_conf != NULL) {
		free_conf(bp_conf);
		bp_conf = NULL;
	}
	return ret;
}


int32 load_city_code(conf_data* bp_conf) {
	if(bp_conf == NULL) {
		WARNING_LOG_BP("The input parameter is illegal");
		return ERR_ILLEGAL;
	}
	int32 ret = 0;
	int32 city_num = 0;
	get_conf_int32(bp_conf, "city_num", &city_num);
	if(city_num == 0) {
		WARNING_LOG_BP("No citycode for bus position");
		return ERR_ILLEGAL;
	}

	char city_key[CITY_SIZE];
	char city_code[CITY_SIZE];
	char city_name[CITY_SIZE];

	for(int32 i = 0; i < city_num; i++) {
		snprintf(city_key, sizeof(city_key), "city_c%d", i);
		get_conf_nstr(bp_conf, city_key, city_code, sizeof(city_code));
		if(city_code[0] == '\0') {
			WARNING_LOG_BP("city field [%s] is empty", city_key);
			continue;
		}

		snprintf(city_key, sizeof(city_key), "city_n%d", i);
		get_conf_nstr(bp_conf, city_key, city_name, sizeof(city_name));
		if(city_name[0] == '\0') {
			WARNING_LOG_BP("city field [%s] is empty", city_key);
			continue;
		}

		struct city_list* cl = (struct city_list*) calloc(1, sizeof(struct city_list));
		if(cl == NULL) {
			WARNING_LOG_BP("No enough memory for new city_list");
			return ERR_NO_MEM;
		}
		snprintf(cl->city_code, sizeof(cl->city_code), "%s", city_code);
		snprintf(cl->city_name, sizeof(cl->city_name), "%s", city_name);
		ret = url_encode(cl->city_name_encoded, sizeof(cl->city_name_encoded), city_name);
		if(ret < 0) {
			WARNING_LOG_BP("Fail to url_encode for city_name[%s]", city_name);
			return ERR_ILLEGAL;
		}

		cl->bl = NULL;
		cl->next = g_city_list;
		g_city_list = cl;
	}

	return 0;
}

int32 bp_init() {
	if(g_bp_conf == NULL) {
		WARNING_LOG_BP("g_bp_conf is NULL, illegal");
		return ERR_ILLEGAL;
	}
	int32 ret = 0;
	srv_conf conf_http;
	if(srv_default_conf(&conf_http) < 0) {
		WARNING_LOG_BP("fail to srv_default_conf()");
		return ERR_ILLEGAL;
	}

	ret = log_init(g_bp_conf->log_dir, g_bp_conf->log_file, g_bp_conf->log_level, g_bp_conf->log_split_limit);
	if(ret < 0) {
		WARNING_LOG_BP("fail to log_init()");
		return ERR_ILLEGAL;
	}

	ret = log_init_thread_attr();
	if(ret < 0) {
		WARNING_LOG_BP("fail to log_init_thread_attr()");
		return ERR_ILLEGAL;
	}

	ret = print_bp_conf();
	if(ret < 0) {
		WARNING_LOG("fail to print_bp_conf()");
		return ERR_ILLEGAL;
	}

	//start to create http thread
	conf_http.backlog = g_bp_conf->backlog;
	conf_http.connect_to = g_bp_conf->connect_timeout;
	conf_http.connect_type = g_bp_conf->connect_type_http;
	snprintf(conf_http.name, sizeof(conf_http.name), "%s", g_bp_conf->srv_name_http);
	conf_http.pool_pending_queue_cap = g_bp_conf->pool_pending_queue_cap_http;
	conf_http.pool_sock_arr_size = g_bp_conf->pool_sock_arr_size_http;
	conf_http.port = g_bp_conf->port_http;
	conf_http.read_size = g_bp_conf->req_buf_limit;
	conf_http.read_to = g_bp_conf->read_timeout;
	conf_http.srv_stack_size = g_bp_conf->srv_stack_size;
	conf_http.srv_type = g_bp_conf->srv_type_http;
	conf_http.thread_num = g_bp_conf->thread_num_http;
	conf_http.user_size = 0;
	conf_http.write_size = g_bp_conf->res_buf_limit;
	conf_http.write_to = g_bp_conf->write_timeout;

	g_srv_http = srv_create(&conf_http);
	if(g_srv_http == NULL) {
		FATAL_LOG("fail to create server:[%s]", conf_http.name);
		return ERR_ILLEGAL;
	}
	ret = srv_set_rw_data(g_srv_http, NULL, g_bp_conf->req_buf_limit, NULL, g_bp_conf->res_buf_limit);
	if(ret < 0) {
		FATAL_LOG("fail to set rw_data for server:[%s]", conf_http.name);
		return ERR_ILLEGAL;
	}

	g_bp_user_data = (void**) calloc(g_bp_conf->thread_num_http, sizeof(struct bp_user_data));
	if(g_bp_user_data == NULL) {
		FATAL_LOG("no enough memory for g_bp_user_data");
		return ERR_NO_MEM;
	}

	for(int32 i = 0; i < g_bp_conf->thread_num_http; i++) {
		struct bp_user_data* tmp_user_data = (struct bp_user_data*) calloc(1, sizeof(struct bp_user_data));
		if(tmp_user_data == NULL) {
			FATAL_LOG("no enough memory for tmp_user_data");
			return ERR_NO_MEM;
		}
		if(bp_init_user_data(tmp_user_data) < 0) {
			return ERR_NO_MEM;
		}
		g_bp_user_data[i] = (void*) tmp_user_data;
	}

	ret = srv_set_user_data(g_srv_http, g_bp_user_data, sizeof(bp_user_data));
	if(ret < 0) {
		FATAL_LOG("fail to set user_data for server:[%s]", conf_http.name);
		return ERR_ILLEGAL;
	}

	ret = srv_set_call_back(g_srv_http, bp_main_process);
	if(ret < 0) {
		FATAL_LOG("fail to set call_back for server:[%s]", conf_http.name);
		return ERR_ILLEGAL;
	}

	/*//��������hash_map
	g_city_hash = new(std::nothrow) city_hash;
	if(g_city_hash == NULL) {
		FATAL_LOG("no enough memory for g_city_hash");
		return ERR_NO_MEM;
	}*/

	return 0;
}

int32 print_bp_conf() {
	if(g_bp_conf == NULL) {
		WARNING_LOG_BP("g_bp_conf is NULL, illegal");
		return ERR_ILLEGAL;
	}

	DEBUG_LOG("log_dir:[%s]", g_bp_conf->log_dir);
	DEBUG_LOG("log_file:[%s]", g_bp_conf->log_file);
	DEBUG_LOG("log_level:[%d]", g_bp_conf->log_level);
	DEBUG_LOG("log_split_limit:[%d]", g_bp_conf->log_split_limit);

	DEBUG_LOG("srv_name_http;[%s]", g_bp_conf->srv_name_http);
	DEBUG_LOG("pool_pending_queue_cap_http:[%d]", g_bp_conf->pool_pending_queue_cap_http);
	DEBUG_LOG("pool_sock_arr_size_http:[%d]", g_bp_conf->pool_sock_arr_size_http);
	DEBUG_LOG("port_http:[%d]", g_bp_conf->port_http);
	DEBUG_LOG("srv_type_http:[%d]", g_bp_conf->srv_type_http);
	DEBUG_LOG("thread_num_http:[%d]", g_bp_conf->thread_num_http);
	DEBUG_LOG("connect_type_http:[%d]", g_bp_conf->connect_type_http);
	DEBUG_LOG("backlog:[%d]", g_bp_conf->backlog);

	DEBUG_LOG("req_buf_limit:[%u]", g_bp_conf->req_buf_limit);
	DEBUG_LOG("res_buf_limit:[%u]", g_bp_conf->res_buf_limit);
	DEBUG_LOG("srv_stack_size:[%d]", g_bp_conf->srv_stack_size);
	DEBUG_LOG("read_timeout:[%d]ms", g_bp_conf->read_timeout);
	DEBUG_LOG("write_timeout:[%d]ms", g_bp_conf->write_timeout);
	DEBUG_LOG("connect_timeout:[%d]ms", g_bp_conf->connect_timeout);

	DEBUG_LOG("update_clear_time:[%d]", g_bp_conf->update_clear_time);
	DEBUG_LOG("update_http_url:[%s]", g_bp_conf->update_http_url);
	DEBUG_LOG("update_http_timeout:[%d]ms", g_bp_conf->update_http_timeout);
	DEBUG_LOG("update_interval:[%d]s", g_bp_conf->update_interval);

	DEBUG_LOG("expire_time:[%d]s", g_bp_conf->expire_time);
	DEBUG_LOG("blk_vol_size:[%d]", g_bp_conf->blk_vol_size);
	DEBUG_LOG("http_res_buf_size:[%d]", g_bp_conf->http_res_buf_size);

	struct city_list* cur_cl = g_city_list;
	while(cur_cl != NULL) {
		DEBUG_LOG("city_code:[%s]", cur_cl->city_code);
		DEBUG_LOG("city_name:[%s]", cur_cl->city_name);
		cur_cl = cur_cl->next;
	}


	return 0;
}

int32 bp_build_city_list() {
	if(g_city_list == NULL) {
		FATAL_LOG("g_city_list is NULL! No support city");
		return ERR_ILLEGAL;
	}

	struct city_list* cl = g_city_list;
	while(cl != NULL) {
		cl->bl = blk_list_create(g_bp_conf->blk_vol_size);
		if(cl->bl == NULL) {
			return ERR_ILLEGAL;
		}

		cl = cl->next;
	}

	return 0;
}

int32 bp_run() {

	int32 ret = 0;
	ret = bp_build_city_list();
	if(ret < 0) {
		FATAL_LOG("fail to bp_build_city_list()");
		return ERR_ILLEGAL;
	}

	ret = start_update();
	if(ret < 0) {
		FATAL_LOG("fail to start_update()");
		return ERR_ILLEGAL;
	}

	ret = srv_run(g_srv_http);
	if(ret < 0) {
		FATAL_LOG("fail to run srv_run() for server:[%s]", g_srv_http->srv_name);
		return ERR_ILLEGAL;
	}

	srv_join(g_srv_http);
	return 0;
}
