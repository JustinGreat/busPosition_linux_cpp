/*
 * bp_update.h
 *
 *  Created on: 2013-3-16
 *      Author: pengcheng.wang
 */

#ifndef BP_UPDATE_H_
#define BP_UPDATE_H_


#include <string>
#include <curl/curl.h>
#include <json/reader.h>
#include <json/value.h>

#include "bp_type.h"
#include "bp_blk_list.h"

struct update_unit {
	std::string up_request;
	std::string up_response;
	struct ln_info up_ln;
	CURL* up_curl;
};

int32 start_update();
void* update_data(void* arg);
int32 http_res_call_back(char *data, size_t n_size, size_t n_memb, void *user_buf);
int32 bp_http_request(int to_ms, struct update_unit* up);
int32 cur_handle_optimize(CURL* curl_handle);
int32 handle_data(struct update_unit* up);
int32 process_blk_node(struct city_list* cl, struct blk_node* node, struct update_unit* up);
int32 build_http_request(const char* city_name_encoded, std::string& req, struct blk_node* node);
int32 update_blk_node(struct city_list* cl, struct update_unit* up);
int32 parse_json(Json::Value& info_list, uint32 index, struct ln_info& ln);
int32 clear_trip_info(struct trip_info* trip);
int32 load_all_data(struct update_unit* up);
int32 load_city_data(struct city_list* cl, struct update_unit* up);
int32 build_city_hash();
int32 update_ln_blk_node(struct city_list* cl, struct update_unit* up);

#endif /* BP_UPDATE_H_ */
