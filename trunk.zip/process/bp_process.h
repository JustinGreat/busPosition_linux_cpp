/*
 * bp_process.h
 *
 *  Created on: 2013-3-13
 *      Author: pengcheng.wang
 */

#ifndef BP_PROCESS_H_
#define BP_PROCESS_H_

#include "bp_type.h"

int32 bp_main_process();

int32 bp_set_log_data();
int32 bp_send_response(char* write_data, struct bp_user_data* user_data);
int32 bp_build_res_err(int32 err, char* res_buf, int32 res_buf_size, struct bp_user_data* user_data);
int32 bp_clear_ln_info(struct ln_info* ln);
int32 bp_handle(char* read_data, char* write_data, uint32 write_data_size,
		struct bp_user_data* user_data);
int32 bp_process_arivl_st(char* write_data, uint32 write_data_size, struct bp_user_data* user_data);
int32 bp_process_city_supt(char* write_data, uint32 write_data_size, struct bp_user_data* user_data);
int32 bp_build_res_city_supt(char* res_buf, uint32 res_size, struct bp_user_data* user_data);
int32 bp_process_trips_st(char* write_data, uint32 write_data_size, struct bp_user_data* user_data);
int32 bp_process_trips_st2(char* write_data, uint32 write_data_size, struct bp_user_data* user_data);
int32 bp_parse_request(char* request, struct bp_user_data* user_data);
int32 bp_slit_city(char* str, struct bp_prm* prm);
int32 bp_split_req(int32 type, char* str, struct bp_prm* prm);
int32 bp_build_res(char* res_buf, int32 res_size, struct bp_user_data* user_data);
int32 build_arivl_st(char*& res_buf, int32& res_size, struct bp_user_data* user_data);
int32 build_trips_st(char*& res_buf, int32& res_size, struct bp_user_data* user_data);
int32 build_trips_st2(char*& res_buf, int32& res_size, struct bp_user_data* user_data);
int32 bp_err_to_code(int32 err);
int32 bp_clear_user_data(struct bp_user_data* user_data);
int32 bp_init_user_data(struct bp_user_data* user_data);
int32 bp_get_arivl_st(uint64 st_id, struct bp_user_data* user_data);
int32 bp_get_trips_st(struct bp_user_data* user_data, bool include_trip);
int32 bp_get_trips_st2(struct bp_user_data* user_data);
bool check_city_valid(char* city);
struct city_list* get_city_list(uint64 ln_id);

#endif /* BP_PROCESS_H_ */
