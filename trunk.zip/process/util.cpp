/*
 * util.cpp
 *
 *  Created on: 2012-5-3
 *      Author: pengcheng.wang
 */


#include "util.h"
#include "my_log.h"
#include <ctype.h>

int32 xatoi(char* src) {
	if(src == NULL) {
		return 0;
	}
	return (int32) atoi(src);
}

uint32 xatoui(char* src) {
	if(src == NULL) {
		return 0;
	}
	return (uint32) atoi(src);
}

double xatod(char* src) {
	if(src == NULL) {
		return 0.0;
	}
	return atof(src);
}

float xatof(char* src) {
	if(src == NULL) {
		return 0.0;
	}
	return (float) atof(src);
}

uint64 xatoul(char* src) {
	if(src == NULL) {
		return 0;
	}
	return (uint64) atol(src);
}


char* gen_xml_str(char* res, int32& res_len, const char* tag, const char* content) {
	if(res == NULL || tag == NULL || content == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return NULL;
	}
	if(res_len <= 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}

	char* cursor = res;
	int32 left_len = res_len;
	int32 ret = 0;
	ret = snprintf(cursor, left_len, "<%s>%s</%s>", tag, content, tag);
	if(ret <= 0) {
		WARNING_LOG("Fail to build <%s> for response!", tag);
		return NULL;
	}
	left_len -= ret;
	if(left_len < 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}
	res_len -= ret;

	return (cursor + ret);
}

char* gen_xml_conv_str(char* res, int32& res_len, const char* tag, const char* content) {
	char* cursor = res;
	if(cursor == NULL || tag == NULL || content == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return NULL;
	}
	if(res_len <= 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}
	int32 ret = 0;
	int32 i = 0;
	int32 left_len = res_len;

	ret = snprintf(cursor, left_len, "<%s>", tag);
	if(ret <= 0) {
		WARNING_LOG("Fail to build <%s> for response!", tag);
		return NULL;
	}

	cursor += ret;
	left_len -= ret;
	if(left_len <= 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}

	while(content[i] != '\0') {
		switch(content[i])
		{
		case '<':
			ret = snprintf(cursor, left_len, "%s", "&lt;");
			break;
		case '>':
			ret = snprintf(cursor, left_len, "%s", "&gt;");
			break;
		case '&':
			ret = snprintf(cursor, left_len, "%s", "&amp;");
			break;
		case '\"':
			ret = snprintf(cursor, left_len, "%s", "&quot;");
			break;
		case '\'':
			ret = snprintf(cursor, left_len, "%s", "&apos;");
			break;
		default:
			if(left_len >= 2) {
				strncat(cursor, content+i, 1);
				ret = 1;
			}else{
				WARNING_LOG("No enough buffer for response!");
				return NULL;
			}
			break;
		}

		if(ret <= 0) {
			WARNING_LOG("Fail to convert special tag to normal  for response!");
			return NULL;
		}

		cursor += ret;
		left_len -= ret;
		i++;
		if(left_len <= 0) {
			WARNING_LOG("No enough buffer for response!");
			return NULL;
		}
	}

	ret = snprintf(cursor, left_len, "</%s>", tag);
	if(ret <= 0) {
		WARNING_LOG("Fail to build </%s> for response!", tag);
		return NULL;
	}
	left_len -= ret;
	if(left_len < 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}
	cursor += ret;
	res_len = left_len;

	return cursor;
}

char* gen_xml_float(char* res, int32& res_len, const char* tag, float content) {
	if(res == NULL || tag == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return NULL;
	}
	if(res_len <= 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}

	char* cursor = res;
	int32 left_len = res_len;
	int32 ret = 0;
	ret = snprintf(cursor, left_len, "<%s>%f</%s>", tag, content, tag);
	if(ret <= 0) {
		WARNING_LOG("Fail to build <%s> for response!", tag);
		return NULL;
	}
	left_len -= ret;
	if(left_len < 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}
	res_len -= ret;

	return (cursor + ret);
}

char* gen_xml_double(char* res, int32& res_len, const char* tag, double content) {
	if(res == NULL || tag == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return NULL;
	}
	if(res_len <= 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}

	char* cursor = res;
	int32 left_len = res_len;
	int32 ret = 0;
	ret = snprintf(cursor, left_len, "<%s>%f</%s>", tag, content, tag);
	if(ret <= 0) {
		WARNING_LOG("Fail to build <%s> for response!", tag);
		return NULL;
	}
	left_len -= ret;
	if(left_len < 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}
	res_len -= ret;

	return (cursor + ret);
}

char* gen_xml_int32(char* res, int32& res_len, const char* tag, int32 content) {
	if(res == NULL || tag == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return NULL;
	}
	if(res_len <= 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}

	char* cursor = res;
	int32 left_len = res_len;
	int32 ret = 0;
	ret = snprintf(cursor, left_len, "<%s>%d</%s>", tag, content, tag);
	if(ret <= 0) {
		WARNING_LOG("Fail to build <%s> for response!", tag);
		return NULL;
	}
	left_len -= ret;
	if(left_len < 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}
	res_len -= ret;

	return (cursor + ret);
}

char* gen_xml_uint32(char* res, int32& res_len, const char* tag, uint32 content) {
	if(res == NULL || tag == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return NULL;
	}
	if(res_len <= 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}

	char* cursor = res;
	int32 left_len = res_len;
	int32 ret = 0;
	ret = snprintf(cursor, left_len, "<%s>%u</%s>", tag, content, tag);
	if(ret <= 0) {
		WARNING_LOG("Fail to build <%s> for response!", tag);
		return NULL;
	}
	left_len -= ret;
	if(left_len < 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}
	res_len -= ret;

	return (cursor + ret);
}

char* gen_xml_int64(char* res, int32& res_len, const char* tag, int64 content) {
	if(res == NULL || tag == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return NULL;
	}
	if(res_len <= 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}

	char* cursor = res;
	int32 left_len = res_len;
	int32 ret = 0;
	ret = snprintf(cursor, left_len, "<%s>%ld</%s>", tag, content, tag);
	if(ret <= 0) {
		WARNING_LOG("Fail to build <%s> for response!", tag);
		return NULL;
	}
	left_len -= ret;
	if(left_len < 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}
	res_len -= ret;

	return (cursor + ret);
}

char* gen_xml_uint64(char* res, int32& res_len, const char* tag, uint64 content) {
	if(res == NULL || tag == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return NULL;
	}
	if(res_len <= 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}

	char* cursor = res;
	int32 left_len = res_len;
	int32 ret = 0;
	ret = snprintf(cursor, left_len, "<%s>%lu</%s>", tag, content, tag);
	if(ret <= 0) {
		WARNING_LOG("Fail to build <%s> for response!", tag);
		return NULL;
	}
	left_len -= ret;
	if(left_len < 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}
	res_len -= ret;

	return (cursor + ret);
}

char* gen_xml_encode_head(char* res, int32& res_len, const char* char_set) {
	if(res == NULL || res_len <= 0 || char_set == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return NULL;
	}
	if(res_len <= 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}

	char* cursor = res;
	int32 left_len = res_len;
	int32 ret = 0;
	ret = snprintf(cursor, left_len, "<?xml version='1.0' encoding='%s' ?>", char_set);
	if(ret <= 0) {
		WARNING_LOG("Fail to build <?xml encoding> for response!");
		return NULL;
	}
	left_len -= ret;
	if(left_len < 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}
	res_len -= ret;
	return (cursor + ret);
}

char* gen_xml_tag(char* res, int32& res_len, const char* tag) {
	if(res == NULL || tag == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return NULL;
	}
	if(res_len <= 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}

	char* cursor = res;
	int32 left_len = res_len;
	int32 ret = 0;
	ret = snprintf(cursor, left_len, "%s", tag);
	if(ret <= 0) {
		WARNING_LOG("Fail to build %s for response!", tag);
		return NULL;
	}
	left_len -= ret;
	if(left_len < 0) {
		WARNING_LOG("No enough buffer for response!");
		return NULL;
	}
	res_len -= ret;
	return (cursor + ret);
}


int32  url_decode(char* url) {
	if(url == NULL) {
		WARNING_LOG("The input parameter is illegal!");
		return -1;
	}
	char* src = url;
	char* dst = src;
	char ch;

	while((ch = *src++) != 0) {

		if (ch == '+') {
			*dst++ = ' ';
		}else if (ch == '%') {
#define Hex2Int(n) ((n) < 'A' ? (n) - '0' : (n) - '7')
			char h = *src++;
			char l = *src++;
			*dst++ = ((Hex2Int(h)) << 4) + (Hex2Int(l));
#undef Hex2Int
		}else {
			*dst++ = ch;
		}

	}

	*dst = 0;

	return 0;
}

int32 url_encode(char* des, int32 des_size, const char* src) {
	if(des == NULL || des_size <= 0 || src == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return -1;
	}

	char* cursor = des;
	int32 left = des_size;
	int32 ret = 0;

	while(*src && left > 2) {
		if(*((uint8 *) src) > 0x80) {
			if(*(src+1)) {
				//���ֻ��������ַ�����Ҫ����һ����
				ret = snprintf(cursor, left, "%%%02X%%%02X", *((uint8 *) src), *((uint8 *)(src+1)));
				left -= ret;
				if(left <= 0) {
					WARNING_LOG("No enough buffer for encode url!");
					return -1;
				}
				cursor += ret;
				src += 2;
			}else{
				//������ַ����˵�
				break;
			}
		}else {
			if(isalnum(*src)) {
				*(cursor++) = *src;
				left--;
				src++;
			}else{
				ret = snprintf(cursor, left, "%%%02X", *((uint8 *) src));
				left -= ret;
				if(left <= 0) {
					WARNING_LOG("No enough buffer for encode url!");
					return -1;
				}
				cursor += ret;
				src++;
			}
		}
	}

	if(*src) {
		WARNING_LOG("No enough buffer for encode url!");
		return -1;
	}

	*cursor = 0;

	return 0;
}

