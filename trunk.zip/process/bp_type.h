/*
 * bp_type.h
 *
 *  Created on: 2013-3-12
 *      Author: pengcheng.wang
 */

#ifndef BP_TYPE_H_
#define BP_TYPE_H_

#define PATH_SIZE (512)

#define IP_BUF_SIZE (128)
#define DEFAULT_NODE_VOL (20)
#define DEFAULT_EXPIRE_TIME (5*60) //��λ��
#define CITY_SIZE (256)
#define HTTP_HEAD_SIZE (1024)
#define BUF_SIZE (512)
#define DEFAULT_TRIP_NUM (1)
#define MAX_LINE_LIMIT (10)

typedef unsigned char uint8;
typedef char int8;
typedef unsigned int uint32;
typedef int int32;
typedef unsigned long uint64;
typedef long int64;





#endif /* BP_TYPE_H_ */
