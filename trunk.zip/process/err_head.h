/*
 * err_head.h
 *
 *  Created on: 2013-3-12
 *      Author: pengcheng.wang
 */

#ifndef ERR_HEAD_H_
#define ERR_HEAD_H_

enum ERR_ENUM {
	ERR_ILLEGAL = -1,
	ERR_NO_MEM = -2,
	ERR_HTTP_REQ = -3,
	ERR_NO_DATA = -4,
	ERR_RES_EMPTY = -5,
	ERR_BUF_RES = -6,
	ERR_NO_SUCH_CITY = -7,
	ERR_CURL_FAIL = -8,
	ERR_UPDATE = -9,
	ERR_DATA_EXPIRE = -10,


	ERR_END = -11,
};


#endif /* ERR_HEAD_H_ */
