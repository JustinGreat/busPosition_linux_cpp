/*
 * rw_lock.h
 *
 *  Created on: 2012-5-9
 *      Author: pengcheng.wang
 */

#ifndef RW_LOCK_H_
#define RW_LOCK_H_

#include <pthread.h>

class RWLock {
private:
	pthread_rwlock_t* _rw_lock;
	/*
	 * ��ֹ��������ֵ���캯��
	 */
	RWLock(RWLock const&);
	RWLock& operator= (RWLock const&);
public:
	RWLock(pthread_rwlock_t* rw_lock);
	~RWLock();

	int read_lock();
	int write_lock();
	int un_lock();
};


#endif /* RW_LOCK_H_ */
