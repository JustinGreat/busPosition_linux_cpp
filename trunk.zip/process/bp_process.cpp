/*
 * bp_process.cpp
 *
 *  Created on: 2013-3-13
 *      Author: pengcheng.wang
 */

#include "bp_process.h"
#include "my_log.h"
#include "bp_head.h"
#include "err_head.h"
#include "util.h"
#include "srv_pool.h"
#include "bp_blk_list.h"

extern bp_conf* g_bp_conf;
extern struct city_list* g_city_list;
extern struct city_hash* g_city_hash;

bool sort_by_dis_ascend(struct trip_st_index a, struct trip_st_index b) {
	struct trip_st_unit& a_tsu = (*(a.trip))[a.trip_index].st_unit_arr[a.st_index];
	struct trip_st_unit& b_tsu = (*(b.trip))[b.trip_index].st_unit_arr[b.st_index];

	if(a_tsu.dis < b_tsu.dis) {
		return true;
	}else if(a_tsu.dis == b_tsu.dis) {
		if(a_tsu.index < b_tsu.index) {
			return true;
		}
	}

	return false;
}

/*
 * ��st_dis_index���鰴��nxt_sid�������С�
 * ���nxt_sid��ͬ�����յ����nxt_sid��dis��������;
 * �����nxt_sid��dis��ͬ������ ƽ���ٶ� ��������
 *
 */
bool sort_by_nxt_sid_descend(struct trip_st_index a, struct trip_st_index b) {
	/*struct trip_info& a_ti = (*(a.trip))[a.trip_index];
	struct trip_info& b_ti = (*(b.trip))[b.trip_index];

	if(a_ti.nxt_st_id > b_ti.nxt_st_id) {
		return true;
	}else if(a_ti.nxt_st_id == b_ti.nxt_st_id) {

		struct trip_st_unit& a_tsu = a_ti.st_unit_arr[a_ti.nxt_st_index];
		struct trip_st_unit& b_tsu = b_ti.st_unit_arr[b_ti.nxt_st_index];

		if(a_tsu.dis < b_tsu.dis) {
			return true;
		}else if(a_tsu.dis == b_tsu.dis) {
			if(a_ti.speed_avg > b_ti.speed_avg) {
				return true;
			}
		}
	}

	return false;*/
	struct trip_info& a_ti = (*(a.trip))[a.trip_index];
	struct trip_info& b_ti = (*(b.trip))[b.trip_index];
	struct trip_st_unit& a_tsu = a_ti.st_unit_arr[a_ti.nxt_st_index];
	struct trip_st_unit& b_tsu = b_ti.st_unit_arr[b_ti.nxt_st_index];
	
	if(a_tsu.index > b_tsu.index) {
		return true;
	}else if(a_tsu.index == b_tsu.index) {
	
		if(a_tsu.dis < b_tsu.dis) {
			return true;
		}else if(a_tsu.dis == b_tsu.dis) {
			if(a_ti.speed_avg > b_ti.speed_avg) {
				return true;
			}
		}
	}
	return false;
}

int32 bp_set_log_data() {
	char ip_str[IP_BUF_SIZE];
	struct in_addr tmp_ip;
	bzero(&tmp_ip, sizeof(struct in_addr));
	tmp_ip.s_addr = srv_get_thread_data()->ip;

	inet_ntop(AF_INET, (void*)&tmp_ip, ip_str, sizeof(ip_str));

	log_set_notice_info(MY_LOG_FROM_IP, "%s", ip_str);
	log_set_notice_info(MY_LOG_SRV_NAME, "%s", g_bp_conf->srv_name_http);
	return 0;
}

int32 bp_main_process() {
	char* read_data = (char*) srv_get_read_data();
	if(read_data == NULL) {
		WARNING_LOG("read_data is NULL!");
		return ERR_ILLEGAL;
	}
	char* write_data = (char*) srv_get_write_data();
	if(write_data == NULL) {
		WARNING_LOG("write_data is NULL!");
		return ERR_ILLEGAL;
	}
	uint32 write_data_size = srv_get_write_size();

	bp_user_data* user_data = (bp_user_data*) srv_get_user_data();
	if(user_data == NULL) {
		WARNING_LOG("user_data is NULL!");
		return ERR_ILLEGAL;
	}

	bp_set_log_data();
	bp_clear_user_data(user_data);

	int32 req_body_len = srv_read_http(g_bp_conf->read_timeout, user_data->http_get_post);
	if(req_body_len < 0) {
		return ERR_ILLEGAL;
	}

	struct timeval begin_time;
	struct timeval end_time;
	gettimeofday(&begin_time, NULL);

	int32 ret = bp_handle(read_data, write_data, write_data_size, user_data);

	gettimeofday(&end_time, NULL);
	user_data->elps_time = end_time.tv_sec - begin_time.tv_sec;

	if(ret < 0) {
		goto err_exit;
	}

	NOTICE_LOG("Successfully finish response! Elapse time: [%f] ms",
			((end_time.tv_sec - begin_time.tv_sec) * 1000.0 + (end_time.tv_usec - begin_time.tv_usec)/1000.0));

	bp_send_response(write_data, user_data);

	return 0;

err_exit:
	if(bp_build_res_err(ret, write_data, write_data_size, user_data) > 0) {
		bp_send_response(write_data, user_data);
	}

	return 0;
}

int32 bp_send_response(char* write_data, struct bp_user_data* user_data) {
	if(write_data == NULL || user_data == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}

	int32 ret = srv_write_raw(user_data->http_res_head,
									strlen(user_data->http_res_head),
									g_bp_conf->write_timeout);
	if(ret < 0) {
		WARNING_LOG("Fail to write http_head!");
		return ret;
	}

	ret = srv_write_raw(write_data,
									user_data->http_response_len,
									g_bp_conf->write_timeout);
	if(ret < 0) {
		WARNING_LOG("Fail to write http_response!");
		return ret;
	}

	return 0;
}

int32 bp_build_res_err(int32 err, char* res_buf, int32 res_buf_size, struct bp_user_data* user_data) {
	if(res_buf == NULL || user_data == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return ERR_ILLEGAL;
	}
	char* cursor = res_buf;
	int32 left_len = res_buf_size;
	int32 ret = 0;
	if(err >= 0 || err <= ERR_END) {
		WARNING_LOG("err_no is recognized! illegal!");
		err = ERR_ILLEGAL;
	}

	int32 code = bp_err_to_code(err);
	ret = snprintf(cursor, left_len, "<bp><code>%d</code><message>%s</message></bp>",
			code, message[code]);
	user_data->http_response_len = ret;

	snprintf(user_data->http_res_head, sizeof(user_data->http_res_head),
			"HTTP/1.0 200 OK\r\nContent-Length: %d\r\nContent-Type: text/xml;charset=GBK\r\nConnection: close\r\n\r\n",
			ret);

	return ret;
}

int32 bp_clear_ln_info(struct ln_info* ln) {
	if(ln == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}
	ln->ln_id = 0;
	ln->ln_expire_time = 0;
	ln->ln_trip_arr.clear();
	return 0;
}

int32 bp_handle(char* read_data, char* write_data, uint32 write_data_size,
		struct bp_user_data* user_data) {
	if(read_data == NULL || write_data == NULL || user_data == NULL) {
		WARNING_LOG("The input paramete is illegal");
		return ERR_ILLEGAL;
	}

	int32 ret = url_decode(read_data);
	if(ret < 0) {
		WARNING_LOG("url decode error for request data ");
		return ERR_HTTP_REQ;
	}
	NOTICE_LOG("receive:%s", read_data);

	/*
	 * ��������
	 */
	ret = bp_parse_request(read_data, user_data);
	if(ret < 0) {
		return ret;
	}

	if(user_data->prm->cmd == CMD_ARIVL_ST) {
		return bp_process_arivl_st(write_data, write_data_size, user_data);
	}else if(user_data->prm->cmd == CMD_CITY_SUPOT) {
		return bp_process_city_supt(write_data, write_data_size, user_data);
	}else if(user_data->prm->cmd == CMD_LINE_ST) {
		return bp_process_trips_st(write_data, write_data_size, user_data);
	}else if(user_data->prm->cmd == CMD_TRIPS_ST) {
		return bp_process_trips_st(write_data, write_data_size, user_data);
	}else if(user_data->prm->cmd == CMD_TRIPS_ST2) {
		return bp_process_trips_st2(write_data, write_data_size, user_data);
	}

	return 0;
}

int32 bp_process_arivl_st(char* write_data, uint32 write_data_size, struct bp_user_data* user_data) {
	if(write_data == NULL || user_data == NULL) {
		WARNING_LOG("The input paramete is illegal");
		return ERR_ILLEGAL;
	}
	/*
	 * �ж�����Ƿ��ǺϷ���
	 */
	if(!user_data->prm->include_lines) {
		WARNING_LOG("no line id in http request");
		return ERR_HTTP_REQ;
	}
	if(!user_data->prm->include_stations) {
		WARNING_LOG("no station id in http request");
		return ERR_HTTP_REQ;
	}

	if(user_data->prm->trip_limit == 0) {
		user_data->prm->trip_limit = DEFAULT_TRIP_NUM;
	}

	int32 ret = 0;
	/*
	 * ��blk_list�л�ȡָ��ln_id�ĳ�����Ϣ
	 */
	struct city_list* cl = NULL;
	int32 ln_limit = user_data->prm->ln_arr.size();
	for(int32 i = 0; i < ln_limit; i++) {
		uint64 ln_id = user_data->prm->ln_arr[i].ln_id;
		//��Ҫ���¼���city_list
		cl = get_city_list(ln_id);
		if(cl == NULL) {
			continue;
		}

		bp_clear_ln_info(user_data->ln);
		ret = blk_list_find(cl->bl, ln_id, user_data->ln);
		if(ret < 0) {
			if(ret == ERR_NO_DATA) {
				/*
				 * blk_list����û�����ln_id,��Ҫ��������µ�id���������߳��첽����
				 */
				ret = blk_list_insert(cl->bl, ln_id);
				if(ret < 0) {
					WARNING_LOG("Fail to blk_list_insert ln_id[%lu]", ln_id);
				}

				continue;
			}else if(ret == ERR_DATA_EXPIRE) {
				/*
				 * blk_list�����д�ln_id,���Ǵ������Ѿ�����ʧЧ
				 */
				continue;
			}else{
				WARNING_LOG("The blk_list data error!");
				return ret;
			}
		}

		ret = bp_get_arivl_st(user_data->prm->ln_arr[i].st_id, user_data);
		if(ret < 0) {
			WARNING_LOG("Fail to compute ln_id[%lu] for build result", user_data->ln->ln_id);
			continue;
		}
	}
	
	if(cl == NULL) {
		WARNING_LOG("No support such city");
		return ERR_NO_SUCH_CITY;
	}

	std::string city(cl->city_code);	
	user_data->prm->city_arr.clear();
	user_data->prm->city_arr.push_back(city);
	/*
	 * �Զ����ƽ��ת��������Ϊָ����ʽ��Ӧ��
	 */
	ret = bp_build_res(write_data, write_data_size, user_data);
	if(ret < 0) {
		WARNING_LOG("Fail to build final response");
		return ret;
	}

	return 0;
}

int32 bp_process_city_supt(char* write_data, uint32 write_data_size, struct bp_user_data* user_data) {
	if(write_data == NULL || user_data == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}
	/*
	 * ����ж��Ƿ�֧�ֳ���
	 */
	uint32 city_num = user_data->prm->city_arr.size();

	if(city_num == 0) {
		WARNING_LOG("no city in http request");
		return ERR_HTTP_REQ;
	}

	for(uint32 i = 0; i < city_num; i++) {
		struct city_list* cl = g_city_list;
		const char* city_code = user_data->prm->city_arr[i].c_str();
		bool is_support = false;

		while(cl != NULL) {
			if(strcmp(city_code, cl->city_code) == 0) {
				is_support = true;
				break;
			}
			cl = cl->next;
		}
		user_data->city_support->push_back(is_support);
	}

	/*
	 * �Զ����ƽ��ת��������Ϊָ����ʽ��Ӧ��
	 */
	int32 ret = bp_build_res_city_supt(write_data, write_data_size, user_data);
	if(ret < 0) {
		WARNING_LOG("Fail to build final response");
		return ret;
	}

	return 0;
}

int32 bp_build_res_city_supt(char* res_buf, uint32 res_size, struct bp_user_data* user_data) {
	if(res_buf == NULL || user_data == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}
	int32 ret = 0;
	char* cursor = res_buf;
	int32 left_len = res_size;
	uint32 limit = user_data->city_support->size();
	int32 is_support = 0;

	if(limit != user_data->prm->city_arr.size()) {
		WARNING_LOG("number of city_support[%u] mismatch the requested city number[%zd]",  limit, user_data->prm->city_arr.size());
		ret = ERR_ILLEGAL;
		goto err_exit;
	}

	if((cursor = gen_xml_encode_head(cursor, left_len, "GBK")) == NULL) {
		ret = ERR_BUF_RES;
		goto err_exit;
	}
	if((cursor = gen_xml_tag(cursor, left_len, "<bp>")) == NULL) {
		ret = ERR_BUF_RES;
		goto err_exit;
	}
	if((cursor = gen_xml_int32(cursor, left_len, "code", CODE_OK)) == NULL) {
		ret = ERR_BUF_RES;
		goto err_exit;
	}
	if((cursor = gen_xml_str(cursor, left_len, "message", message[CODE_OK])) == NULL) {
		ret = ERR_BUF_RES;
		goto err_exit;
	}
	if((cursor = gen_xml_tag(cursor, left_len, "<city>")) == NULL) {
		ret = ERR_BUF_RES;
		goto err_exit;
	}

	for(uint32 i = 0; i < limit; i++) {
		if((cursor = gen_xml_tag(cursor, left_len, "<item>")) == NULL) {
			ret = ERR_BUF_RES;
			goto err_exit;
		}
		if((cursor = gen_xml_str(cursor, left_len, "citycode", user_data->prm->city_arr[i].c_str())) == NULL) {
			ret = ERR_BUF_RES;
			goto err_exit;
		}
		is_support = (* user_data->city_support)[i] ? 1 : 0;
		if((cursor = gen_xml_int32(cursor, left_len, "support", is_support)) == NULL) {
			ret = ERR_BUF_RES;
			goto err_exit;
		}

		if((cursor = gen_xml_tag(cursor, left_len, "</item>")) == NULL) {
			ret = ERR_BUF_RES;
			goto err_exit;
		}
	}

	if((cursor = gen_xml_tag(cursor, left_len, "</city>")) == NULL) {
		ret = ERR_BUF_RES;
		goto err_exit;
	}

	if((cursor = gen_xml_tag(cursor, left_len, "</bp>")) == NULL) {
		ret = ERR_BUF_RES;
		goto err_exit;
	}

	user_data->http_response_len = res_size - left_len;

	snprintf(user_data->http_res_head, sizeof(user_data->http_res_head),
			"HTTP/1.0 200 OK\r\nContent-Length: %d\r\nContent-Type: text/xml;charset=GBK\r\nConnection: close\r\n\r\n",
			user_data->http_response_len);

err_exit:
	return ret;
}

int32 bp_process_trips_st(char* write_data, uint32 write_data_size, struct bp_user_data* user_data) {
	if(write_data == NULL || user_data == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}

	/*
	 * ��blk_list�л�ȡָ��ln_id�ĳ�����Ϣ
	 */
	int32 ret = 0;
	int32 ln_limit = user_data->prm->ln_arr.size();
	if(ln_limit == 0 || user_data->prm->ln_arr[0].ln_id == 0) {
		WARNING_LOG("http request for all trips, should include lines");
		return ERR_HTTP_REQ;
	}
	if(ln_limit > MAX_LINE_LIMIT) {
		WARNING_LOG("number of lines [%d] more than limit [%d]", ln_limit, MAX_LINE_LIMIT);
		return ERR_HTTP_REQ;
	}

	bool include_trip = (user_data->prm->cmd == CMD_TRIPS_ST) ? true : false;
	
	struct city_list* cl = NULL;
	for(int32 i = 0; i < ln_limit; i++) {
		uint64 ln_id = user_data->prm->ln_arr[i].ln_id;
		//��Ҫ���¼���city_list
		cl = get_city_list(ln_id);
		if(cl == NULL) {
			continue;
		}

		bp_clear_ln_info(user_data->ln);
		ret = blk_list_find(cl->bl, ln_id, user_data->ln);
		if(ret < 0) {
			if(ret == ERR_NO_DATA) {
				/*
				 * blk_list����û�����ln_id,��Ҫ��������µ�id���������߳��첽����
				 */
				ret = blk_list_insert(cl->bl, ln_id);
				if(ret < 0) {
					WARNING_LOG("Fail to blk_list_insert ln_id[%lu]", ln_id);
				}

				continue;
			}else if(ret == ERR_DATA_EXPIRE) {
				/*
				 * blk_list�����д�ln_id,���Ǵ������Ѿ�����ʧЧ
				 */
				continue;
			}else{
				WARNING_LOG("The blk_list data error!");
				return ret;
			}
		}

		ret = bp_get_trips_st(user_data, include_trip);
		if(ret < 0) {
			WARNING_LOG("Fail to bp_get_trips_st ln_id[%lu] for build result", user_data->ln->ln_id);
			continue;
		}
	}

	if(cl == NULL) {
		WARNING_LOG("No support such city");
		return ERR_NO_SUCH_CITY;
	}

	std::string city(cl->city_code);	
	user_data->prm->city_arr.clear();
	user_data->prm->city_arr.push_back(city);
	/*
	 * �Զ����ƽ��ת��������Ϊָ����ʽ��Ӧ��
	 */
	ret = bp_build_res(write_data, write_data_size, user_data);
	if(ret < 0) {
		WARNING_LOG("Fail to build final response");
		return ret;
	}

	return 0;
}


int32 bp_parse_request(char* request, struct bp_user_data* user_data) {
	if(request == NULL || user_data == NULL) {
		WARNING_LOG("The input parameter is NULL!");
		return ERR_ILLEGAL;
	}

	if(user_data->http_get_post != 1) {// HTTP GET
		WARNING_LOG("The current http is not GET!");
		return ERR_HTTP_REQ;
	}

	if(user_data->http_get_post == 1) {
		//GET
		char* cursor = NULL;
		cursor = strchr(request, '?');
		if(cursor == NULL) {
			WARNING_LOG("Illegal http GET head[%s]", request);
			return ERR_HTTP_REQ;
		}
		cursor++;

		//��'&'���ֶ�ȡ����
		char* token = NULL;
		while((token = strsep(&cursor, "&")) != NULL) {
			char* equal_ptr = strchr(token, '=');
			if(equal_ptr == NULL) {
				WARNING_LOG("no value for parameter, Illegal http request!");
				return ERR_HTTP_REQ;
			}
			*equal_ptr = '\0';
			std::string key_str(token);
			std::string value_str(equal_ptr+1);
			user_data->prm_map->insert(pair<std::string, std::string>(key_str, value_str));
		}
	}

	std::map<std::string, std::string>::iterator iter = user_data->prm_map->find("cmd");
	if(iter == user_data->prm_map->end()) {
		WARNING_LOG("no \"cmd\" in http request");
		return ERR_HTTP_REQ;
	}
	user_data->prm->cmd = xatoi((char*) iter->second.c_str());
	if(user_data->prm->cmd < CMD_ARIVL_ST || user_data->prm->cmd > CMD_TRIPS_ST2) {
		WARNING_LOG("cmd[%d] is illegal in http request", user_data->prm->cmd);
		return ERR_HTTP_REQ;
	}

	iter = user_data->prm_map->begin();
	for(; iter != user_data->prm_map->end(); iter++) {
		const char* iter_key = iter->first.c_str();
		if(strcmp(iter_key, "city") == 0) {
			if(bp_slit_city((char*) iter->second.c_str(), user_data->prm) < 0) {
				return ERR_HTTP_REQ;
			}
		}else if(strcmp(iter_key, "lines") == 0) {
			if(bp_split_req(LN_TYPE, (char*) iter->second.c_str(), user_data->prm) < 0) {
				return ERR_HTTP_REQ;
			}
			user_data->prm->include_lines = true;
		}else if(strcmp(iter_key, "stations") == 0) {
			if(bp_split_req(ST_TYPE, (char*) iter->second.c_str(), user_data->prm) < 0) {
				return ERR_HTTP_REQ;
			}
			user_data->prm->include_stations = true;
		}else if(strcmp(iter_key, "count") == 0) {
			user_data->prm->trip_limit = xatoi((char*) iter->second.c_str());
		}
	}

	return 0;
}

int32 bp_slit_city(char* str, struct bp_prm* prm) {
	if(str == NULL || prm == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}

	if(*str == '\0') {
		WARNING_LOG("city value is NULL, illegal");
		return ERR_HTTP_REQ;
	}

	char* cursor = str;
	char* token = NULL;

	while((token = strsep(&cursor, ",")) != NULL) {
		if(*token != '\0') {
			if(!check_city_valid(token)) {
				WARNING_LOG("city value[%s] is invalid", token);
				return ERR_HTTP_REQ;
			}
			std::string city(token);
			prm->city_arr.push_back(city);
		}
	}

	return 0;
}

bool check_city_valid(char* city) {
	uint32 len = strlen(city);
	for(uint32 i = 0; i < len; i++) {
		if(!isdigit(city[i])) {
			return false;
		}
	}

	return true;
}

int32 bp_split_req(int32 type, char* str, struct bp_prm* prm) {
	if(str == NULL || prm == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}

	if(type != LN_TYPE && type != ST_TYPE) {
		WARNING_LOG("type[%d] is illegal", type);
		return ERR_ILLEGAL;
	}

	char* cursor = str;
	char* token = NULL;

	struct ln_st_unit lsu;
	lsu.ln_id = 0;
	lsu.st_id = 0;

	bool is_check = false;
	int32 limit = prm->ln_arr.size();
	if(limit != 0) {
		is_check = true;
	}

	int32 index = 0;
	while((token = strsep(&cursor, ",")) != NULL) {
		if(is_check) {
			if(index >= limit) {
				WARNING_LOG("number of lines and stations mismatch in http request");
				return ERR_ILLEGAL;
			}
			if(type == LN_TYPE) {
				prm->ln_arr[index].ln_id = xatoul(token);
				if(prm->ln_arr[index].ln_id == 0) {
					WARNING_LOG("ln_id is 0, illegal");
					return ERR_ILLEGAL;
				}
			}else{
				prm->ln_arr[index].st_id = xatoul(token);
				if(prm->ln_arr[index].st_id == 0) {
					WARNING_LOG("st_id is 0, illegal");
					return ERR_ILLEGAL;
				}
			}
		}else{
			if(type == LN_TYPE) {
				lsu.ln_id = xatoul(token);
				if(lsu.ln_id == 0) {
					WARNING_LOG("ln_id is 0, illegal");
					return ERR_ILLEGAL;
				}
			}else{
				lsu.st_id = xatoul(token);
				if(lsu.st_id == 0) {
					WARNING_LOG("st_id is 0, illegal");
					return ERR_ILLEGAL;
				}
			}
			prm->ln_arr.push_back(lsu);
		}

		index++;
	}

	if(is_check && index != limit) {
		WARNING_LOG("number of lines and stations mismatch in http request");
		return ERR_ILLEGAL;
	}

	return 0;
}

int32 bp_build_res(char* res_buf, int32 res_size, struct bp_user_data* user_data) {
	if(res_buf == NULL || res_size == 0 || user_data == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}

	int32 cmd = user_data->prm->cmd;
	int32 ret = 0;
	char* cursor = res_buf;
	int32 left_len = res_size;

	if((cursor = gen_xml_encode_head(cursor, left_len, "GBK")) == NULL) {
		ret = ERR_BUF_RES;
		goto err_exit;
	}
	if((cursor = gen_xml_tag(cursor, left_len, "<bp>")) == NULL) {
		ret = ERR_BUF_RES;
		goto err_exit;
	}
	if((cursor = gen_xml_int32(cursor, left_len, "code", CODE_OK)) == NULL) {
		ret = ERR_BUF_RES;
		goto err_exit;
	}
	if((cursor = gen_xml_str(cursor, left_len, "message", message[CODE_OK])) == NULL) {
		ret = ERR_BUF_RES;
		goto err_exit;
	}
	if((cursor = gen_xml_str(cursor, left_len, "citycode", user_data->prm->city_arr[0].c_str())) == NULL) {
		ret = ERR_BUF_RES;
		goto err_exit;
	}

	if((cursor = gen_xml_tag(cursor, left_len, "<buses>")) == NULL) {
		ret = ERR_BUF_RES;
		goto err_exit;
	}

	if(cmd == CMD_ARIVL_ST) {
		ret = build_arivl_st(cursor, left_len, user_data);
	}else if(cmd == CMD_LINE_ST) {
		ret = build_trips_st(cursor, left_len, user_data);
	}else if(cmd == CMD_TRIPS_ST) {
		ret = build_trips_st(cursor, left_len, user_data);
	}else if(cmd == CMD_TRIPS_ST2) {
		ret = build_trips_st2(cursor, left_len, user_data);
	}else{
		//����Ų���
		ret = ERR_HTTP_REQ;
		goto err_exit;
	}

	if(ret < 0) {
		goto err_exit;
	}

	if((cursor = gen_xml_tag(cursor, left_len, "</buses>")) == NULL) {
		ret = ERR_BUF_RES;
		goto err_exit;
	}
	if((cursor = gen_xml_tag(cursor, left_len, "</bp>")) == NULL) {
		ret = ERR_BUF_RES;
		goto err_exit;
	}

	user_data->http_response_len = res_size - left_len;

	snprintf(user_data->http_res_head, sizeof(user_data->http_res_head),
			"HTTP/1.0 200 OK\r\nContent-Length: %d\r\nContent-Type: text/xml;charset=GBK\r\nConnection: close\r\n\r\n",
			user_data->http_response_len);

err_exit:
	return ret;
}

int32 build_arivl_st(char*& res_buf, int32& res_size, struct bp_user_data* user_data) {
	if(res_buf == NULL || user_data == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}

	int32 ret = 0;
	char* cursor = res_buf;
	int32 left_len = res_size;

	std::list<struct arivl_st>& trip_unit = *(user_data->arivl_st_list);
	if(trip_unit.empty()) {
		WARNING_LOG("result is empty");
		return ERR_RES_EMPTY;
	}

	std::list<struct arivl_st>::iterator iter_trip = trip_unit.begin();
	std::list<struct arivl_st_item>::iterator iter_item;
	std::list<struct arivl_st_item>* item = NULL;

	for(iter_trip = trip_unit.begin(); iter_trip != trip_unit.end(); iter_trip++) {
		if((cursor = gen_xml_tag(cursor, left_len, "<item>")) == NULL) {
			ret = ERR_BUF_RES;
			goto err_exit;
		}

		if((cursor = gen_xml_uint64(cursor, left_len, "line", iter_trip->ln_id)) == NULL) {
			ret = ERR_BUF_RES;
			goto err_exit;
		}

		if((cursor = gen_xml_uint64(cursor, left_len, "station", iter_trip->st_id)) == NULL) {
			ret = ERR_BUF_RES;
			goto err_exit;
		}

		item = &(iter_trip->item);

		for(iter_item = item->begin(); iter_item != item->end(); iter_item++) {
			if((cursor = gen_xml_tag(cursor, left_len, "<trip>")) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}

			if((cursor = gen_xml_uint32(cursor, left_len, "arrival", iter_item->time_left)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_int32(cursor, left_len, "station_left", iter_item->st_num_left)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}

			if((cursor = gen_xml_double(cursor, left_len, "x", iter_item->trip_longitude)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_double(cursor, left_len, "y", iter_item->trip_latitude)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_int32(cursor, left_len, "speed", iter_item->trip_speed)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_int32(cursor, left_len, "speed_avg", iter_item->trip_speed_avg)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_int32(cursor, left_len, "dis", iter_item->trip_dis)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_tag(cursor, left_len, "</trip>")) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
		}

		if((cursor = gen_xml_tag(cursor, left_len, "</item>")) == NULL) {
			ret = ERR_BUF_RES;
			goto err_exit;
		}
	}

	res_buf = cursor;
	res_size = left_len;

err_exit:
	return ret;
}

int32 build_trips_st(char*& res_buf, int32& res_size, struct bp_user_data* user_data) {
	if(res_buf == NULL || user_data == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}

	int32 ret = 0;
	char* cursor = res_buf;
	int32 left_len = res_size;

	std::list<struct trips_st>& trip_unit = *(user_data->trips_st_list);
	if(trip_unit.empty()) {
		WARNING_LOG("result is empty");
		return ERR_RES_EMPTY;
	}

	std::list<struct trips_st>::iterator iter_trip = trip_unit.begin();

	std::list<struct coord>::iterator iter_coord;
	std::list<struct coord>* crd = NULL;

	std::list<struct line_st_item>::iterator iter_item;
	std::list<struct line_st_item>* item = NULL;

	for(iter_trip = trip_unit.begin(); iter_trip != trip_unit.end(); iter_trip++) {
		if((cursor = gen_xml_tag(cursor, left_len, "<item>")) == NULL) {
			ret = ERR_BUF_RES;
			goto err_exit;
		}

		if((cursor = gen_xml_uint64(cursor, left_len, "line", iter_trip->ln_id)) == NULL) {
			ret = ERR_BUF_RES;
			goto err_exit;
		}

		crd = &(iter_trip->trip_coord);
		//�������νڵ�
		for(iter_coord = crd->begin(); iter_coord != crd->end(); iter_coord++) {
			if((cursor = gen_xml_tag(cursor, left_len, "<trip>")) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_double(cursor, left_len, "x", iter_coord->longitude)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_double(cursor, left_len, "y", iter_coord->latitude)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_tag(cursor, left_len, "</trip>")) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
		}

		item = &(iter_trip->item);
		for(iter_item = item->begin(); iter_item != item->end(); iter_item++) {
			if((cursor = gen_xml_tag(cursor, left_len, "<st>")) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_uint64(cursor, left_len, "station", iter_item->st_id)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_uint32(cursor, left_len, "arrival", iter_item->time_left)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_int32(cursor, left_len, "station_left", iter_item->st_num_left)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_tag(cursor, left_len, "</st>")) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
		}

		if((cursor = gen_xml_tag(cursor, left_len, "</item>")) == NULL) {
			ret = ERR_BUF_RES;
			goto err_exit;
		}
	}

	res_buf = cursor;
	res_size = left_len;

err_exit:
	return ret;
}

int32 bp_err_to_code(int32 err) {
	if(err > ERR_ILLEGAL || err <= ERR_END) {
		return CODE_NO_DATA;
	}
	int ret = CODE_SERVER_ERR;

	switch(err) {
	case ERR_ILLEGAL:
	case ERR_NO_MEM:
	case ERR_BUF_RES:
		ret = CODE_SERVER_ERR;
		break;
	case ERR_RES_EMPTY:
	case ERR_NO_DATA:
	case ERR_DATA_EXPIRE:
		ret = CODE_NO_DATA;
		break;
	case ERR_HTTP_REQ:
		ret = CODE_PARAM_ILLGEAL;
		break;
	case ERR_NO_SUCH_CITY:
		ret = CODE_NO_SUPPORT;
		break;
	}

	return ret;
}

int32 bp_clear_user_data(struct bp_user_data* user_data) {
	if(user_data == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}
	user_data->elps_time = 0;
	user_data->http_get_post = 0;
	user_data->http_res_head[0] = '\0';
	user_data->http_response_len = 0;
	bp_clear_ln_info(user_data->ln);
	user_data->prm->city_arr.clear();
	user_data->prm->ln_arr.clear();
	user_data->prm->trip_limit = 0;
	user_data->prm->cmd = 0;
	user_data->prm->include_lines = false;
	user_data->prm->include_stations = false;
	if(user_data->prm_map != NULL) {
		user_data->prm_map->clear();
	}
	if(user_data->arivl_st_list != NULL) {
		user_data->arivl_st_list->clear();
	}
	if(user_data->trips_st_list != NULL) {
		user_data->trips_st_list->clear();
	}
	if(user_data->trips_st2_list != NULL) {
		user_data->trips_st2_list->clear();
	}

	if(user_data->st_dis_index != NULL) {
		user_data->st_dis_index->clear();
	}
	if(user_data->city_support != NULL) {
		user_data->city_support->clear();
	}

	return 0;
}

int32 bp_init_user_data(struct bp_user_data* user_data) {
	if(user_data == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}

	user_data->ln = new(std::nothrow) ln_info();
	if(user_data->ln == NULL) {
		FATAL_LOG("No enough memory for ln_info");
		return ERR_NO_MEM;
	}

	user_data->prm = new(std::nothrow) bp_prm();
	if(user_data->prm == NULL) {
		FATAL_LOG("No enough memory for bp_prm");
		return ERR_NO_MEM;
	}

	user_data->prm_map = new(std::nothrow) std::map<std::string, std::string>();
	if(user_data->prm_map == NULL) {
		FATAL_LOG("No enough memory for prm_map");
		return ERR_NO_MEM;
	}

	user_data->arivl_st_list = new(std::nothrow) std::list<struct arivl_st>();
	if(user_data->arivl_st_list == NULL) {
		FATAL_LOG("No enough memory for arivl_st_list");
		return ERR_NO_MEM;
	}

	user_data->trips_st_list = new(std::nothrow) std::list<struct trips_st>();
	if(user_data->trips_st_list == NULL) {
		FATAL_LOG("No enough memory for trips_st_list");
		return ERR_NO_MEM;
	}

	user_data->trips_st2_list = new(std::nothrow) std::list<struct trips_st2>();
	if(user_data->trips_st2_list == NULL) {
		FATAL_LOG("No enough memory for trips_st2_list");
		return ERR_NO_MEM;
	}

	user_data->st_dis_index = new(std::nothrow) std::vector<struct trip_st_index>();
	if(user_data->st_dis_index == NULL) {
		FATAL_LOG("No enough memory for st_dis_index");
		return ERR_NO_MEM;
	}

	user_data->city_support = new(std::nothrow) std::vector<bool>();
	if(user_data->city_support == NULL) {
		FATAL_LOG("No enough memory for city_support");
		return ERR_NO_MEM;
	}

	return 0;
}

int32 bp_get_arivl_st(uint64 st_id, struct bp_user_data* user_data) {
	if(user_data == NULL || user_data->ln == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}
	user_data->st_dis_index->clear();
	std::vector<struct trip_info>& trip_arr = user_data->ln->ln_trip_arr;

	uint32 t_limit = trip_arr.size();
	for(uint32 t_index = 0; t_index < t_limit; t_index++) {
		if(trip_arr[t_index].speed_avg <= 0) {
			continue;
		}

		uint32 s_index = 0;
		bool is_find = false;

		std::vector<struct trip_st_unit>& st_arr = trip_arr[t_index].st_unit_arr;

		uint32 s_limit = st_arr.size();
		for(s_index = 0; s_index < s_limit; s_index++) {
			if(st_arr[s_index].st_id == st_id) {
				is_find = true;
				break;
			}
		}

		if(is_find) {
			if(((int32) s_index >= trip_arr[t_index].nxt_st_index) && st_arr[s_index].dis >= 0) {
				struct trip_st_index tsi;
				tsi.trip = &(trip_arr);
				tsi.trip_index = t_index;
				tsi.st_index = s_index;
				user_data->st_dis_index->push_back(tsi);
			}
		}

	}

	if(user_data->st_dis_index->empty()) {
		WARNING_LOG("not find suitable trip for ln_id[%lu] and st_id[%lu]", user_data->ln->ln_id, st_id);
		return 0;
	}

	/*
	 * ��st_dis_index�����������
	 */
	sort(user_data->st_dis_index->begin(), user_data->st_dis_index->end(), sort_by_dis_ascend);

	int32 limit = user_data->prm->trip_limit;
	int32 real_limit = user_data->st_dis_index->size();
	limit = (limit < real_limit) ? limit : real_limit;

	struct arivl_st trip;
	trip.ln_id = user_data->ln->ln_id;
	trip.st_id = st_id;

	struct arivl_st_item item;

	int32 count = 0;
	while(count < limit) {
		struct trip_st_index&  tsi = (*(user_data->st_dis_index))[count];
		struct trip_info& ti = (* tsi.trip)[tsi.trip_index];

		memset(&item, 0, sizeof(item));
		item.trip_longitude = ti.longitude;
		item.trip_latitude = ti.latitude;
		item.trip_speed = ti.speed_instent;
		item.trip_speed_avg = ti.speed_avg;
		item.trip_dis = ti.st_unit_arr[tsi.st_index].dis;

		item.time_left = item.trip_dis / item.trip_speed_avg;
		if(item.time_left == 0) {
			item.st_num_left = 0;
		}else{
			item.st_num_left = tsi.st_index - ti.nxt_st_index;
			item.st_num_left = (item.st_num_left < 0) ? 0 : item.st_num_left;
		}
		trip.item.push_back(item);

		count++;
	}

	user_data->arivl_st_list->push_back(trip);

	return 0;
}

int32 bp_get_trips_st(struct bp_user_data* user_data, bool include_trip) {
	if(user_data == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}

	user_data->st_dis_index->clear();

	struct trips_st trip;
	trip.ln_id = user_data->ln->ln_id;

	std::vector<struct trip_info>& trip_arr = user_data->ln->ln_trip_arr;

	struct coord crd;

	uint32 t_limit = trip_arr.size();
	for(uint32 t_index = 0; t_index < t_limit; t_index++) {
		if(trip_arr[t_index].speed_avg > 0) {
			if(include_trip) {
				crd.longitude = trip_arr[t_index].longitude ;
				crd.latitude = trip_arr[t_index].latitude;
				trip.trip_coord.push_back(crd);
			}
			struct trip_st_index tsi;
			tsi.trip = &(trip_arr);
			tsi.trip_index = t_index;
			tsi.st_index = 0;
			user_data->st_dis_index->push_back(tsi);
		}
	}

	if(user_data->st_dis_index->empty()) {
		WARNING_LOG("not find suitable trip for ln_id[%lu]", user_data->ln->ln_id);
		return 0;
	}

	/*
	 * ��st_dis_index���鰴��nxt_sid�������У����nxt_sid��ͬ���յ����nxt_sid��dis��������
	 */
	sort(user_data->st_dis_index->begin(), user_data->st_dis_index->end(), sort_by_nxt_sid_descend);

	int32 limit = user_data->st_dis_index->size();

	struct line_st_item item;

	int32 count = 0;
	while(count < limit) {
		struct trip_st_index&  tsi = (*(user_data->st_dis_index))[count];
		struct trip_info& ti = (* tsi.trip)[tsi.trip_index];

		uint64 st_id_boundary = 0;
		int32 st_index_limit = 0;
		int32 s_limit = (int32) ti.st_unit_arr.size();
		int32 nxt_st_index = ti.nxt_st_index;

		std::list<struct line_st_item>::iterator iter = trip.item.begin();
		if(iter != trip.item.end()) {
			st_id_boundary = iter->st_id;
			for(st_index_limit = nxt_st_index; st_index_limit < s_limit; st_index_limit++) {
				if(ti.st_unit_arr[st_index_limit].st_id == st_id_boundary) {
					break;
				}
			}
			if(st_index_limit == nxt_st_index) {
				//��ʾ�����˳��ε�nxt_st_idվ����ͬ��ֻ��Ҫһ�����ݼ��ɣ�������������
				count++;
				continue;
			}
			st_index_limit--;
		}else{
			st_index_limit = s_limit - 1;
		}

		for(int32 s_index = st_index_limit; s_index >= nxt_st_index; s_index--) {
			struct trip_st_unit& tsu = ti.st_unit_arr[s_index];

			memset(&item, 0, sizeof(item));

			item.st_id = tsu.st_id;
			item.time_left = tsu.dis / ti.speed_avg;
			if(item.time_left == 0) {
				item.st_num_left = 0;
			}else{
				item.st_num_left = s_index - ti.nxt_st_index;
				item.st_num_left = (item.st_num_left < 0) ? 0 : item.st_num_left;
			}

			trip.item.push_front(item);
		}

		count++;
	}

	user_data->trips_st_list->push_back(trip);
	return 0;
}

int32 bp_process_trips_st2(char* write_data, uint32 write_data_size, struct bp_user_data* user_data) {
	if(write_data == NULL || user_data == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}

	/*
	 * ��blk_list�л�ȡָ��ln_id�ĳ�����Ϣ
	 */
	int32 ret = 0;
	int32 ln_limit = user_data->prm->ln_arr.size();
	if(ln_limit == 0 || user_data->prm->ln_arr[0].ln_id == 0) {
		WARNING_LOG("http request for all trips, should include lines");
		return ERR_HTTP_REQ;
	}
	if(ln_limit > MAX_LINE_LIMIT) {
		WARNING_LOG("number of lines [%d] more than limit [%d]", ln_limit, MAX_LINE_LIMIT);
		return ERR_HTTP_REQ;
	}

	struct city_list* cl = NULL;
	for(int32 i = 0; i < ln_limit; i++) {
		uint64 ln_id = user_data->prm->ln_arr[i].ln_id;
		//��Ҫ���¼���city_list
		cl = get_city_list(ln_id);
		if(cl == NULL) {
			continue;
		}

		bp_clear_ln_info(user_data->ln);
		ret = blk_list_find(cl->bl, ln_id, user_data->ln);
		if(ret < 0) {
			if(ret == ERR_NO_DATA) {
				/*
				 * blk_list����û�����ln_id,��Ҫ��������µ�id���������߳��첽����
				 */
				ret = blk_list_insert(cl->bl, ln_id);
				if(ret < 0) {
					WARNING_LOG("Fail to blk_list_insert ln_id[%lu]", ln_id);
				}

				continue;
			}else if(ret == ERR_DATA_EXPIRE) {
				/*
				 * blk_list�����д�ln_id,���Ǵ������Ѿ�����ʧЧ
				 */
				continue;
			}else{
				WARNING_LOG("The blk_list data error!");
				return ret;
			}
		}

		ret = bp_get_trips_st2(user_data);
		if(ret < 0) {
			WARNING_LOG("Fail to bp_get_trips_st2 ln_id[%lu] for build result", user_data->ln->ln_id);
			continue;
		}
	}

	if(cl == NULL) {
		WARNING_LOG("No support such city");
		return ERR_NO_SUCH_CITY;
	}
	
	std::string city(cl->city_code);
	user_data->prm->city_arr.clear();
	user_data->prm->city_arr.push_back(city);
	/*
	 * �Զ����ƽ��ת��������Ϊָ����ʽ��Ӧ��
	 */
	ret = bp_build_res(write_data, write_data_size, user_data);
	if(ret < 0) {
		WARNING_LOG("Fail to build final response");
		return ret;
	}

	return 0;
}

#define  BUS_WAIT_DIS (80)//ͣ��վ����ֵ�����ξ����ٽ���һվ����С�ڵ��ڸ�ֵʱ����Ϊ�ó��δ���ͣ��״̬����λ����

int32 bp_get_trips_st2(struct bp_user_data* user_data) {
	if(user_data == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}

	user_data->st_dis_index->clear();

	struct trips_st2 trip;
	trip.ts_ln_id = user_data->ln->ln_id;

	std::vector<struct trip_info>& trip_arr = user_data->ln->ln_trip_arr;

	uint32 t_limit = trip_arr.size();
	for(uint32 t_index = 0; t_index < t_limit; t_index++) {
		if(trip_arr[t_index].speed_avg > 0) {
			struct trip_st_index tsi;
			tsi.trip = &(trip_arr);
			tsi.trip_index = t_index;
			tsi.st_index = 0;
			user_data->st_dis_index->push_back(tsi);
		}
	}

	if(user_data->st_dis_index->empty()) {
		WARNING_LOG("not find suitable trip for ln_id[%lu]", user_data->ln->ln_id);
		return 0;
	}

	/*
	 * ��st_dis_index���鰴��nxt_sid�������У����nxt_sid��ͬ���յ����nxt_sid��dis��������
	 */
	sort(user_data->st_dis_index->begin(), user_data->st_dis_index->end(), sort_by_nxt_sid_descend);

	struct trip_unit tu;
	struct td_item tdi;
	struct ts_item tsi;

	int32 limit = user_data->st_dis_index->size();
	int32 count = 0;
	while(count < limit) {
		struct trip_st_index& trip_si = (*(user_data->st_dis_index))[count];
		struct trip_info& ti = (* trip_si.trip)[trip_si.trip_index];

		//��¼��ǰ������Ϣ
		memset(&tu, 0, sizeof(struct trip_unit));
		tu.t_index = (limit - count - 1);
		tu.t_coord.longitude = ti.longitude;
		tu.t_coord.latitude = ti.latitude;
		tu.t_stid = ti.nxt_st_id;

		struct trip_st_unit& tsu = ti.st_unit_arr[ti.nxt_st_index];
		if(tsu.dis <= BUS_WAIT_DIS) {
			//��ǰ���δ���ͣ��״̬
			tu.t_status = 0;
		}else{
			//��ǰ���δ�����;��״̬
			tu.t_status = 1;
			tu.t_dis = tsu.dis;
			tu.t_time_left = tu.t_dis / ti.speed_avg;
		}
		trip.ts_tu.push_front(tu);

		//����ts_item
		uint64 st_id_boundary = 0;
		int32 st_index_limit = 0;
		int32 st_limit = (int32) ti.st_unit_arr.size();
		int32 nxt_st_index = ti.nxt_st_index;

		std::list<struct ts_item>::iterator iter = trip.ts_ti.begin();
		if(iter != trip.ts_ti.end()) {
			st_id_boundary = iter->ti_stid;

			for(st_index_limit = nxt_st_index; st_index_limit < st_limit; st_index_limit++) {
				if(ti.st_unit_arr[st_index_limit].st_id == st_id_boundary) {
					break;
				}
			}
			st_index_limit--;

			//�������е�ts_item
			int32 up_st_index = st_index_limit + 1;
			for(iter = trip.ts_ti.begin(); iter != trip.ts_ti.end(); iter++) {
				while(up_st_index < st_limit) {
					if(ti.st_unit_arr[up_st_index].st_id == iter->ti_stid) {
						break;
					}
					up_st_index++;
				}

				//�쳣���
				if(up_st_index >= st_limit) {
					break;
				}

				//����ʱ
				tdi.ti_index = tu.t_index;
				tdi.ti_dis = ti.st_unit_arr[up_st_index].dis;
				tdi.ti_time_left = tdi.ti_dis / ti.speed_avg;
				tdi.ti_station_left = up_st_index - ti.nxt_st_index;
				//����ͣ�����߼�����վ�ĳ�����Ŀ
				if(up_st_index == nxt_st_index) {
					if(tu.t_status == 0) {
						//ͣ����վ
						iter->ti_trip_wait++;
					}else{
						//;��
						iter->ti_trip_arriving++;
					}
				}

				if (!iter->ti_data.empty()){
					
					 std::list<struct td_item>::iterator tempIter 
					 	= iter->ti_data.begin();

					 int32 	nDis 		= tdi.ti_dis - tempIter->ti_dis;
					 int32	nTimeLeft	= tempIter->ti_time_left;
					 tdi.ti_time_left = nTimeLeft + nDis / ti.speed_avg;
				}
				
				iter->ti_data.push_front(tdi);
			}
		}else{
			st_index_limit = st_limit - 1;
		}

		//����ts_item
		for(int32 s_index = st_index_limit; s_index >= nxt_st_index; s_index--) {
			struct trip_st_unit& tsu = ti.st_unit_arr[s_index];

			tsi.ti_stid = tsu.st_id;
			tsi.ti_trip_arriving = ((s_index == nxt_st_index) && (tu.t_status == 1)) ? 1 : 0;
			tsi.ti_trip_wait = ((s_index == nxt_st_index) && (tu.t_status == 0)) ? 1 : 0;
			tsi.ti_data.clear();


			tdi.ti_index = tu.t_index;
			tdi.ti_dis = tsu.dis;
			tdi.ti_time_left = tdi.ti_dis / ti.speed_avg;
			tdi.ti_station_left = s_index - ti.nxt_st_index; 

			tsi.ti_data.push_back(tdi);
			trip.ts_ti.push_front(tsi);
		}


		count++;
	}

	user_data->trips_st2_list->push_back(trip);
	return 0;
}

#undef BUS_WAIT_DIS

int32 build_trips_st2(char*& res_buf, int32& res_size, struct bp_user_data* user_data) {
	if(res_buf == NULL || user_data == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}

	int32 ret = 0;
	char* cursor = res_buf;
	int32 left_len = res_size;

	std::list<struct trips_st2>& trip_unit = *(user_data->trips_st2_list);
	if(trip_unit.empty()) {
		WARNING_LOG("result is empty");
		return ERR_RES_EMPTY;
	}

	std::list<struct trips_st2>::iterator iter_trip = trip_unit.begin();

	std::list<struct trip_unit>* tu;
	std::list<struct trip_unit>::iterator iter_tu;

	std::list<struct ts_item>* ti;
	std::list<struct ts_item>::iterator iter_ti;

	std::list<struct td_item>* td;
	std::list<struct td_item>::iterator iter_td;

	for(iter_trip = trip_unit.begin(); iter_trip != trip_unit.end(); iter_trip++) {
		if((cursor = gen_xml_tag(cursor, left_len, "<item>")) == NULL) {
			ret = ERR_BUF_RES;
			goto err_exit;
		}

		if((cursor = gen_xml_uint64(cursor, left_len, "line", iter_trip->ts_ln_id)) == NULL) {
			ret = ERR_BUF_RES;
			goto err_exit;
		}

		tu = &(iter_trip->ts_tu);
		//�������νڵ�
		for(iter_tu = tu->begin(); iter_tu != tu->end(); iter_tu++) {
			if((cursor = gen_xml_tag(cursor, left_len, "<trip>")) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_uint32(cursor, left_len, "i", iter_tu->t_index)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_double(cursor, left_len, "x", iter_tu->t_coord.longitude)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_double(cursor, left_len, "y", iter_tu->t_coord.latitude)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_uint64(cursor, left_len, "stid", iter_tu->t_stid)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_uint32(cursor, left_len, "s", iter_tu->t_status)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if(iter_tu->t_status == 1) {
				if((cursor = gen_xml_int32(cursor, left_len, "d", iter_tu->t_dis)) == NULL) {
					ret = ERR_BUF_RES;
					goto err_exit;
				}
				if((cursor = gen_xml_int32(cursor, left_len, "t", iter_tu->t_time_left)) == NULL) {
					ret = ERR_BUF_RES;
					goto err_exit;
				}
			}
			if((cursor = gen_xml_tag(cursor, left_len, "</trip>")) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
		}

		ti = &(iter_trip->ts_ti);
		for(iter_ti = ti->begin(); iter_ti != ti->end(); iter_ti++) {
			if((cursor = gen_xml_tag(cursor, left_len, "<st>")) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if((cursor = gen_xml_uint64(cursor, left_len, "id", iter_ti->ti_stid)) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
			if(iter_ti->ti_trip_wait != 0) {
				if((cursor = gen_xml_uint32(cursor, left_len, "tw", iter_ti->ti_trip_wait)) == NULL) {
					ret = ERR_BUF_RES;
					goto err_exit;
				}
			}
			if(iter_ti->ti_trip_arriving != 0) {
				if((cursor = gen_xml_uint32(cursor, left_len, "ta", iter_ti->ti_trip_arriving)) == NULL) {
					ret = ERR_BUF_RES;
					goto err_exit;
				}
			}

			if((cursor = gen_xml_tag(cursor, left_len, "<td>")) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}

			td = &(iter_ti->ti_data);
			for(iter_td = td->begin(); iter_td != td->end(); iter_td++) {
				if((cursor = gen_xml_tag(cursor, left_len, "<tu>")) == NULL) {
					ret = ERR_BUF_RES;
					goto err_exit;
				}
				if((cursor = gen_xml_uint32(cursor, left_len, "ti", iter_td->ti_index)) == NULL) {
					ret = ERR_BUF_RES;
					goto err_exit;
				}
				if(iter_td->ti_dis != 0) {
					if((cursor = gen_xml_int32(cursor, left_len, "d", iter_td->ti_dis)) == NULL) {
						ret = ERR_BUF_RES;
						goto err_exit;
					}
				}
				if(iter_td->ti_time_left != 0) {
					if((cursor = gen_xml_int32(cursor, left_len, "t", iter_td->ti_time_left)) == NULL) {
						ret = ERR_BUF_RES;
						goto err_exit;
					}
				}
				if(iter_td->ti_station_left > 0) {
					if((cursor = gen_xml_int32(cursor, left_len, "ls", iter_td->ti_station_left)) == NULL) {
						ret = ERR_BUF_RES;
						goto err_exit;
					}
				}
				if((cursor = gen_xml_tag(cursor, left_len, "</tu>")) == NULL) {
					ret = ERR_BUF_RES;
					goto err_exit;
				}
			}

			if((cursor = gen_xml_tag(cursor, left_len, "</td></st>")) == NULL) {
				ret = ERR_BUF_RES;
				goto err_exit;
			}
		}

		if((cursor = gen_xml_tag(cursor, left_len, "</item>")) == NULL) {
			ret = ERR_BUF_RES;
			goto err_exit;
		}
	}

	res_buf = cursor;
	res_size = left_len;

err_exit:
	return ret;
}

/*
struct city_list* get_city_list(uint64 ln_sign) {
	
	hash_map<uint64, struct city_list*>::iterator iter = g_city_hash->hp.find(ln_sign);
	if(iter == g_city_hash->hp.end()) {
		return NULL;
	}

	return iter->second;
}
*/

struct city_list* get_city_list(uint64 ln_id) {
	bool is_find = false;
	struct city_list* cl = g_city_list;
	while(cl != NULL) {
		is_find = blk_list_ln_is_exist(cl->bl, ln_id);
		if(is_find) {
			break;
		}
		cl = cl->next;
	}

	return cl;
}

