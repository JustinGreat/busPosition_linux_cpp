/*
 * bp_blk_list.cpp
 *
 *  Created on: 2013-3-13
 *      Author: pengcheng.wang
 */

#include "bp_blk_list.h"
#include "my_log.h"
#include "err_head.h"
#include "rw_lock.h"


struct blk_node* blk_list_get_free_node(struct blk_list* bl);
int32 blk_list_copy_ln_info(struct ln_info* des, struct ln_info* src);

struct blk_list* blk_list_create(int32 node_vol) {
	if(node_vol <= 0) {
		FATAL_LOG("The input node_vol[%d] is illegal", node_vol);
		return NULL;
	}
	struct blk_list* new_bl = (struct blk_list*) calloc(1, sizeof(struct blk_list));
	if(new_bl == NULL) {
		FATAL_LOG("No enouth memory for new blk_list");
		return NULL;
	}
	new_bl->node_vol = node_vol;
	new_bl->ln_hash_map = new(std::nothrow) hash_map<uint64, struct blk_node* >();
	if(new_bl->ln_hash_map == NULL) {
		FATAL_LOG("No enough memory for ln_hash_map");
		return NULL;
	}

	if(pthread_rwlock_init(&new_bl->blk_rw_lock, NULL) != 0) {
		FATAL_LOG("Fail to init blk_list pthread_rw_lock! err[%s]", strerror(errno));
		return NULL;
	}

	return new_bl;
}

int32 blk_list_destroy(struct blk_list* bl) {
	if(bl == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}

	if(bl->ln_hash_map != NULL) {
		delete bl->ln_hash_map;
		bl->ln_hash_map = NULL;
	}
	while(bl->head != NULL) {
		struct blk_node* cur_node = bl->head->next;

		delete[] bl->head->ln_arr;
		bl->head->ln_arr = NULL;

		free(bl->head);
		bl->head = cur_node;
	}

	pthread_rwlock_destroy(&bl->blk_rw_lock);
	free(bl);

	return 0;
}

struct blk_node* blk_list_new_node(int32 node_vol) {
	if(node_vol <= 0) {
		WARNING_LOG("The input node_vol[%d] is illegal", node_vol);
		return NULL;
	}

	struct blk_node* new_node = (struct blk_node*) calloc(1, sizeof(struct blk_node));
	if(new_node == NULL) {
		FATAL_LOG("The input parameter is illegal");
		return NULL;
	}

	new_node->ln_arr = new(std::nothrow) struct ln_info[node_vol];
	if(new_node->ln_arr == NULL) {
		FATAL_LOG("No enouth memory for ln_info_array");
		return NULL;
	}

	return new_node;
}

/*
 * ֻ�������������������µ�line_id����
 */
int32 blk_list_insert(struct blk_list* bl, uint64 ln_id) {
	if(bl == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}
	if(bl->ln_hash_map == NULL) {
		WARNING_LOG("blk_list hash_map is NULL!");
		return ERR_ILLEGAL;
	}
	/*
	 * �Ӷ���,�Է�ֹupdate_timer�ﶨʱ����ʱ��delete ��grid������RAII���ƣ����Զ��ͷ���
	 * ��������Դ��ȡ���ǳ�ʼ���������Resource Acquisition Is Initialization��
	 */
	RWLock my_lock(&bl->blk_rw_lock);
	if(my_lock.write_lock() != 0) {
		return ERR_ILLEGAL;
	}
	/*
	 * ��Ϊ�����Ƕ��̶߳������insert�������ȼ�д������ֻ֤��һ���߳�������insert��
	 * ��������ж��Ƿ��Ѿ���ln_id����������򷵻�����
	 */
	hash_map<uint64, struct blk_node*>::iterator iter_map = bl->ln_hash_map->find(ln_id);
	if(iter_map != bl->ln_hash_map->end()) {
		return 0;
	}

	struct blk_node* cur_node = blk_list_get_free_node(bl);
	if(cur_node == NULL) {
		WARNING_LOG("Fail to get free node from blk_list");
		return ERR_ILLEGAL;
	}
	uint8 cur_index = cur_node->used_num;
	if(cur_index >= bl->node_vol) {
		WARNING_LOG("current blk_node is full! blk_list_get_free_node() is illegal");
		return ERR_ILLEGAL;
	}

	cur_node->ln_arr[cur_index].ln_id = ln_id;
	cur_node->ln_arr[cur_index].ln_expire_time = 0;
	cur_node->ln_arr[cur_index].ln_trip_arr.clear();
	cur_node->used_num++;

	bl->ln_hash_map->insert(std::pair<uint64, struct blk_node*>(ln_id, cur_node));

	return 0;
}

int32 blk_list_find(struct blk_list* bl, uint64 ln_id, struct ln_info* res) {
	if(bl == NULL|| res == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}
	if(bl->head == NULL || bl->ln_hash_map == NULL) {
		WARNING_LOG("blk_list is empty!");
		return ERR_NO_DATA;
	}

	RWLock my_lock(&bl->blk_rw_lock);
	if(my_lock.read_lock() != 0) {
		return ERR_ILLEGAL;
	}

	hash_map<uint64, struct blk_node*>::iterator iter_map = bl->ln_hash_map->find(ln_id);
	if(iter_map == bl->ln_hash_map->end()) {
		WARNING_LOG("ln_id[%lu] not in hash_map", ln_id);
		return ERR_NO_DATA;
	}
	struct blk_node* cur_node = iter_map->second;
	if(cur_node == NULL) {
		WARNING_LOG("ln_id[%lu] in hash_map, but no blk_node pointer, maybe blk_list content synchronized error!", ln_id);
		return ERR_NO_DATA;
	}
	time_t cur_time = 0;
	time(&cur_time);

	for(int32 i = 0; i < cur_node->used_num; i++) {
		if(cur_node->ln_arr[i].ln_id == ln_id) {
			if(cur_node->ln_arr[i].ln_expire_time > cur_time) {
				return blk_list_copy_ln_info(res, &(cur_node->ln_arr[i]));
			}else{
				//�������Ѿ�������Ч�ڣ�ʧЧ
				return ERR_DATA_EXPIRE;
			}

		}
	}

	WARNING_LOG("ln_id[%lu] in hash_map, but not in blk_node, maybe blk_list content synchronized error!", ln_id);
	return ERR_NO_DATA;
}

int32 blk_list_copy_ln_info(struct ln_info* des, struct ln_info* src) {
	if(des == NULL || src == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}
	des->ln_id = src->ln_id;
	des->ln_expire_time = src->ln_expire_time;
	des->ln_trip_arr.clear();

	des->ln_trip_arr.assign(src->ln_trip_arr.begin(), src->ln_trip_arr.end());

	return 0;
}

bool blk_list_ln_is_exist(struct blk_list* bl, uint64 ln_id) {
	if(bl == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return false;
	}
	if(bl->ln_hash_map == NULL) {
		return false;
	}

	RWLock my_lock(&bl->blk_rw_lock);
	if(my_lock.read_lock() != 0) {
		return false;
	}
	
	hash_map<uint64, struct blk_node*>::iterator iter_map = bl->ln_hash_map->find(ln_id);
	if(iter_map != bl->ln_hash_map->end()) {
		return true;
	}

	return false;
}

struct blk_node* blk_list_get_free_node(struct blk_list* bl) {
	if(bl == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return NULL;
	}

	if(bl->tail == NULL || bl->tail->used_num == bl->node_vol) {
		struct blk_node* new_node = blk_list_new_node(bl->node_vol);
		if(new_node == NULL) {
			return NULL;
		}
		if(bl->tail == NULL) {
			bl->tail = new_node;
			bl->head = bl->tail;
		}else{
			bl->tail->next = new_node;
			bl->tail = new_node;
		}
	}

	return bl->tail;
}


int32 blk_list_clear(struct blk_list* bl) {
	if(bl == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}

	if(bl->ln_hash_map == NULL) {
		WARNING_LOG("blk_list hash_map is NULL, illegal");
		return ERR_ILLEGAL;
	}

	if(bl->head == NULL || bl->tail == NULL || bl->ln_hash_map->empty()) {
		return 0;
	}


	RWLock my_lock(&bl->blk_rw_lock);
	if(my_lock.write_lock() != 0) {
		return ERR_ILLEGAL;
	}

	//����hash_map�е������йش�old_node����ln_id��Ӧ��blk_nodeָ��
	//���hash_map����
	bl->ln_hash_map->clear();

	while(bl->head != NULL) {
		struct blk_node* cur_node = bl->head->next;

		delete[] bl->head->ln_arr;
		bl->head->ln_arr = NULL;

		free(bl->head);

		bl->head = cur_node;
	}

	bl->tail = NULL;

	return 0;
}

/*
 * ���µ�ln_info���뵽blk_list�У�
 * ���blk_listû�д�ln_id���ݣ����������ݣ�
 * �����ԭln_id���ݽ��и������ݲ���
 */
int32 blk_list_update(struct blk_list* bl, struct ln_info* new_ln_info) {
	if(bl == NULL || new_ln_info == NULL) {
		WARNING_LOG("The input parameter is illegal");
		return ERR_ILLEGAL;
	}
	if(bl->ln_hash_map == NULL) {
		WARNING_LOG("ln_hash_map is NULL");
		return ERR_ILLEGAL;
	}

	RWLock my_lock(&bl->blk_rw_lock);
	if(my_lock.write_lock() != 0) {
		return ERR_ILLEGAL;
	}

	hash_map<uint64, struct blk_node*>::iterator iter_map;

	iter_map = bl->ln_hash_map->find(new_ln_info->ln_id);
	if(iter_map == bl->ln_hash_map->end()) {
		/*
		 * ����û�д���������£���Ҫ��������
		 */
		struct blk_node* cur_node = blk_list_get_free_node(bl);
		if(cur_node == NULL) {
			WARNING_LOG("Fail to get free node from blk_list");
			return ERR_ILLEGAL;
		}
		uint8 cur_index = cur_node->used_num;
		if(cur_index >= bl->node_vol) {
			WARNING_LOG("current blk_node is full! blk_list_get_free_node() is illegal");
			return ERR_ILLEGAL;
		}

		int32 ret = blk_list_copy_ln_info(cur_node->ln_arr+cur_index, new_ln_info);
		if(ret < 0) {
			WARNING_LOG("fail to copy new ln_info into index[%u] in node arrary", cur_index);
			return ERR_ILLEGAL;
		}

		cur_node->used_num++;

		bl->ln_hash_map->insert(std::pair<uint64, struct blk_node*>(new_ln_info->ln_id, cur_node));

		return 0;
	}else{
		/*
		 * �������и�ln_id�Ľṹ�壬����Ҫ��ԭ�����ݽ��и���
		 */
		struct blk_node* cur_node = iter_map->second;
		if(cur_node == NULL) {
			WARNING_LOG("ln_id[%lu] in hash_map, but no blk_node pointer, maybe blk_list content synchronized error!",
					new_ln_info->ln_id);
			return ERR_ILLEGAL;
		}

		for(int32 i = 0; i < cur_node->used_num; i++) {
			if(cur_node->ln_arr[i].ln_id == new_ln_info->ln_id) {
				return blk_list_copy_ln_info(cur_node->ln_arr+i, new_ln_info);
			}
		}
	}

	WARNING_LOG("not find ln_id[%lu] in blk_node list!", new_ln_info->ln_id);
	return ERR_ILLEGAL;
}
