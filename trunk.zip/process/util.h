/*
 * util.h
 *
 *  Created on: 2012-5-2
 *      Author: pengcheng.wang
 */

#ifndef UTIL_H_
#define UTIL_H_

#include "bp_type.h"

int32 xatoi(char* src);

uint32 xatoui(char* src);

double xatod(char* src);

float xatof(char* src);

uint64 xatoul(char* src);

char* gen_xml_uint64(char* res, int32& res_len, const char* tag, uint64 content);
char* gen_xml_int64(char* res, int32& res_len, const char* tag, int64 content);
char* gen_xml_uint32(char* res, int32& res_len, const char* tag, uint32 content);
char* gen_xml_int32(char* res, int32& res_len, const char* tag, int32 content);
char* gen_xml_float(char* res, int32& res_len, const char* tag, float content);
char* gen_xml_double(char* res, int32& res_len, const char* tag, double content);
char* gen_xml_conv_str(char* res, int32& res_len, const char* tag, const char* content);
char* gen_xml_str(char* res, int32& res_len, const char* tag, const char* content);

char* gen_xml_tag(char* res, int32&res_len, const char* tag);
char* gen_xml_encode_head(char* res, int32& res_len, const char* char_set);

int32  url_decode(char *url);
int32 url_encode(char* des, int32 des_size, const char* src);

#endif /* UTIL_H_ */
